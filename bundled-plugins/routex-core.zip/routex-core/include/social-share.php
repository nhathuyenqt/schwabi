<?php


// product single social share
function routex_wooc_product_social_share(){

    $post_url = get_the_permalink(); 
    ?>
    <span><?php echo esc_html__('Share:', 'rr-core'); ?></span>
    <a href="<?php echo esc_url($post_url);?>"><i class="fa-brands fa-facebook-f"></i></a>
    <a href="<?php echo esc_url($post_url);?>"><i class="fa-brands fa-vimeo-v"></i></a>
    <a href="<?php echo esc_url($post_url);?>"><i class="fa-brands fa-twitter"></i></a>
    <a href="<?php echo esc_url($post_url);?>"><i class="fa-brands fa-linkedin-in"></i></a>

<?php

}
add_action( 'routex_woo_social_share', 'routex_wooc_product_social_share' );