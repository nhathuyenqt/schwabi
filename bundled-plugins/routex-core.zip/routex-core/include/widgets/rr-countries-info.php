<?php
	/**
	 * Medidove Footer full Widget
	 *
	 *
	 * @author 		Nilartstudio
	 * @category 	Widgets
	 * @package 	Medidove/Widgets
	 * @version 	1.0.0
	 * @extends 	WP_Widget
	 */
	add_action('widgets_init', 'Medinet_Countrie_Widget');
	function Medinet_Countrie_Widget() {
		register_widget('Medinet_Countrie_Widget');
	} 
	
	
	class Medinet_Countrie_Widget  extends WP_Widget{
		
		public function __construct(){
			parent::__construct('Medinet_Countrie_Widget',esc_html__('Countrie Info','tocore'),array(
				'description' => esc_html__('Countrie Info Widget','tocore'),
			));
		}
		
		public function widget($args, $instance){
			extract($args);
			extract($instance);
			
			 print $before_widget; 
                                 
		        if ( ! empty( $title ) ) {
					print $before_title . apply_filters( 'widget_title', $title ) . $after_title;
				}
		?>

<div class="countrie-details__title wow fadeInLeft" data-wow-delay=".2s">
    <?php if( !empty($title) ): ?>
    <h4><?php print esc_attr($title); ?></h4>
    <?php endif; ?>
</div>
<div class="countrie-details__box wow fadeInLeft  animated" data-wow-delay=".3s">
    <div class="countrie-details__box-content wow fadeInLeft" data-wow-delay=".4s">
        <a href="tel:6295550129"><i class="fa-solid fa-phone"></i>(629) 555-0129</a>
        <a class="mt-20" href="mailto:info.rrdevs@gmail.com"><i class="fa-solid fa-envelope"></i>info@example.com</a>
        <a class="mt-20" href="https://maps.app.goo.gl/R8Y6ZY6s1KrcGWc67"><i class="fa-solid fa-location-dot"></i>6391
            Elgin St. Celina, 10299</a>
    </div>
    <div class="countrie-details__box-btn mt-40">
        <a href="contact.html">Contact Us <i class="fa-solid fa-arrow-right"></i></a>
    </div>
</div>
<?php print $after_widget; ?>
<?php 
		}
	
		/**
		 * widget function.
		 *
		 * @see WP_Widget
		 * @access public
		 * @param array $instance
		 * @return void
		 */
		public function form($instance){

			$title  = isset($instance['title'])? $instance['title']:'';
			$address  = isset($instance['address'])? $instance['address']:'';
			$email  = isset($instance['email'])? $instance['email']:'';
			$phone_number  = isset($instance['phone_number'])? $instance['phone_number']:'';
			$website  = isset($instance['website'])? $instance['website']:'';
			?>
<p>
    <label for="title"><?php esc_html_e('Title:','tocore'); ?></label>
</p>
<input type="text" id="<?php print esc_attr($this->get_field_id('title')); ?>"
    name="<?php print esc_attr($this->get_field_name('title')); ?>" class="widefat"
    value="<?php print esc_attr($title); ?>">

<p>
    <label for="title"><?php esc_html_e('Address:','tocore'); ?></label>
</p>
<input type="text" id="<?php print esc_attr($this->get_field_id('address')); ?>"
    name="<?php print esc_attr($this->get_field_name('address')); ?>" class="widefat"
    value="<?php print esc_attr($address); ?>">

<p>
    <label for="title"><?php esc_html_e('Email Address:','tocore'); ?></label>
</p>
<input type="text" id="<?php print esc_attr($this->get_field_id('email')); ?>"
    name="<?php print esc_attr($this->get_field_name('email')); ?>" class="widefat"
    value="<?php print esc_attr($email); ?>">

<p>
    <label for="title"><?php esc_html_e('Phone Number:','tocore'); ?></label>
</p>
<input type="text" id="<?php print esc_attr($this->get_field_id('phone_number')); ?>"
    name="<?php print esc_attr($this->get_field_name('phone_number')); ?>" class="widefat"
    value="<?php print esc_attr($phone_number); ?>">

<p>
    <label for="title"><?php esc_html_e('Website Url:','tocore'); ?></label>
</p>
<input type="text" id="<?php print esc_attr($this->get_field_id('website')); ?>"
    name="<?php print esc_attr($this->get_field_name('website')); ?>" class="widefat"
    value="<?php print esc_attr($website); ?>">

<?php
		}
				
		public function update( $new_instance, $old_instance ) {
			$instance = array();
			$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
			$instance['address'] = ( ! empty( $new_instance['address'] ) ) ? strip_tags( $new_instance['address'] ) : '';
			$instance['email'] = ( ! empty( $new_instance['email'] ) ) ? strip_tags( $new_instance['email'] ) : '';
			$instance['phone_number'] = ( ! empty( $new_instance['phone_number'] ) ) ? strip_tags( $new_instance['phone_number'] ) : '';
			$instance['website'] = ( ! empty( $new_instance['website'] ) ) ? strip_tags( $new_instance['website'] ) : '';

			return $instance;
		}
	}