<?php
	/**
	 * Contact Info Widget
	 *
	 *
	 * @author 		Nilartstudio
	 * @category 	Widgets
	 * @package 	pohat/Widgets
	 * @version 	1.0.0
	 * @extends 	WP_Widget
	 */
	add_action('widgets_init', 'kingfact_contact_info_widget');
	function kingfact_contact_info_widget() {
		register_widget('kingfact_contact_info_widget');
	}
	
	
	class Kingfact_Contact_Info_Widget  extends WP_Widget{
		
		public function __construct(){
			parent::__construct('kingfact_contact_info_widget',esc_html__('Zibber Contact Info', 'tocore'),array(
				'description' => esc_html__('Zibber Contact Info Widget', 'tocore'),
			));
		}
		
		public function widget($args, $instance){
			extract($args);
			extract($instance);
			

			 print $before_widget; 
                                 
		        if ( ! empty( $title ) ) {
					print $before_title . apply_filters( 'widget_title', $title ) . $after_title;
				}
		?>
<div class="countrie-details__box wow fadeInLeft  animated" data-wow-delay=".3s">
    <div class="countrie-details__box-content wow fadeInLeft" data-wow-delay=".4s">
		<?php if($phone_number): ?>
        <a href="tel:<?php print esc_attr($phone_number_url); ?>"><i class="fa-solid fa-phone"></i><?php print esc_html($phone_number); ?></a>
		<?php endif; ?>
		<?php if($email): ?>
        <a class="mt-20" href="mailto:<?php print esc_html($email); ?>"><i class="fa-solid fa-envelope"></i><?php print esc_html($email); ?></a>
		<?php endif; ?>
		<?php if($address): ?>
        <a class="mt-20" href="<?php print esc_url($address_url); ?>"><i class="fa-solid fa-location-dot"></i><?php print esc_html($address); ?></a>
		<?php endif; ?>
    </div>
    <div class="countrie-details__box-btn mt-40">
	<?php if( !empty($button_text) ): ?>	
        <a href="<?php print esc_url($button_url); ?>"><?php print esc_html($button_text); ?> <i class="fa-solid fa-arrow-right"></i></a>
	<?php endif; ?>
    </div>
</div>
 
<?php print $after_widget; ?>
<?php 
		}
		
		/**
		 * widget function.
		 *
		 * @see WP_Widget
		 * @access public
		 * @param array $instance
		 * @return void
		 */
		public function form($instance){

			$title  = isset($instance['title'])? $instance['title']:'';
			$address  = isset($instance['address'])? $instance['address']:'';
			$address_url  = isset($instance['address_url']['url'])? $instance['address_url']['url']:'';
			$email  = isset($instance['email'])? $instance['email']:'';
			$phone_number  = isset($instance['phone_number'])? $instance['phone_number']:'';
			$phone_number_url  = isset($instance['phone_number_url'])? $instance['phone_number_url']:'';
			$website  = isset($instance['website'])? $instance['website']:'';
			$button_text  = isset($instance['button_text'])? $instance['button_text']:'';
			$button_url  = isset($instance['button_url']['url'])? $instance['button_url']['url']:'';
			?>
<p>
    <label for="title"><?php esc_html_e('Title:','tocore'); ?></label>
</p>
<input type="text" id="<?php print esc_attr($this->get_field_id('title')); ?>"
    name="<?php print esc_attr($this->get_field_name('title')); ?>" class="widefat"
    value="<?php print esc_attr($title); ?>">
	<p>

<label for="title"><?php esc_html_e('Phone Number:','tocore'); ?></label>
</p>
<input type="text" id="<?php print esc_attr($this->get_field_id('phone_number')); ?>"
    name="<?php print esc_attr($this->get_field_name('phone_number')); ?>" class="widefat"
    value="<?php print esc_attr($phone_number); ?>">

<label for="title"><?php esc_html_e('Phone Number Url:','tocore'); ?></label>
</p>
<input type="text" id="<?php print esc_attr($this->get_field_id('phone_number_url')); ?>"
    name="<?php print esc_attr($this->get_field_name('phone_number_url')); ?>" class="widefat"
    value="<?php print esc_attr($phone_number_url); ?>">

<p>
    <label for="title"><?php esc_html_e('Address:','tocore'); ?></label>
</p>
<input type="text" id="<?php print esc_attr($this->get_field_id('address')); ?>"
    name="<?php print esc_attr($this->get_field_name('address')); ?>" class="widefat"
    value="<?php print esc_attr($address); ?>">

	
<p>
    <label for="title"><?php esc_html_e('Address Url:','tocore'); ?></label>
</p>
<input type="url" id="<?php print esc_attr($this->get_field_id('address_url')); ?>"
    name="<?php print esc_attr($this->get_field_name('address_url')); ?>" class="widefat"
    value="<?php print esc_attr($address_url); ?>">

	
<p>
    <label for="title"><?php esc_html_e('Email Address:','tocore'); ?></label>
</p>
<input type="text" id="<?php print esc_attr($this->get_field_id('email')); ?>"
    name="<?php print esc_attr($this->get_field_name('email')); ?>" class="widefat"
    value="<?php print esc_attr($email); ?>">
<p>
    <label for="title"><?php esc_html_e('Button Text:','tocore'); ?></label>
</p>
<input type="text" id="<?php print esc_attr($this->get_field_id('button_text')); ?>"
    name="<?php print esc_attr($this->get_field_name('button_text')); ?>" class="widefat"
    value="<?php print esc_attr($button_text); ?>">
<p>
    <label for="title"><?php esc_html_e('Button Url:','tocore'); ?></label>
</p>
<input type="text" id="<?php print esc_attr($this->get_field_id('button_url')); ?>"
    name="<?php print esc_attr($this->get_field_name('button_url')); ?>" class="widefat"
    value="<?php print esc_attr($button_url); ?>">


<?php
		}
				
		public function update( $new_instance, $old_instance ) {
			$instance = array();
			$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
			$instance['address'] = ( ! empty( $new_instance['address'] ) ) ? strip_tags( $new_instance['address'] ) : '';
			$instance['address_url'] = ( ! empty( $new_instance['address_url'] ) ) ? strip_tags( $new_instance['address_url'] ) : '';
			$instance['email'] = ( ! empty( $new_instance['email'] ) ) ? strip_tags( $new_instance['email'] ) : '';
			$instance['phone_number'] = ( ! empty( $new_instance['phone_number'] ) ) ? strip_tags( $new_instance['phone_number'] ) : '';
			$instance['phone_number_url'] = ( ! empty( $new_instance['phone_number_url'] ) ) ? strip_tags( $new_instance['phone_number_url'] ) : '';
			$instance['button_text'] = ( ! empty( $new_instance['button_text'] ) ) ? strip_tags( $new_instance['button_text'] ) : '';
			$instance['button_url'] = ( ! empty( $new_instance['button_url'] ) ) ? strip_tags( $new_instance['button_url'] ) : '';

			return $instance;
		}
	}