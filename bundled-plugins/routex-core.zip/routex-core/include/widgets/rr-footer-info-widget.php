<?php
	/**
	 * Medidove Footer full Widget
	 *
	 *
	 * @author 		Nilartstudio
	 * @category 	Widgets
	 * @package 	Medidove/Widgets
	 * @version 	1.0.0
	 * @extends 	WP_Widget
	 */
	add_action('widgets_init', 'Medinet_info_Widget');
	function Medinet_info_Widget() {
		register_widget('Medinet_info_Widget');
	}
	
	
	class Medinet_info_Widget  extends WP_Widget{
		
		public function __construct(){
			parent::__construct('Medinet_info_Widget',esc_html__('Footer Info','tocore'),array(
				'description' => esc_html__('Footer Info Widget','tocore'),
			));
		}
		
		public function widget($args, $instance){
			extract($args);
			extract($instance);
			

			 print $before_widget; 
                                 
		        if ( ! empty( $title ) ) {
					print $before_title . apply_filters( 'widget_title', $title ) . $after_title;
				}
		?>

<div class="footer__widget footer__widget-item-1 wow fadeInLeft animated" data-wow-delay=".2s">
    <span class="footer__widget-item-1-location"><img
            src="<?php echo get_template_directory_uri(  ); ?>/assets/imgs/footer/footer1-bg-location-img.png"
            alt="img not found"></span>
    <div class="footer__logo mb-30">
        <a href="<?php print home_url();?>">
            <img src="<?php print $image_box_image;?>" alt="<?php print esc_html__( 'Logo', 'rr-core' );?>">
        </a>
    </div>
    <div class="footer__content">
        <?php if( !empty($description) ): ?>
        <p><?php print $description; ?></p>
        <?php endif; ?>
    </div>

    <div class="footer__social mt-20">
        <?php if( !empty($facebook) ): ?>
        <a href="<?php print esc_url($facebook); ?>"><i class="fab fa-facebook-f"></i></a>
        <?php endif; ?>
        <?php if( !empty($instagram) ): ?>
        <a href="<?php print esc_url($instagram); ?>">
            <i class="fa-brands fa-instagram"></i>
        </a>
        <?php endif; ?>
		<?php if( !empty($linkedin) ): ?>
        <a href="<?php print esc_url($linkedin); ?>"><i class="fab fa-linkedin-in"></i></a>
        <?php endif; ?>

        <?php if( !empty($pinterest) ): ?>
        <a href="<?php print esc_url($pinterest); ?>"><i class="fa-brands fa-pinterest-p"></i></a>
        <?php endif; ?>
    </div>
</div>


<?php print $after_widget; ?>
<?php 
		}
		

		/**
		 * widget function.
		 *
		 * @see WP_Widget
		 * @access public
		 * @param array $instance
		 * @return void
		 */
		public function form($instance){

			$title  = isset($instance['title'])? $instance['title']:'';
			$description  = isset($instance['description'])? $instance['description']:'';
			$author_img  = isset($instance['image_box_image'])? $instance['image_box_image']:'';

			$twitter  = isset($instance['twitter'])? $instance['twitter']:'';
			$facebook  = isset($instance['facebook'])? $instance['facebook']:'';
			$pinterest  = isset($instance['pinterest'])? $instance['pinterest']:'';
			$instagram  = isset($instance['instagram'])? $instance['instagram']:'';
			$linkedin  = isset($instance['linkedin'])? $instance['linkedin']:'';

			?>
<p>
    <label for="title"><?php esc_html_e('Title:','tocore'); ?></label>
</p>
<input type="text" id="<?php print esc_attr($this->get_field_id('title')); ?>"
    name="<?php print esc_attr($this->get_field_name('title')); ?>" value="<?php print esc_attr($title); ?>">
<p>
    <label for="title"><?php esc_html_e('Short Description:','tocore'); ?></label>
</p>

<textarea class="widefat" rows="7" cols="15" id="<?php print esc_attr($this->get_field_id('description')); ?>"
    value="<?php print esc_attr($description); ?>"
    name="<?php print esc_attr($this->get_field_name('description')); ?>"><?php print esc_attr($description); ?></textarea>

<p>
    <button type="submit" class="button button-secondary" id="author_info_image">Upload Media</button>
    <input type="hidden" name="<?php print esc_attr($this->get_field_name('image_box_image')); ?>" class="image_er_link"
        value="<?php print $author_img ; ?>">
<div class="author-image-show">
    <img src="<?php print $author_img ; ?>" alt="" width="150" height="auto">
</div>
</p>

<p>
    <label for="title"><?php esc_html_e('Facebook:','tocore'); ?></label>
</p>
<input type="text" id="<?php print esc_attr($this->get_field_id('facebook')); ?>"
    name="<?php print esc_attr($this->get_field_name('facebook')); ?>" value="<?php print esc_attr($facebook); ?>">


<p>
    <label for="title"><?php esc_html_e('Twitter:','tocore'); ?></label>
</p>
<input type="text" id="<?php print esc_attr($this->get_field_id('twitter')); ?>"
    name="<?php print esc_attr($this->get_field_name('twitter')); ?>" value="<?php print esc_attr($twitter); ?>">

<p>
    <label for="title"><?php esc_html_e('Instagram:','tocore'); ?></label>
</p>
<input type="text" id="<?php print esc_attr($this->get_field_id('instagram')); ?>"
    name="<?php print esc_attr($this->get_field_name('instagram')); ?>" value="<?php print esc_attr($instagram); ?>">
<p>
    <label for="title"><?php esc_html_e('pinterest:','tocore'); ?></label>
</p>
<input type="text" id="<?php print esc_attr($this->get_field_id('pinterest')); ?>"
    name="<?php print esc_attr($this->get_field_name('pinterest')); ?>" value="<?php print esc_attr($pinterest); ?>">

<p>
    <label for="title"><?php esc_html_e('linkedin:','tocore'); ?></label>
</p>
<input type="text" id="<?php print esc_attr($this->get_field_id('linkedin')); ?>"
    name="<?php print esc_attr($this->get_field_name('linkedin')); ?>" value="<?php print esc_attr($linkedin); ?>">

<?php
		}
				
		public function update( $new_instance, $old_instance ) {
			$instance = array();
			$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
			$instance['description'] = ( ! empty( $new_instance['description'] ) ) ? strip_tags( $new_instance['description'] ) : '';

			$instance['facebook'] = ( ! empty( $new_instance['facebook'] ) ) ? strip_tags( $new_instance['facebook'] ) : '';
			$instance['twitter'] = ( ! empty( $new_instance['twitter'] ) ) ? strip_tags( $new_instance['twitter'] ) : '';
			$instance['instagram'] = ( ! empty( $new_instance['instagram'] ) ) ? strip_tags( $new_instance['instagram'] ) : '';
			$instance['pinterest'] = ( ! empty( $new_instance['pinterest'] ) ) ? strip_tags( $new_instance['pinterest'] ) : '';
			$instance['linkedin'] = ( ! empty( $new_instance['linkedin'] ) ) ? strip_tags( $new_instance['linkedin'] ) : '';

			$instance['image_box_image'] = ( ! empty( $new_instance['image_box_image'] ) ) ? strip_tags( $new_instance['image_box_image'] ) : '';

			return $instance;
		}
	}