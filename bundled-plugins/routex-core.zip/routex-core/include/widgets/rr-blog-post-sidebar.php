<?php
	/**
	 * RRCore Sidebar Posts Image
	 *
	 *
	 * @author 		RRDevs
	 * @category 	Widgets
	 * @package 	RRCore/Widgets
	 * @version 	1.0.0
	 * @extends 	WP_Widget
	*/   

Class RR_Post_Sidebar_Widget extends WP_Widget{

	public function __construct(){
		parent::__construct('RR-latest-posts', 'RR Sidebar Posts Image', array(
			'description'	=> 'Latest Blog Post Widget by RRDevs'
		));
	}

	public function widget($args, $instance){
		extract($args);
		extract($instance);

	 echo $before_widget; 
		 if($instance['title']):
		 echo $before_title; ?>
<?php echo apply_filters( 'widget_title', $instance['title'] ); ?>
<?php echo $after_title; ?>
<?php endif; ?>

<div class="sidebar-post__wrapper mt-20">
<?php 
	$q = new WP_Query( array(
		'post_type'     => 'post',
		'posts_per_page'=> ($instance['count']) ? $instance['count'] : '3',
		'order'			=> ($instance['posts_order']) ? $instance['posts_order'] : 'DESC',
		'orderby' => 'comment_count'
	));

	if( $q->have_posts() ):
	while( $q->have_posts() ):$q->the_post();
	?>

    <div class="sidebar-post">
		<?php if ( has_post_thumbnail() ): ?>
        <a class="sidebar-post_thumb"
            href="<?php the_permalink(); ?>"><?php the_post_thumbnail('thumbnail'); ?></a>
        <?php endif; ?>
        <div class="sidebar-post_content">
            <ul class="post-meta">
                <li>
                    <svg width="11" height="13" viewBox="0 0 11 13" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path
                            d="M3.5625 2H6.9375V1.0625C6.9375 0.757812 7.17188 0.5 7.5 0.5C7.80469 0.5 8.0625 0.757812 8.0625 1.0625V2H9C9.82031 2 10.5 2.67969 10.5 3.5V11C10.5 11.8438 9.82031 12.5 9 12.5H1.5C0.65625 12.5 0 11.8438 0 11V3.5C0 2.67969 0.65625 2 1.5 2H2.4375V1.0625C2.4375 0.757812 2.67188 0.5 3 0.5C3.30469 0.5 3.5625 0.757812 3.5625 1.0625V2ZM1.125 6.3125H3V5H1.125V6.3125ZM1.125 7.4375V8.9375H3V7.4375H1.125ZM4.125 7.4375V8.9375H6.375V7.4375H4.125ZM7.5 7.4375V8.9375H9.375V7.4375H7.5ZM9.375 5H7.5V6.3125H9.375V5ZM9.375 10.0625H7.5V11.375H9C9.1875 11.375 9.375 11.2109 9.375 11V10.0625ZM6.375 10.0625H4.125V11.375H6.375V10.0625ZM3 10.0625H1.125V11C1.125 11.2109 1.28906 11.375 1.5 11.375H3V10.0625ZM6.375 5H4.125V6.3125H6.375V5Z"
                            fill="#83CD20"></path>
                    </svg>
					<?php the_time( get_option('date_format') ); ?>
                </li>
            </ul>

            <a href="<?php the_permalink(); ?>">
                <h3 class="title rr-fw-medium"><?php print wp_trim_words(get_the_title(), 5, ''); ?></h3>
            </a>
        </div>
    </div>
    <?php endwhile;            
	endif; ?>
</div>
<?php echo $after_widget; ?>

<?php
}



	public function form($instance){
		$title = ! empty( $instance['title'] ) ? $instance['title'] : '';
		$count = ! empty( $instance['count'] ) ? $instance['count'] : esc_html__( '3', 'rr-core' );
		$posts_order = ! empty( $instance['posts_order'] ) ? $instance['posts_order'] : esc_html__( 'DESC', 'rr-core' );
		$choose_style = ! empty( $instance['choose_style'] ) ? $instance['choose_style'] : esc_html__( 'style_1', 'rr-core' );
	?>
<p>
    <label for="<?php echo $this->get_field_id('title'); ?>">Title</label>
    <input type="text" name="<?php echo $this->get_field_name('title'); ?>"
        id="<?php echo $this->get_field_id('title'); ?>" value="<?php echo esc_attr( $title ); ?>" class="widefat">
</p>

<p>
    <label for="<?php echo $this->get_field_id('count'); ?>">How many posts you want to show ?</label>
    <input type="number" name="<?php echo $this->get_field_name('count'); ?>"
        id="<?php echo $this->get_field_id('count'); ?>" value="<?php echo esc_attr( $count ); ?>" class="widefat">
</p>

<p>
    <label for="<?php echo $this->get_field_id('posts_order'); ?>">Posts Order</label>
    <select name="<?php echo $this->get_field_name('posts_order'); ?>"
        id="<?php echo $this->get_field_id('posts_order'); ?>" class="widefat">
        <option value="" disabled="disabled">Select Post Order</option>
        <option value="ASC" <?php if($posts_order === 'ASC'){ echo 'selected="selected"'; } ?>>ASC</option>
        <option value="DESC" <?php if($posts_order === 'DESC'){ echo 'selected="selected"'; } ?>>DESC</option>
    </select>
</p>

<?php }


}

add_action('widgets_init', function(){
	register_widget('RR_Post_Sidebar_Widget');
});