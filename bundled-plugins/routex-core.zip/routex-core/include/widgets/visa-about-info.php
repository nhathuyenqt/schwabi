<?php
	/**
	 * Visas Footer full Widget
	 *
	 *
	 * @author 		ThemePure
	 * @category 	Widgets
	 * @package 	Visas/Widgets
	 * @version 	1.0.0
	 * @extends 	WP_Widget
	 */
	add_action('widgets_init', 'Visas_offer_Widget');
	function Visas_offer_Widget() {
		register_widget('Visas_offer_Widget');
	}
	
	
	class Visas_offer_Widget  extends WP_Widget{
		
		public function __construct(){
			parent::__construct('Visas_offer_Widget',esc_html__('Visas Touch ','rr-core'),array(
				'description' => esc_html__('Visas About Widget For Touch','rr-core'),
			));
		}
		
		public function widget($args, $instance){
			extract($args);
			extract($instance);

			print $before_widget; 
			?>
<div class="visa-details__widget mt-30 wow fadeInLeft" data-wow-delay=".3s">
    <div class="visa-details__widget-icon">
        <i class="fa-solid fa-phone"></i>
    </div>
    <h3 class="mt-15"><?php echo esc_attr__( 'GET TOUCH', 'rr-core' )?></h3>
    <?php if(!empty($short_description)) : ?>
    <a href="tel:<?php echo esc_html($img_link); ?>"><?php echo esc_html($short_description); ?></a>
    <?php endif; ?>
</div>

<?php print $after_widget; ?>
<?php 
		}
		

		/**
		 * widget function.
		 *
		 * @see WP_Widget
		 * @access public
		 * @param array $instance
		 * @return void
		 */
		public function form($instance){

			//Image
            if ( isset( $instance[ 'sidebar_offer_img' ] ) ) {
                $sidebar_offer_img = $instance[ 'sidebar_offer_img' ];
            }else {
                $sidebar_offer_img = '';
            }

			$short_description = isset($instance['short_description'])? $instance['short_description']:'';
			$img_link = isset($instance['img_link'])? $instance['img_link']:'';

			?>


<!-- short description -->
<p><label for="short_description"><?php esc_html_e('Number :','rr-core'); ?></p>
<textarea class="widefat" cols="15" rows="3" id="<?php echo esc_attr($this->get_field_id('short_description')); ?>"
    name="<?php echo esc_attr($this->get_field_name('short_description')); ?>"><?php print esc_attr($short_description); ?></textarea>

<!-- img url -->
<p><label for="img_url"><?php esc_html_e('Number Link', 'rr-core'); ?></label></p>
<input type="text" class="widefat" id="<?php echo esc_attr($this->get_field_id('img_link')); ?>"
    name="<?php echo esc_attr($this->get_field_name('img_link')); ?>" value="<?php echo esc_attr($img_link); ?>">


<hr>

<script>
jQuery(function($) {
    'use strict';
    /**
     *
     * About Widget About Us upload
     *
     */
    $(function() {
        $(".img_show").css({
            "margin": "0 auto",
            "display": "block",
            "max-width": "80%"
        });
        $(document).on('widget-updated', function(event, widget) {
            var widget_id = $(widget).attr('id');
            if (widget_id.indexOf('mechon_aboutus_widget') != -1) {
                $imgval = $(".img_val").val();
                $(".img_show").attr("src", $imgval);
                $(".img_show").css({
                    "margin": "0 auto",
                    "display": "block",
                    "max-width": "80%"
                });
            }
        });
        $("body").off("click", ".about-up-btn");
        $("body").on("click", ".about-up-btn", function(e) {

            let frame = wp.media({
                title: 'Select or Upload Media About Us',
                button: {
                    text: 'Use this About Us'
                },
                multiple: false
            });

            frame.on("select", function() {
                // Get media attachment details from the frame state
                let $img = frame.state().get('selection').first().toJSON();

                $(".img_show").attr("src", $img.url);
                $(".img_val").val($img.url);

                $(".img_val").trigger('change');

                $(".about-up-btn").text("Change Image");
            });

            // Open Media Modal
            frame.open();
            e.preventDefault();
        });
    });
});
</script>

<?php
		}
				
		public function update( $new_instance, $old_instance ) {
			$instance = array();
			$instance['sidebar_offer_img'] = ( ! empty( $new_instance['sidebar_offer_img'] ) ) ? strip_tags( $new_instance['sidebar_offer_img'] ) : '';
			$instance['short_description'] = ( ! empty( $new_instance['short_description'] ) ) ? strip_tags( $new_instance['short_description'] ) : '';
			$instance['img_link'] = ( ! empty( $new_instance['img_link'] ) ) ? strip_tags( $new_instance['img_link'] ) : '';
			$instance['fb_link'] = ( ! empty( $new_instance['fb_link'] ) ) ? strip_tags( $new_instance['fb_link'] ) : '';
			$instance['tw_link'] = ( ! empty( $new_instance['tw_link'] ) ) ? strip_tags( $new_instance['tw_link'] ) : '';
			$instance['ig_link'] = ( ! empty( $new_instance['ig_link'] ) ) ? strip_tags( $new_instance['ig_link'] ) : '';
			$instance['ld_link'] = ( ! empty( $new_instance['ld_link'] ) ) ? strip_tags( $new_instance['ld_link'] ) : '';
			$instance['yt_link'] = ( ! empty( $new_instance['yt_link'] ) ) ? strip_tags( $new_instance['yt_link'] ) : '';
			return $instance;
		}
	}