<?php
	/**
	 * Medidove Footer full Widget
	 *
	 *
	 * @author 		Nilartstudio
	 * @category 	Widgets
	 * @package 	Medidove/Widgets
	 * @version 	1.0.0
	 * @extends 	WP_Widget
	 */
add_action( 'widgets_init', function () {
    register_widget( 'Routex_sidebar_instagram_post' );
} );

class Routex_sidebar_instagram_post extends WP_Widget {

    public function __construct() {

        parent::__construct( 'Routex_sidebar_instagram_post', esc_html__( 'Routex Sidebar instagram Post', 'rr-core' ), array(
            'description' => esc_html__( 'Show Sidebar instagram Post Widget By Artima', 'rr-core' ),

        ) );
    }

    public function widget( $args, $instance ) {

        extract( $args );

        extract( $instance );

        print $before_widget;

        if ( !empty( $title ) ) {

            print $before_title . apply_filters( 'widget_title', $title ) . $after_title;

        }

        ?>
<div class="rr-footer-3__widget-gallery-wrap">
    <div class="row gx-5">
    <?php if ( !empty( $gallery_img_1 ) ): ?>
        <div class="col-xl-4 col-lg-4 col-md-4 col-4 p-1">
            <div class="rr-footer__widget-gallery p-relative">
                <a href="<?php print $gallery_img_1;?>" class="our-gallery__item popup-image">
                    <img src="<?php print $gallery_img_1;?>" alt="<?php print esc_html__( 'instagram Post', 'rr-core' );?>">
                    <span><i class="fa-solid fa-plus"></i></span>
                </a>
            </div>
        </div>
        <?php endif; ?>
        <?php if ( !empty( $gallery_img_2 ) ): ?>
        <div class="col-xl-4 col-lg-4 col-md-4 col-4  p-1">
            <div class="rr-footer__widget-gallery p-relative">
                <a href="<?php print $gallery_img_2;?>" class="our-gallery__item popup-image">
                    <img src="<?php print $gallery_img_2;?>" alt="<?php print esc_html__( 'instagram Post', 'rr-core' );?>">
                    <span><i class="fa-solid fa-plus"></i></span>
                </a>
            </div>
        </div>
        <?php endif; ?>
        <?php if ( !empty( $gallery_img_3 ) ): ?>
        <div class="col-xl-4 col-lg-4 col-md-4 col-4  p-1">
            <div class="rr-footer__widget-gallery p-relative">
                <a href="<?php print $gallery_img_3;?>" class="our-gallery__item popup-image">
                    <img src="<?php print $gallery_img_3;?>" alt="<?php print esc_html__( 'instagram Post', 'rr-core' );?>">
                    <span><i class="fa-solid fa-plus"></i></span>
                </a>
            </div>
        </div>
        <?php endif; ?>
        <?php if ( !empty( $gallery_img_4 ) ): ?>
        <div class="col-xl-4 col-lg-4 col-md-4 col-4  p-1">
            <div class="rr-footer__widget-gallery p-relative">
                <a href="<?php print $gallery_img_4;?>" class="our-gallery__item popup-image">
                    <img src="<?php print $gallery_img_4;?>" alt="<?php print esc_html__( 'instagram Post', 'rr-core' );?>">
                    <span><i class="fa-solid fa-plus"></i></span>
                </a>
            </div>
        </div>
        <?php endif; ?>
        <?php if ( !empty( $gallery_img_5 ) ): ?>
        <div class="col-xl-4 col-lg-4 col-md-4 col-4  p-1">
            <div class="rr-footer__widget-gallery p-relative">
                <a href="<?php print $gallery_img_5;?>" class="our-gallery__item popup-image">
                    <img src="<?php print $gallery_img_5;?>" alt="<?php print esc_html__( 'instagram Post', 'rr-core' );?>">
                    <span><i class="fa-solid fa-plus"></i></span>
                </a>
            </div>
        </div>
        <?php endif; ?>
        <?php if ( !empty( $gallery_img_6 ) ): ?>
        <div class="col-xl-4 col-lg-4 col-md-4 col-4  p-1">
            <div class="rr-footer__widget-gallery p-relative">
                <a href="<?php print $gallery_img_6;?>" class="our-gallery__item popup-image">
                    <img src="<?php print $gallery_img_6;?>" alt="<?php print esc_html__( 'instagram Post', 'rr-core' );?>">
                    <span><i class="fa-solid fa-plus"></i></span>
                </a>
            </div>
        </div>
        <?php endif; ?>
    </div>
</div>


<?php print $after_widget;?>

<?php

    }

    /**
     * widget function.
     *
     * @see WP_Widget
     * @access public
     * @param array $instance
     * @return void
     */

    public function form( $instance ) {

        $title = isset( $instance['title'] ) ? $instance['title'] : '';

        $gallery_img_1 = isset( $instance['gallery_img_1'] ) ? $instance['gallery_img_1'] : '';
        $gallery_img_2 = isset( $instance['gallery_img_2'] ) ? $instance['gallery_img_2'] : '';
        $gallery_img_3 = isset( $instance['gallery_img_3'] ) ? $instance['gallery_img_3'] : '';
        $gallery_img_4 = isset( $instance['gallery_img_4'] ) ? $instance['gallery_img_4'] : '';
        $gallery_img_5 = isset( $instance['gallery_img_5'] ) ? $instance['gallery_img_5'] : '';
        $gallery_img_6 = isset( $instance['gallery_img_6'] ) ? $instance['gallery_img_6'] : '';
		$instagram  = isset($instance['instagram'])? $instance['instagram']:'';
		$instagram_2  = isset($instance['instagram_2'])? $instance['instagram_2']:'';
		$instagram_3  = isset($instance['instagram_3'])? $instance['instagram_3']:'';
		$instagram_4  = isset($instance['instagram_4'])? $instance['instagram_4']:'';

        ?>

<p>
    <label for="title"><?php esc_html_e( 'Title:', 'rr-core' );?></label>
    <input type="text" class="widefat" id="<?php print esc_attr( $this->get_field_id( 'title' ) );?>"
        name="<?php print esc_attr( $this->get_field_name( 'title' ) );?>" value="<?php print esc_attr( $title );?>">
</p>

<p>
    <button type="submit" class="button button-secondary" id="author_info_image">Upload Media</button>
    <input type="hidden" name="<?php print esc_attr( $this->get_field_name( 'gallery_img_1' ) );?>"
        class="image_er_link" value="<?php print $gallery_img_1;?>">
<div class="author-image-show">
    <img src="<?php print $gallery_img_1;?>" alt="" width="150" height="auto">
</div>
</p>




<p>
    <button type="submit" class="button button-secondary" id="author_info_image">Upload Media</button>
    <input type="hidden" name="<?php print esc_attr( $this->get_field_name( 'gallery_img_2' ) );?>"
        class="image_er_link" value="<?php print $gallery_img_2;?>">
<div class="author-image-show">
    <img src="<?php print $gallery_img_2;?>" alt="" width="150" height="auto">
</div>
</p>

<p>
    <button type="submit" class="button button-secondary" id="author_info_image">Upload Media</button>
    <input type="hidden" name="<?php print esc_attr( $this->get_field_name( 'gallery_img_3' ) );?>"
        class="image_er_link" value="<?php print $gallery_img_3;?>">
<div class="author-image-show">
    <img src="<?php print $gallery_img_3;?>" alt="" width="150" height="auto">
</div>
</p>

<p>
    <button type="submit" class="button button-secondary" id="author_info_image">Upload Media</button>
    <input type="hidden" name="<?php print esc_attr( $this->get_field_name( 'gallery_img_4' ) );?>"
        class="image_er_link" value="<?php print $gallery_img_4;?>">
<div class="author-image-show">
    <img src="<?php print $gallery_img_4;?>" alt="" width="150" height="auto">
</div>
</p>

<p>
    <button type="submit" class="button button-secondary" id="author_info_image">Upload Media</button>
    <input type="hidden" name="<?php print esc_attr( $this->get_field_name( 'gallery_img_5' ) );?>"
        class="image_er_link" value="<?php print $gallery_img_5;?>">
<div class="author-image-show">
    <img src="<?php print $gallery_img_5;?>" alt="" width="150" height="auto">
</div>
</p>

<p>
    <button type="submit" class="button button-secondary" id="author_info_image">Upload Media</button>
    <input type="hidden" name="<?php print esc_attr( $this->get_field_name( 'gallery_img_6' ) );?>"
        class="image_er_link" value="<?php print $gallery_img_6;?>">
<div class="author-image-show">
    <img src="<?php print $gallery_img_6;?>" alt="" width="150" height="auto">
</div>
</p>

<?php

    }

    public function update( $new_instance, $old_instance ) {

        $instance = array();

        $instance['title'] = ( !empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';

        $instance['gallery_img_1'] = ( !empty( $new_instance['gallery_img_1'] ) ) ? strip_tags( $new_instance['gallery_img_1'] ) : '';
        $instance['gallery_img_2'] = ( !empty( $new_instance['gallery_img_2'] ) ) ? strip_tags( $new_instance['gallery_img_2'] ) : '';
        $instance['gallery_img_3'] = ( !empty( $new_instance['gallery_img_3'] ) ) ? strip_tags( $new_instance['gallery_img_3'] ) : '';
        $instance['gallery_img_4'] = ( !empty( $new_instance['gallery_img_4'] ) ) ? strip_tags( $new_instance['gallery_img_4'] ) : '';
        $instance['gallery_img_5'] = ( !empty( $new_instance['gallery_img_5'] ) ) ? strip_tags( $new_instance['gallery_img_5'] ) : '';
        $instance['gallery_img_6'] = ( !empty( $new_instance['gallery_img_6'] ) ) ? strip_tags( $new_instance['gallery_img_6'] ) : '';
		
		$instance['instagram'] = ( ! empty( $new_instance['instagram'] ) ) ? strip_tags( $new_instance['instagram'] ) : '';
		$instance['instagram_2'] = ( ! empty( $new_instance['instagram_2'] ) ) ? strip_tags( $new_instance['instagram_2'] ) : '';
		$instance['instagram_3'] = ( ! empty( $new_instance['instagram_3'] ) ) ? strip_tags( $new_instance['instagram_3'] ) : '';
		$instance['instagram_4'] = ( ! empty( $new_instance['instagram_4'] ) ) ? strip_tags( $new_instance['instagram_4'] ) : '';
        return $instance;

    }

}