<?php
namespace RRCore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Repeater;
use \Elementor\Utils;
use RRCore\Elementor\Controls\Group_Control_RRBGGradient;
use RRCore\Elementor\Controls\Group_Control_RRGradient;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * RR Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class RR_Service extends Widget_Base {

    use \RRCore\Widgets\RRCoreElementFunctions;

    /**
     * Retrieve the widget name.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name() {
        return 'rr_service';
    }

    /**
     * Retrieve the widget title.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title() {
        return __( 'RR Service', 'rr-core' );
    }

    /**
     * Retrieve the widget icon.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'rr-icon';
    }

    /**
     * Retrieve the list of categories the widget belongs to.
     *
     * Used to determine where to display the widget in the editor.
     *
     * Note that currently Elementor supports only one category.
     * When multiple categories passed, Elementor uses the first one.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return array Widget categories.
     */
    public function get_categories() {
        return [ 'rr-core' ];
    }

    /**
     * Retrieve the list of scripts the widget depended on.
     *
     * Used to set scripts dependencies required to run the widget.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return array Widget scripts dependencies.
     */
    public function get_script_depends() {
        return [ 'rr-core' ];
    }

    /**
     * Register the widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     *
     * @access protected
     */

    protected function register_controls(){
        $this->register_controls_section();
        $this->style_tab_content();
    }
    protected function register_controls_section() {

        // layout Panel
        $this->start_controls_section(
            'rr_layout',
            [
                'label' => esc_html__('Design Layout', 'rr-core'),
            ]
        );
        $this->add_control(
            'rr_design_style',
            [
                'label' => esc_html__('Select Layout', 'rr-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Layout 1', 'rr-core'),
                    'layout-2' => esc_html__('Layout 2', 'rr-core'),
                    'layout-3' => esc_html__('Layout 3', 'rr-core'),
                    'layout-4' => esc_html__('Layout 4', 'rr-core'),
                    'layout-5' => esc_html__('Layout 5', 'rr-core'),
                    'layout-6' => esc_html__('Layout 6', 'rr-core'),
                    'layout-7' => esc_html__('Layout 7', 'rr-core'),
                ],
                'default' => 'layout-1',
            ]
        );

        $this->end_controls_section();

        // title/content
        $this->rr_section_title_render_controls('section', 'Section Title', 'Sub Title', 'your title here', $default_description = 'Hic nesciunt galisum aut dolorem aperiam eum soluta quod ea cupiditate.', ['layout-2', 'layout-3', 'layout-4', 'layout-5', 'layout-7'] );
    // button
    $this->rr_button_render('services', 'Button', ['layout-2']);
        // Service group
        $this->start_controls_section( 
            'rr_services',
            [
                'label' => esc_html__('Services List', 'rr-core'),
                'description' => esc_html__( 'Control all the style settings from Style tab', 'rr-core' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'repeater_condition',
            [
                'label' => __( 'Field condition', 'rr-core' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'style_1' => __( 'Style 1', 'rr-core' ),
                    'style_2' => __( 'Style 2', 'rr-core' ),
                    'style_3' => __( 'Style 3', 'rr-core' ),
                ],
                'default' => 'style_1',
                'frontend_available' => true,
                'style_transfer' => true,
            ]
        );

        $repeater->add_control(
            'rr_service_icon_type',
            [
                'label' => esc_html__('Select Icon Type', 'rr-core'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'icon',
                'options' => [
                    'image' => esc_html__('Image', 'rr-core'),
                    'icon' => esc_html__('Icon', 'rr-core'),
                    'svg' => esc_html__('SVG', 'rr-core'),
                ],
            ]
        );

        $repeater->add_control(
            'rr_service_image',
            [
                'label' => esc_html__('Upload Icon Image', 'rr-core'),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
                'condition' => [
                    'rr_service_icon_type' => 'image'
                ]

            ]
        );

        if (rr_is_elementor_version('<', '2.6.0')) {
            $repeater->add_control(
                'rr_service_icon',
                [
                    'show_label' => false,
                    'type' => Controls_Manager::ICON,
                    'label_block' => true,
                    'default' => 'fa fa-star',
                    'condition' => [
                        'rr_service_icon_type' => 'icon'
                    ]
                ]
            );
        } else {
            $repeater->add_control(
                'rr_service_selected_icon',
                [
                    'show_label' => false,
                    'type' => Controls_Manager::ICONS,
                    'fa4compatibility' => 'icon',
                    'label_block' => true,
                    'default' => [
                        'value' => 'fas fa-star',
                        'library' => 'solid',
                    ],
                    'condition' => [
                        'rr_service_icon_type' => 'icon'
                    ]
                ]
            );
        }

        $repeater->add_control(
            'rr_service_icon_svg',
            [
                'show_label' => false,
                'type' => Controls_Manager::TEXTAREA,
                'label_block' => true,
                'placeholder' => esc_html__('SVG Code Here', 'rr-core'),
                'condition' => [
                    'rr_service_icon_type' => 'svg',
                ]
            ]
        );

        $repeater->add_control(
            'rr_service_cat', [
                'label' => esc_html__('Cat Field', 'rr-core'),
                'description' => rr_get_allowed_html_desc( 'basic' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('visa', 'rr-core'),
                'condition' => [
                    'repeater_condition' => 'style_2'
                ]
            ]
        );
    
        $repeater->add_control(
            'rr_service_image_thumb',
            [
                'label' => esc_html__( 'Choose Thumbnail Image', 'rr-core' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
                'condition' => [
                    'repeater_condition' => 'style_3'
                ]
            ]
        );

        $repeater->add_group_control(
            Group_Control_Image_Size::get_type(),
            [
                'name' => 'rr_image_size',
                'default' => 'full',
                'exclude' => [
                    'custom'
                ] ,
                'condition' => [
                    'repeater_condition' => 'style_3'
                ]
            ]
        );
        $repeater->add_control(
            'rr_service_title', [
                'label' => esc_html__('Title', 'rr-core'),
                'description' => rr_get_allowed_html_desc( 'basic' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('Service Title', 'rr-core'),
                'label_block' => true,
            ]
        );

        $repeater->add_control(
            'rr_service_description',
            [
                'label' => esc_html__('Description', 'rr-core'),
                'description' => rr_get_allowed_html_desc( 'intermediate' ),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'default' => esc_html__('There are many variations of passages of Lorem Ipsum available, but the majority have suffered.', 'rr-core'),
                'label_block' => true,
            ]
        );

        $repeater->add_control(
            'rr_services_link_switcher',
            [
                'label' => esc_html__( 'Add Services link', 'rr-core' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Yes', 'rr-core' ),
                'label_off' => esc_html__( 'No', 'rr-core' ),
                'return_value' => 'yes',
                'default' => 'yes',
                'separator' => 'before',
            ]
        );

        $repeater->add_control(
            'rr_services_link_type',
            [
                'label' => esc_html__( 'Service Link Type', 'rr-core' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    '1' => 'Custom Link',
                    '2' => 'Internal Page',
                ],
                'default' => '1',
                'condition' => [
                    'rr_services_link_switcher' => 'yes'
                ]
            ]
        );

        $repeater->add_control(
            'rr_services_link',
            [
                'label' => esc_html__( 'Service Link link', 'rr-core' ),
                'type' => \Elementor\Controls_Manager::URL,
                'dynamic' => [
                    'active' => true,
                ],
                'placeholder' => esc_html__( 'htrrs://your-link.com', 'rr-core' ),
                'show_external' => true,
                'default' => [
                    'url' => '#',
                    'is_external' => false,
                    'nofollow' => false,
                ],
                'condition' => [
                    'rr_services_link_type' => '1',
                    'rr_services_link_switcher' => 'yes',
                ]
            ]
        );

        $repeater->add_control(
            'rr_services_page_link',
            [
                'label' => esc_html__( 'Select Service Link Page', 'rr-core' ),
                'type' => \Elementor\Controls_Manager::SELECT2,
                'label_block' => true,
                'options' => rr_get_all_pages(),
                'condition' => [
                    'rr_services_link_type' => '2',
                    'rr_services_link_switcher' => 'yes',
                ]
            ]
        );
        $repeater->add_control(
            'rr_service_btn', [
                'label' => esc_html__('Button', 'rr-core'),
                'description' => rr_get_allowed_html_desc( 'basic' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('Read More', 'rr-core'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'rr_service_list',
            [
                'label' => esc_html__('Services - List', 'rr-core'),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'rr_service_title' => esc_html__('Business Stratagy', 'rr-core'),
                    ],
                    [
                        'rr_service_title' => esc_html__('Website Development', 'rr-core')
                    ],
                    [
                        'rr_service_title' => esc_html__('Marketing & Reporting', 'rr-core')
                    ]
                ],
                'title_field' => '{{{ rr_service_title }}}',
            ]
        );
        $this->end_controls_section();
        
        // thumbnail image
        $this->start_controls_section(
            'rr_thumbnail_section',
                [
                    'label' => esc_html__( 'Thumbnail', 'rr-core' ),
                    'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
                    'condition' => [
                        'rr_design_style' => ['layout-2', 'layout-3'],
                    ],
                ], 
            );
    
            $this->add_control(
                'rr_image_thumb',
                [
                    'label' => esc_html__( 'Choose Thumbnail Image', 'rr-core' ),
                    'type' => \Elementor\Controls_Manager::MEDIA,
                    'default' => [
                        'url' => \Elementor\Utils::get_placeholder_image_src(),
                    ],
                ]
            );

  
            $this->add_group_control(
                Group_Control_Image_Size::get_type(),
                [
                    'name' => 'rr_image_size',
                    'default' => 'full',
                    'exclude' => [
                        'custom'
                    ] 
                ]
            );

            $this->end_controls_section();
    

        // section column
        $this->rr_columns('col', ['layout-1', 'layout-2', 'layout-4', 'layout-6']);

    }

    // style_tab_content
    protected function style_tab_content(){

        $this->rr_section_style_controls('services_section', 'Section Style', '.ele-section');
        $this->rr_basic_style_controls('section_sub_title', 'Section - Sub Title', '.rr-el-sub-title');
        $this->rr_basic_style_controls('section_title', 'Section - Title', '.rr-el-title');
        $this->rr_basic_style_controls('services_title', 'Services Title', '.rr-el-re-Title');
        $this->rr_basic_style_controls('services_desc', 'Services Description', '.rr-el-re-dec');
        $this->rr_link_controls_style('repiter_icon', 'Services - Icon', '.rr-el-icon');
        $this->rr_link_controls_style('repiter_btn', 'services - Button', '.rr-el-btn');
        $this->rr_section_style_controls('services_box', 'Services Box', '.services-box');
        
    }

    /**
     * Render the widget ourrut on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     * 
     * @since 1.0.0
     *
     * @access protected
     */
    protected function render() {
        $settings = $this->get_settings_for_display();

        ?>

<?php if ( $settings['rr_design_style']  == 'layout-2' ):

if ( !empty($settings['rr_image_thumb']['url']) ) {
    $rr_image_thumb = !empty($settings['rr_image_thumb']['id']) ? wp_get_attachment_image_url( $settings['rr_image_thumb']['id'], $settings['rr_image_size_size']) : $settings['rr_image_thumb']['url'];
    $rr_image_alt = get_post_meta($settings["rr_image_thumb"]["id"], "_wp_attachment_image_alt", true);
}     
    // Link
    if ('2' == $settings['rr_services_btn_link_type']) {
        $this->add_render_attribute('rr-button-arg', 'href', get_permalink($settings['rr_services_btn_page_link']));
        $this->add_render_attribute('rr-button-arg', 'target', '_self');
        $this->add_render_attribute('rr-button-arg', 'rel', 'nofollow');
        $this->add_render_attribute('rr-button-arg', 'class', 'rr-btn');
    } else {
        if ( ! empty( $settings['rr_services_btn_link']['url'] ) ) {
            $this->add_link_attributes( 'rr-button-arg', $settings['rr_services_btn_link'] );
            $this->add_render_attribute('rr-button-arg', 'class', 'rr-btn');
        }
    }
    // Link
    if ('2' == $settings['rr_services_btn_link_type']) {
        $this->add_render_attribute('rr-button-arg', 'href', get_permalink($settings['rr_services_btn_page_link']));
        $this->add_render_attribute('rr-button-arg', 'target', '_self');
        $this->add_render_attribute('rr-button-arg', 'rel', 'nofollow');
        $this->add_render_attribute('rr-button-arg', 'class', 'rr-btn wow rrfadeUp rr-el-btn');
    } else {
        if ( ! empty( $settings['rr_services_btn_link']['url'] ) ) {
            $this->add_link_attributes( 'rr-button-arg', $settings['rr_services_btn_link'] );
            $this->add_render_attribute('rr-button-arg', 'class', 'rr-btn wow rrfadeUp rr-el-btn');
        }
    }
    $this->add_render_attribute('title_args', 'class', 'section-title2__wrapper-title  wow fadeInLeft animated rr-el-title');
?>

<section class="visa-catagory__area section-space gray-bg overflow-hidden position-relative ele-section">
    <div class="container">
        <?php if ( !empty($settings['rr_section_section_title_show']) ) : ?>
        <div class="section-title2 mb-60">
            <div class="section-title2__wrapper">
                <?php if ( !empty($settings['rr_section_sub_title']) ) : ?>
                <span class="section-title2__wrapper-subtitle wow fadeInLeft animated rr-el-sub-title"
                    data-wow-delay=".2s"><?php echo rr_kses( $settings['rr_section_sub_title'] ); ?>
                    <svg width="52" height="10" viewBox="0 0 52 10" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <g clip-path="url(#clip0_3795_118)">
                            <path
                                d="M47.2105 2.14437C46.4106 2.36766 45.5884 2.50135 44.759 2.54299L38.0755 3.26714C36.5634 3.43986 35.0723 3.76256 33.6242 4.23048C32.835 4.49614 32.0757 4.84349 31.3587 5.2669C30.5825 5.78994 29.7749 6.26475 28.9404 6.68864C28.4375 6.92402 27.8878 7.04215 27.3326 7.03411C26.7214 6.99856 26.1435 6.7438 25.7049 6.3166C24.8612 5.44628 24.6287 4.38993 24.0772 3.71228C23.8491 3.37951 23.506 3.14288 23.1139 3.04791C22.6936 2.95474 22.2553 2.98472 21.8516 3.13427C20.9452 3.46398 20.1849 4.10423 19.7057 4.94135C19.1277 5.79839 18.6759 6.775 18.0182 7.69183C17.3781 8.67698 16.4295 9.42226 15.3209 9.81116C14.739 9.97733 14.1223 9.97733 13.5404 9.81116C12.9891 9.64765 12.4808 9.36403 12.0522 8.9807C11.2858 8.27735 10.6885 7.40973 10.3049 6.44282C9.91959 5.55257 9.64054 4.68889 9.25521 3.93151C8.81334 2.89622 8.01098 2.05634 6.99695 1.56765C5.98293 1.07897 4.82607 0.974642 3.74097 1.27404C3.16462 1.41933 2.62589 1.6859 2.16075 2.05594C1.69561 2.42599 1.31477 2.89102 1.04364 3.41996C0.610002 4.23627 0.403487 5.15404 0.445698 6.07742C0.462342 6.66905 0.588506 7.25247 0.817762 7.79813C0.970566 8.18346 1.07686 8.37613 1.04364 8.40271C1.01043 8.42928 0.850974 8.26318 0.62509 7.89778C0.298973 7.3528 0.0970721 6.74258 0.0337932 6.11063C-0.0934455 5.09968 0.0725961 4.07346 0.512138 3.1542C0.79995 2.52884 1.21882 1.97266 1.74037 1.52332C2.26192 1.07399 2.87396 0.742013 3.53502 0.549886C4.34237 0.314234 5.19223 0.262331 6.02226 0.397987C6.85229 0.533642 7.64143 0.85342 8.33175 1.33384C9.08289 1.89515 9.68508 2.63192 10.0857 3.47975C10.5175 4.31021 10.8231 5.18716 11.2018 6.01762C11.536 6.84506 12.054 7.58567 12.7166 8.18347C13.0189 8.47409 13.3917 8.68086 13.7983 8.78339C14.2049 8.88592 14.6313 8.88064 15.0352 8.7681C15.9067 8.44143 16.6499 7.84273 17.1545 7.06068C17.7325 6.2568 18.1843 5.28018 18.8155 4.33678C19.1365 3.84764 19.5182 3.40117 19.9515 3.00804C20.4081 2.61118 20.9387 2.30862 21.5128 2.11779C22.1052 1.91517 22.7422 1.88068 23.3531 2.01814C23.9729 2.17131 24.5187 2.53834 24.8944 3.05455C25.5986 3.99795 25.8378 5.04765 26.4092 5.5725C26.6685 5.83263 27.0128 5.99065 27.3791 6.01762C27.7827 6.02071 28.1821 5.9345 28.5484 5.76517C29.3507 5.36762 30.1293 4.92396 30.8804 4.43644C31.658 3.99071 32.4823 3.632 33.3385 3.36681C34.8537 2.91365 36.4126 2.62192 37.9891 2.49649C40.8459 2.25731 43.1379 2.18423 44.7324 2.1045C45.5574 2.02614 46.3885 2.03952 47.2105 2.14437Z"
                                fill="#034833" />
                            <path
                                d="M45.4762 6.2697C45.4231 6.13018 46.1406 5.7382 47.2235 5.08712C47.7683 4.76158 48.4127 4.36296 49.1036 3.89126C49.4491 3.65873 49.768 3.39963 50.1666 3.13388C50.3373 3.0178 50.4954 2.88421 50.6383 2.73527C50.7579 2.61795 50.8527 2.47789 50.9173 2.32336C50.9506 2.19713 50.9173 2.20377 50.9173 2.15726C50.821 2.06916 50.7009 2.01139 50.5719 1.99117L49.283 1.64571C48.4592 1.41982 47.7218 1.20058 47.1039 0.981341C45.8682 0.582721 45.1108 0.263819 45.1573 0.124302C45.2038 -0.0152149 46.001 0.0379361 47.2833 0.250534C47.9476 0.356832 48.6784 0.502993 49.5155 0.675728L50.8443 0.968051C51.184 1.02987 51.4955 1.19726 51.7345 1.4464C51.8826 1.61431 51.9774 1.82242 52.0069 2.04432C52.0341 2.24825 52.0113 2.45574 51.9405 2.6489C51.8291 2.94985 51.6521 3.2222 51.4223 3.44614C51.235 3.63879 51.0254 3.80831 50.7978 3.95105C50.4124 4.23009 50.0205 4.47591 49.6484 4.70179C48.9845 5.09883 48.2916 5.44528 47.5756 5.7382C46.3399 6.25641 45.5294 6.40257 45.4762 6.2697Z"
                                fill="#034833" />
                        </g>
                        <defs>
                            <clipPath id="clip0_3795_118">
                                <rect width="52" height="9.86585" fill="white" transform="translate(0 0.0664062)" />
                            </clipPath>
                        </defs>
                    </svg>
                </span>
                <?php endif; ?>
                <?php
                if ( !empty($settings['rr_section_title' ]) ) :
                    printf( '<%1$s %2$s>%3$s</%1$s>',
                    tag_escape( $settings['rr_section_title_tag'] ),
                    $this->get_render_attribute_string( 'title_args' ),
                    rr_kses( $settings['rr_section_title' ] )
                    );
                endif;
                ?>
            </div>
            <div class="section-title2__button wow fadeInLeft animated" data-wow-delay=".4s">
                <?php if ( !empty($settings['rr_services_btn_text']) ) : ?>
                <a <?php echo $this->get_render_attribute_string( 'rr-button-arg' ); ?>><?php echo rr_kses($settings['rr_services_btn_text']); ?>
                    <i class="fa-solid fa-arrow-right"></i></a>
                <?php endif; ?>
            </div>
        </div>
        <?php endif; ?>
        <div class="row">
            <div class="col-lg-8">
                <div class="row mb-minus-30">
                    <?php foreach ($settings['rr_service_list'] as $key => $item) :

                    if ('2' == $item['rr_services_link_type']) {
                        $link = get_permalink($item['rr_services_page_link']);
                        $target = '_self';
                        $rel = 'nofollow';
                    } else {
                        $link = !empty($item['rr_services_link']['url']) ? $item['rr_services_link']['url'] : '';
                        $target = !empty($item['rr_services_link']['is_external']) ? '_blank' : '';
                        $rel = !empty($item['rr_services_link']['nofollow']) ? 'nofollow' : '';
                    }
                ?>
                    <div
                        class="col-xl-<?php echo esc_attr($settings['rr_col_for_desktop']); ?> col-lg-<?php echo esc_attr($settings['rr_col_for_laptop']); ?> col-md-<?php echo esc_attr($settings['rr_col_for_tablet']); ?> col-<?php echo esc_attr($settings['rr_col_for_mobile']); ?>">
                        <div class="visa-catagory__item mb-3 wow fadeInLeft animated services-box" data-wow-delay=".3s">
                            <div class="visa-catagory__item-icon rr-el-icon">
                                <?php if($item['rr_service_icon_type'] == 'icon') : ?>
                                <?php if (!empty($item['rr_service_icon']) || !empty($item['rr_service_selected_icon']['value'])) : ?>
                                <span>
                                    <?php rr_render_icon($item, 'rr_service_icon', 'rr_service_selected_icon'); ?>
                                </span>
                                <?php endif; ?>
                                <?php elseif( $item['rr_service_icon_type'] == 'image' ) : ?>
                                <?php if (!empty($item['rr_service_image']['url'])): ?>
                                <span>
                                    <img src="<?php echo $item['rr_service_image']['url']; ?>"
                                        alt="<?php echo get_post_meta(attachment_url_to_postid($item['rr_service_image']['url']), '_wp_attachment_image_alt', true); ?>">
                                </span>
                                <?php endif; ?>
                                <?php else : ?>
                                <?php if (!empty($item['rr_service_icon_svg'])): ?>
                                <span>
                                    <?php echo $item['rr_service_icon_svg']; ?>
                                </span>
                                <?php endif; ?>
                                <?php endif; ?>
                            </div>
                            <div class="visa-catagory__item-content">
                                <?php if (!empty($item['rr_service_cat'])): ?>
                                <span><?php echo rr_kses($item['rr_service_cat']); ?></span>
                                <?php endif; ?>
                                <h3 class="visa-catagory__title rr-el-re-Title">
                                    <?php if ($item['rr_services_link_switcher'] == 'yes') : ?> <a
                                        href="<?php echo esc_url($link); ?>">
                                        <?php echo rr_kses($item['rr_service_title' ]); ?></a>
                                    <?php else : ?>
                                    <?php echo rr_kses($item['rr_service_title' ]); ?>
                                    <?php endif; ?>
                                </h3>
                                <?php if (!empty($item['rr_service_description' ])): ?>
                                <p class="rr-el-re-dec"><?php echo rr_kses($item['rr_service_description']); ?></p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 col-sm-6">
                <div class="visa-catagory__thumb wow fadeInLeft animated" data-wow-delay=".7s">
                    <div class="visa-catagory__thumb-media" data-tilt>
                        <?php if(!empty($rr_image_thumb)) : ?>
                        <img src="<?php echo esc_url($rr_image_thumb); ?>" alt="<?php echo esc_attr($rr_image_alt); ?>">
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php elseif ( $settings['rr_design_style']  == 'layout-3' ):

if ( !empty($settings['rr_image_thumb']['url']) ) {
    $rr_image_thumb = !empty($settings['rr_image_thumb']['id']) ? wp_get_attachment_image_url( $settings['rr_image_thumb']['id'], $settings['rr_image_size_size']) : $settings['rr_image_thumb']['url'];
    $rr_image_alt = get_post_meta($settings["rr_image_thumb"]["id"], "_wp_attachment_image_alt", true);
}     
    // Link
    if ('2' == $settings['rr_services_btn_link_type']) {
        $this->add_render_attribute('rr-button-arg', 'href', get_permalink($settings['rr_services_btn_page_link']));
        $this->add_render_attribute('rr-button-arg', 'target', '_self');
        $this->add_render_attribute('rr-button-arg', 'rel', 'nofollow');
        $this->add_render_attribute('rr-button-arg', 'class', 'rr-btn');
    } else {
        if ( ! empty( $settings['rr_services_btn_link']['url'] ) ) {
            $this->add_link_attributes( 'rr-button-arg', $settings['rr_services_btn_link'] );
            $this->add_render_attribute('rr-button-arg', 'class', 'rr-btn');
        }
    }
    $this->add_render_attribute('title_args', 'class', 'section-slider-title-4-wrapper-title wow fadeInLeft animated rr-el-title');
?>
<section class="service__area custom-width p-relative border overflow-hidden gray-bg ele-section">
    <?php if(!empty($rr_image_thumb)) : ?>
        <div class="service__bg-wrap">
            <div class="service__bg-img" data-background="<?php echo esc_url($rr_image_thumb); ?>"></div>
        </div>
    <?php endif; ?>
    <div class="section-space p-relative overflow-hidden">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <?php if ( !empty($settings['rr_section_section_title_show']) ) : ?>
                    <div class="section-slider-title-4 mb-60">
                        <div class="section-slider-title-4-wrapper">
                            <?php if ( !empty($settings['rr_section_sub_title']) ) : ?>
                            <h6 class="section-slider-title-4-wrapper-subtitle wow fadeInLeft animated rr-el-sub-title"
                                data-wow-delay=".2s"><?php echo rr_kses( $settings['rr_section_sub_title'] ); ?>
                                <svg width="14" height="13" viewBox="0 0 14 13" fill="none"
                                    xmlns="http://www.w3.org/2000/svg">
                                    <g clip-path="url(#clip0_3800_934)">
                                        <path d="M4.9248 10.3943L6.49525 9.70006L5.62485 9.08984L4.9248 10.3943Z"
                                            fill="#83CD20" />
                                        <path
                                            d="M4.9248 10.3939L4.99976 8.01953L13.9078 0.0195312L5.66407 9.13083L4.9248 10.3939Z"
                                            fill="#83CD20" />
                                        <path d="M5 8.01953L13.908 0.0195312L0 6.24657L5 8.01953Z" fill="#83CD20" />
                                        <path d="M5.66406 9.13083L9.95686 12.0195L13.9078 0.0195312L5.66406 9.13083Z"
                                            fill="#034833" />
                                    </g>
                                    <defs>
                                        <clipPath id="clip0_3800_934">
                                            <rect width="13.908" height="12" fill="white"
                                                transform="translate(0 0.0195312)" />
                                        </clipPath>
                                    </defs>
                                </svg>
                            </h6>
                            <?php endif; ?>
                            <?php
                                if ( !empty($settings['rr_section_title' ]) ) :
                                    printf( '<%1$s %2$s>%3$s</%1$s>',
                                    tag_escape( $settings['rr_section_title_tag'] ),
                                    $this->get_render_attribute_string( 'title_args' ),
                                    rr_kses( $settings['rr_section_title' ] )
                                    );
                                endif;
                            ?>
                        </div>
                        <div class="section-slider-title-4-button">
                            <button
                                class="section-slider-title-4-button-right service__slider-button-prev wow fadeInLeft animated"
                                data-wow-delay=".5s">
                                <i class="fa-solid fa-arrow-left"></i>
                            </button>
                            <button
                                class="section-slider-title-4-button-right service__slider-button-next wow fadeInLeft animated"
                                data-wow-delay=".6s">
                                <i class="fa-solid fa-arrow-right"></i>
                            </button>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            <div class="row mb-minus-30">
                <div class="col-12">
                    <div class="swiper service-swiper">
                        <div class="swiper-wrapper">
                            <?php foreach ($settings['rr_service_list'] as $key => $item) :

                                if ('2' == $item['rr_services_link_type']) {
                                    $link = get_permalink($item['rr_services_page_link']);
                                    $target = '_self';
                                    $rel = 'nofollow';
                                } else {
                                    $link = !empty($item['rr_services_link']['url']) ? $item['rr_services_link']['url'] : '';
                                    $target = !empty($item['rr_services_link']['is_external']) ? '_blank' : '';
                                    $rel = !empty($item['rr_services_link']['nofollow']) ? 'nofollow' : '';
                                }
                            ?>
                            <div class="swiper-slide service__item-slide mb-30 wow fadeInLeft animated"
                                data-wow-delay=".4s">
                                <div class="service__box services-box">
                                    <div class="service__icon mb-40 rr-el-icon">
                                        <?php if($item['rr_service_icon_type'] == 'icon') : ?>
                                        <?php if (!empty($item['rr_service_icon']) || !empty($item['rr_service_selected_icon']['value'])) : ?>
                                        <span>
                                            <?php rr_render_icon($item, 'rr_service_icon', 'rr_service_selected_icon'); ?>
                                        </span>
                                        <?php endif; ?>
                                        <?php elseif( $item['rr_service_icon_type'] == 'image' ) : ?>
                                        <?php if (!empty($item['rr_service_image']['url'])): ?>
                                        <span>
                                            <img src="<?php echo $item['rr_service_image']['url']; ?>"
                                                alt="<?php echo get_post_meta(attachment_url_to_postid($item['rr_service_image']['url']), '_wp_attachment_image_alt', true); ?>">
                                        </span>
                                        <?php endif; ?>
                                        <?php else : ?>
                                        <?php if (!empty($item['rr_service_icon_svg'])): ?>
                                        <span>
                                            <?php echo $item['rr_service_icon_svg']; ?>
                                        </span>
                                        <?php endif; ?>
                                        <?php endif; ?>
                                    </div>
                                    <h4 class="service__title rr-el-re-Title">
                                        <?php if ($item['rr_services_link_switcher'] == 'yes') : ?> <a
                                            href="<?php echo esc_url($link); ?>">
                                            <?php echo rr_kses($item['rr_service_title' ]); ?></a>
                                        <?php else : ?>
                                        <?php echo rr_kses($item['rr_service_title' ]); ?>
                                        <?php endif; ?>
                                    </h4>
                                    <?php if (!empty($item['rr_service_description' ])): ?>
                                    <p class="rr-el-re-dec service__box-paragraph mt-20">
                                        <?php echo rr_kses($item['rr_service_description']); ?></p>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php elseif ( $settings['rr_design_style']  == 'layout-4' ):
   
    // Link
    if ('2' == $settings['rr_services_btn_link_type']) {
        $this->add_render_attribute('rr-button-arg', 'href', get_permalink($settings['rr_services_btn_page_link']));
        $this->add_render_attribute('rr-button-arg', 'target', '_self');
        $this->add_render_attribute('rr-button-arg', 'rel', 'nofollow');
        $this->add_render_attribute('rr-button-arg', 'class', 'rr-btn');
    } else {
        if ( ! empty( $settings['rr_services_btn_link']['url'] ) ) {
            $this->add_link_attributes( 'rr-button-arg', $settings['rr_services_btn_link'] );
            $this->add_render_attribute('rr-button-arg', 'class', 'rr-btn');
        }
    }
    $this->add_render_attribute('title_args', 'class', 'section__title-wrapper-title wow fadeInLeft animated rr-el-title');
?>
<section class="visa__area section-space gray-bg ele-section">
    <div class="container">
        <div class="row">
            <?php if ( !empty($settings['rr_section_section_title_show']) ) : ?>
            <div class="section__title-wrapper text-center mb-50">
                <?php if ( !empty($settings['rr_section_sub_title']) ) : ?>
                <h6 class="section__title-wrapper-center-subtitle mb-10 wow fadeInLeft animated rr-el-sub-title"
                    data-wow-delay=".2s">
                    <svg width="21" height="21" viewBox="0 0 21 21" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <g clip-path="url(#clip0_3756_33)">
                            <path
                                d="M19.8 2.66986C19.7618 2.59008 19.6936 2.52868 19.6103 2.49911L12.6959 0.0581985C12.5224 -0.00317634 12.332 0.0879901 12.2706 0.26149L10.7 4.70581H10.013V3.57248C10.013 3.41941 9.97783 3.26838 9.91023 3.13104C9.84263 2.9937 9.7444 2.87372 9.62311 2.78033C9.50182 2.68695 9.36071 2.62266 9.21066 2.59242C9.0606 2.56217 8.9056 2.56679 8.75761 2.6059L0.748416 4.7169V4.7229C0.677823 4.74064 0.615123 4.78133 0.57016 4.83857C0.525197 4.89581 0.500519 4.96636 0.5 5.03915V19.0391C0.5 19.5914 0.947749 20.0391 1.5 20.0391H10.8333C11.3856 20.0391 11.8333 19.5914 11.8333 19.0391V16.0145L14.5066 16.9582C14.6803 17.0194 14.8707 16.9285 14.9319 16.7548L19.8143 2.92457C19.8287 2.88326 19.8349 2.83949 19.8325 2.79578C19.83 2.75208 19.819 2.70928 19.7999 2.66986H19.8ZM8.92769 3.24873C8.97703 3.23573 9.02869 3.23421 9.07871 3.24429C9.12873 3.25436 9.17577 3.27577 9.21623 3.30686C9.2567 3.33802 9.28947 3.37806 9.31202 3.42389C9.33456 3.46972 9.34628 3.52012 9.34627 3.57119V4.70581H3.40366L8.92769 3.24873ZM11.1666 19.0391C11.1666 19.1275 11.1315 19.2123 11.069 19.2748C11.0065 19.3373 10.9217 19.3724 10.8333 19.3724H1.5C1.41159 19.3724 1.32681 19.3373 1.2643 19.2748C1.20178 19.2123 1.16667 19.1275 1.16667 19.0391V5.37248H10.8333C10.9217 5.37248 11.0065 5.4076 11.069 5.47011C11.1315 5.53262 11.1666 5.61741 11.1666 5.70581V19.0391ZM13.9067 6.64152L14.3333 6.43923L14.5366 6.86452L12.917 11.4481C12.8877 11.5315 12.8926 11.6231 12.9306 11.7029L13.2776 12.4288L13.1704 12.7331L12.5093 12.0485C12.4734 12.0112 12.4294 11.9827 12.3806 11.9653C12.3318 11.9479 12.2797 11.9422 12.2283 11.9485L11.8333 11.9985V11.5518L12.1176 11.4158C12.1974 11.3776 12.2588 11.3095 12.2884 11.2262L12.9551 9.34089L13.9067 6.64152ZM14.5353 8.86643L15.2121 9.95384L15.0963 10.2815L14.2866 9.57251L14.5353 8.86643ZM11.8333 10.5121V9.5961L12.1613 9.58243L11.8333 10.5121ZM12.4001 8.90551L11.8333 8.9288V8.4851L12.6494 8.20043L12.4001 8.90551ZM14.4141 16.2185L11.8333 15.3075V12.6704L12.1456 12.6314L13.0667 13.5842C13.098 13.616 13.1353 13.6413 13.1765 13.6585C13.2177 13.6756 13.262 13.6843 13.3066 13.6841C13.3304 13.6842 13.3541 13.6817 13.3773 13.6765C13.4328 13.6644 13.4843 13.6383 13.5268 13.6008C13.5694 13.5632 13.6017 13.5154 13.6206 13.4618L13.9539 12.5188C13.9834 12.4354 13.9785 12.3438 13.9402 12.2642L13.5916 11.5391L14.0477 10.2475L15.027 11.1059C15.0878 11.1592 15.1659 11.1885 15.2468 11.1885C15.2752 11.1885 15.3036 11.1848 15.3311 11.1775C15.3837 11.1637 15.4322 11.1372 15.4723 11.1004C15.5124 11.0636 15.5429 11.0175 15.5611 10.9662L15.8944 10.0232C15.911 9.97606 15.9168 9.92579 15.9114 9.87612C15.906 9.82644 15.8894 9.77863 15.863 9.73622L14.8196 8.06014L15.2103 6.95389C15.2249 6.91256 15.2312 6.86876 15.2289 6.82499C15.2265 6.78122 15.2156 6.73834 15.1966 6.69881L14.7901 5.84856C14.7712 5.80904 14.7447 5.77363 14.7121 5.74435C14.6796 5.71507 14.6416 5.69249 14.6003 5.67791C14.559 5.66332 14.5152 5.65701 14.4715 5.65934C14.4277 5.66167 14.3849 5.67259 14.3454 5.69148L13.4946 6.09823C13.4552 6.11709 13.4199 6.14354 13.3906 6.17607C13.3614 6.2086 13.3389 6.24657 13.3244 6.28781L12.9333 7.39543L11.8333 7.77914V5.70581C11.8329 5.53523 11.7888 5.36759 11.7051 5.21895C11.6214 5.07031 11.5009 4.94564 11.3553 4.85685L11.9001 3.31211L12.0223 2.96557L12.7891 0.798905L19.0753 3.01782L14.4141 16.2185Z"
                                fill="#034833" />
                            <path
                                d="M17.0439 5.12938L17.2657 4.50063L17.8374 4.7023L17.6155 5.33105L17.0439 5.12938ZM12.472 3.51526L12.694 2.88672L13.2654 3.08851L13.0434 3.71709L12.472 3.51526ZM15.9008 4.72588L16.1228 4.09713L16.6943 4.29897L16.4723 4.92755L15.9008 4.72588ZM13.615 3.91892L13.837 3.29034L14.4083 3.49218L14.1863 4.12076L13.615 3.91892ZM14.7579 4.32209L14.98 3.69351L15.5514 3.89534L15.3294 4.52388L14.7579 4.32209ZM6.01301 6.707C4.17202 6.707 2.67969 8.19933 2.67969 10.0403C2.67969 11.8813 4.17202 13.3737 6.01301 13.3737C7.85401 13.3737 9.34634 11.8813 9.34634 10.0403C9.34438 8.20033 7.85318 6.70909 6.01301 6.707ZM8.42005 8.90066L7.9653 8.80075C7.7653 8.75662 7.56522 8.72166 7.36322 8.69137C7.33297 8.48959 7.29646 8.2888 7.25372 8.08929L7.15359 7.63471C7.70852 7.89885 8.15568 8.34585 8.42005 8.90066ZM3.34631 10.0403C3.34698 9.90408 3.35806 9.76804 3.37969 9.63341L4.20393 9.45C4.33039 9.422 4.45768 9.39875 4.58527 9.37675C4.55304 9.8186 4.55304 10.2622 4.58527 10.7041C4.45764 10.6821 4.33039 10.6587 4.20393 10.6307L3.37969 10.4474C3.35809 10.3128 3.34695 10.1767 3.34635 10.0403H3.34631ZM5.26172 9.28937C5.76137 9.24478 6.26399 9.24478 6.76364 9.28937C6.80839 9.78901 6.80839 10.2916 6.76364 10.7913C6.26399 10.836 5.76133 10.836 5.26168 10.7913C5.21693 10.2916 5.21697 9.78901 5.26172 9.28937ZM7.43926 9.37675C7.56701 9.39875 7.6943 9.422 7.82059 9.45L8.64497 9.63341C8.69119 9.90278 8.69119 10.178 8.64497 10.4474L7.82059 10.6307C7.69434 10.6587 7.56701 10.6821 7.43926 10.7044C7.47165 10.2624 7.47165 9.81871 7.43926 9.37675ZM6.41972 7.40704L6.60301 8.23175C6.63101 8.35804 6.6546 8.48533 6.67676 8.61308C6.23474 8.58069 5.79095 8.58069 5.34893 8.61308C5.37106 8.48533 5.39435 8.35804 5.42268 8.23175L5.60593 7.40704C5.87527 7.36131 6.15039 7.36131 6.41972 7.40704ZM4.87306 7.63229L4.77293 8.08704C4.72898 8.28704 4.69397 8.48712 4.66373 8.68912C4.46195 8.71926 4.26116 8.75566 4.06164 8.79829L3.60689 8.89841C3.87146 8.34408 4.31845 7.89749 4.87302 7.63342L4.87306 7.63229ZM3.60623 11.179L4.06098 11.2791C4.26098 11.323 4.46085 11.358 4.66306 11.3883C4.69319 11.5901 4.7296 11.7909 4.77222 11.9904L4.87235 12.4449C4.3175 12.1811 3.87024 11.7344 3.60556 11.18L3.60623 11.179ZM5.60622 12.6717L5.42293 11.8469C5.3946 11.721 5.37135 11.5934 5.34918 11.466C5.56993 11.4821 5.7916 11.493 6.01326 11.493C6.23493 11.493 6.45597 11.4821 6.67701 11.466C6.65489 11.5934 6.63126 11.721 6.60326 11.8469L6.42001 12.6717C6.15068 12.7174 5.87556 12.7174 5.60622 12.6717ZM7.15289 12.4464L7.25301 11.9917C7.2973 11.7917 7.33197 11.5917 7.36259 11.3896C7.56434 11.3594 7.7651 11.323 7.96459 11.2804L8.41918 11.1803C8.15505 11.7356 7.70779 12.183 7.15259 12.4474L7.15289 12.4464ZM3.34635 16.0403H8.67967V16.707H3.34635V16.0403ZM4.01302 17.3736H8.01301V18.0403H4.01302V17.3736ZM5.67968 14.707H6.34635V15.3737H5.67968V14.707ZM4.34635 14.707H5.01302V15.3737H4.34635V14.707ZM7.01301 14.707H7.67968V15.3737H7.01301V14.707Z"
                                fill="#034833" />
                        </g>
                        <defs>
                            <clipPath id="clip0_3756_33">
                                <rect width="20" height="20" fill="white" transform="translate(0.5 0.0390625)" />
                            </clipPath>
                        </defs>
                    </svg><?php echo rr_kses( $settings['rr_section_sub_title'] ); ?>
                </h6>
                <?php endif; ?>
                <?php
                    if ( !empty($settings['rr_section_title' ]) ) :
                        printf( '<%1$s %2$s>%3$s</%1$s>',
                        tag_escape( $settings['rr_section_title_tag'] ),
                        $this->get_render_attribute_string( 'title_args' ),
                        rr_kses( $settings['rr_section_title' ] )
                        );
                    endif;
                ?>
            </div>
            <?php endif; ?>
        </div>
        <div class="row mb-minus-30">
            <?php foreach ($settings['rr_service_list'] as $key => $item) :
                    // Link
                    if ( !empty($item['rr_service_image_thumb']['url']) ) {
                        $rr_service_image_thumb = !empty($item['rr_service_image_thumb']['id']) ? wp_get_attachment_image_url( $item['rr_service_image_thumb']['id'], $settings['rr_image_size_size']) : $item['rr_service_image_thumb']['url'];
                        $rr_image_alt = get_post_meta($item["rr_service_image_thumb"]["id"], "_wp_attachment_image_alt", true);
                    } 

                    if ('2' == $item['rr_services_link_type']) {
                        $link = get_permalink($item['rr_services_page_link']);
                        $target = '_self';
                        $rel = 'nofollow';
                    } else {
                        $link = !empty($item['rr_services_link']['url']) ? $item['rr_services_link']['url'] : '';
                        $target = !empty($item['rr_services_link']['is_external']) ? '_blank' : '';
                        $rel = !empty($item['rr_services_link']['nofollow']) ? 'nofollow' : '';
                    }
                ?>
            <div
                class="col-xl-<?php echo esc_attr($settings['rr_col_for_desktop']); ?> col-lg-<?php echo esc_attr($settings['rr_col_for_laptop']); ?> col-md-<?php echo esc_attr($settings['rr_col_for_tablet']); ?> col-<?php echo esc_attr($settings['rr_col_for_mobile']); ?>">
                <div class="visa__item visa__item-2 mb-30 d-flex align-items-center wow fadeInLeft animated services-box"
                    data-wow-delay=".2s">
                    <div class="visa__item-media">
                        <img src="<?php echo esc_url($rr_service_image_thumb); ?>"
                            alt="<?php echo esc_attr($rr_image_alt); ?>">
                    </div>
                    <div class="visa__item-content">
                        <h5 class="rr-el-re-Title">
                            <?php if ($item['rr_services_link_switcher'] == 'yes') : ?> <a
                                href="<?php echo esc_url($link); ?>">
                                <?php echo rr_kses($item['rr_service_title' ]); ?></a>
                            <?php else : ?>
                            <?php echo rr_kses($item['rr_service_title' ]); ?>
                            <?php endif; ?>
                        </h5>
                        <?php if (!empty($item['rr_service_description' ])): ?>
                        <p class="rr-el-re-dec"><?php echo rr_kses($item['rr_service_description']); ?></p>
                        <?php endif; ?>
                        <div class="visa__item-content-button mt-30 d-flex justify-content-between rr-el-icon">
                            <a href="<?php echo esc_url($link); ?>"><i class="fa-solid fa-arrow-right"></i></a>
                            <?php if($item['rr_service_icon_type'] == 'icon') : ?>
                            <?php if (!empty($item['rr_service_icon']) || !empty($item['rr_service_selected_icon']['value'])) : ?>
                            <span>
                                <?php rr_render_icon($item, 'rr_service_icon', 'rr_service_selected_icon'); ?>
                            </span>
                            <?php endif; ?>
                            <?php elseif( $item['rr_service_icon_type'] == 'image' ) : ?>
                            <?php if (!empty($item['rr_service_image']['url'])): ?>
                            <span>
                                <img src="<?php echo $item['rr_service_image']['url']; ?>"
                                    alt="<?php echo get_post_meta(attachment_url_to_postid($item['rr_service_image']['url']), '_wp_attachment_image_alt', true); ?>">
                            </span>
                            <?php endif; ?>
                            <?php else : ?>
                            <?php if (!empty($item['rr_service_icon_svg'])): ?>
                            <span>
                                <?php echo $item['rr_service_icon_svg']; ?>
                            </span>
                            <?php endif; ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<?php elseif ( $settings['rr_design_style']  == 'layout-5' ):
   
   // Link
   if ('2' == $settings['rr_services_btn_link_type']) {
       $this->add_render_attribute('rr-button-arg', 'href', get_permalink($settings['rr_services_btn_page_link']));
       $this->add_render_attribute('rr-button-arg', 'target', '_self');
       $this->add_render_attribute('rr-button-arg', 'rel', 'nofollow');
       $this->add_render_attribute('rr-button-arg', 'class', 'rr-btn');
   } else {
       if ( ! empty( $settings['rr_services_btn_link']['url'] ) ) {
           $this->add_link_attributes( 'rr-button-arg', $settings['rr_services_btn_link'] );
           $this->add_render_attribute('rr-button-arg', 'class', 'rr-btn');
       }
   }
   $this->add_render_attribute('title_args', 'class', 'section-slider-title-2-wrapper-title wow fadeInLeft animated rr-el-title');
?>
<section class="latest-team__area overflow-hidden gray-bg ele-section">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <?php if ( !empty($settings['rr_section_section_title_show']) ) : ?>
                <div class="section-slider-title-2 mb-60">
                    <div class="section-slider-title-2-wrapper">
                        <?php if ( !empty($settings['rr_section_sub_title']) ) : ?>
                        <h6 class="section-slider-title-2-wrapper-subtitle wow fadeInLeft animated rr-el-sub-title"
                            data-wow-delay=".2s">
                            <svg width="20" height="21" viewBox="0 0 20 21" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <g clip-path="url(#clip0_3756_46)">
                                    <path
                                        d="M19.3 2.67377C19.2618 2.59399 19.1936 2.53259 19.1103 2.50302L12.1959 0.0621048C12.0224 0.000729911 11.832 0.0918964 11.7706 0.265396L10.2 4.70972H9.51302V3.57639C9.513 3.42331 9.47783 3.27229 9.41023 3.13495C9.34263 2.99761 9.2444 2.87762 9.12311 2.78424C9.00182 2.69086 8.86071 2.62656 8.71066 2.59632C8.5606 2.56608 8.4056 2.57069 8.25761 2.60981L0.248416 4.7208V4.7268C0.177823 4.74455 0.115123 4.78523 0.0701599 4.84247C0.0251971 4.89971 0.000518721 4.97027 0 5.04305L0 19.043C0 19.5953 0.447749 20.043 0.999998 20.043H10.3333C10.8856 20.043 11.3333 19.5953 11.3333 19.043V16.0184L14.0066 16.9622C14.1803 17.0233 14.3707 16.9324 14.4319 16.7587L19.3143 2.92847C19.3287 2.88716 19.3349 2.8434 19.3325 2.79969C19.33 2.75598 19.319 2.71319 19.2999 2.67377H19.3ZM8.42769 3.25264C8.47703 3.23964 8.52869 3.23812 8.57871 3.24819C8.62873 3.25827 8.67577 3.27968 8.71623 3.31076C8.7567 3.34193 8.78947 3.38197 8.81202 3.4278C8.83456 3.47363 8.84628 3.52402 8.84627 3.5751V4.70972H2.90366L8.42769 3.25264ZM10.6666 19.043C10.6666 19.1314 10.6315 19.2162 10.569 19.2787C10.5065 19.3412 10.4217 19.3764 10.3333 19.3764H0.999998C0.911593 19.3764 0.826808 19.3412 0.764296 19.2787C0.701784 19.2162 0.666665 19.1314 0.666665 19.043V5.37638H10.3333C10.4217 5.37638 10.5065 5.4115 10.569 5.47402C10.6315 5.53653 10.6666 5.62131 10.6666 5.70972V19.043ZM13.4067 6.64542L13.8333 6.44313L14.0366 6.86842L12.417 11.452C12.3877 11.5354 12.3926 11.627 12.4306 11.7068L12.7776 12.4327L12.6704 12.737L12.0093 12.0525C11.9734 12.0151 11.9294 11.9866 11.8806 11.9692C11.8318 11.9518 11.7797 11.9461 11.7283 11.9524L11.3333 12.0024V11.5557L11.6176 11.4197C11.6974 11.3816 11.7588 11.3134 11.7884 11.2301L12.4551 9.34479L13.4067 6.64542ZM14.0353 8.87034L14.7121 9.95775L14.5963 10.2854L13.7866 9.57642L14.0353 8.87034ZM11.3333 10.516V9.6L11.6613 9.58633L11.3333 10.516ZM11.9001 8.90942L11.3333 8.93271V8.489L12.1494 8.20434L11.9001 8.90942ZM13.9141 16.2224L11.3333 15.3114V12.6743L11.6456 12.6353L12.5667 13.5881C12.598 13.6199 12.6353 13.6452 12.6765 13.6624C12.7177 13.6795 12.762 13.6882 12.8066 13.688C12.8304 13.6882 12.8541 13.6856 12.8773 13.6804C12.9328 13.6683 12.9843 13.6423 13.0268 13.6047C13.0694 13.5671 13.1017 13.5193 13.1206 13.4657L13.4539 12.5227C13.4834 12.4393 13.4785 12.3477 13.4402 12.2681L13.0916 11.543L13.5477 10.2514L14.527 11.1098C14.5878 11.1631 14.6659 11.1925 14.7468 11.1925C14.7752 11.1925 14.8036 11.1887 14.8311 11.1814C14.8837 11.1676 14.9322 11.1411 14.9723 11.1043C15.0124 11.0675 15.0429 11.0214 15.0611 10.9701L15.3944 10.0271C15.411 9.97996 15.4168 9.9297 15.4114 9.88002C15.406 9.83035 15.3894 9.78253 15.363 9.74013L14.3196 8.06405L14.7103 6.9578C14.7249 6.91647 14.7312 6.87267 14.7289 6.8289C14.7265 6.78513 14.7156 6.74225 14.6966 6.70272L14.2901 5.85247C14.2712 5.81295 14.2447 5.77754 14.2121 5.74826C14.1796 5.71898 14.1416 5.6964 14.1003 5.68181C14.059 5.66722 14.0152 5.66091 13.9715 5.66324C13.9277 5.66557 13.8849 5.67649 13.8454 5.69538L12.9946 6.10213C12.9552 6.121 12.9199 6.14745 12.8906 6.17998C12.8614 6.21251 12.8389 6.25048 12.8244 6.29172L12.4333 7.39934L11.3333 7.78305V5.70972C11.3329 5.53913 11.2888 5.3715 11.2051 5.22286C11.1214 5.07422 11.0009 4.94954 10.8553 4.86076L11.4001 3.31601L11.5223 2.96947L12.2891 0.802812L18.5753 3.02172L13.9141 16.2224Z"
                                        fill="#034833" />
                                    <path
                                        d="M16.5439 5.13329L16.7657 4.50454L17.3374 4.7062L17.1155 5.33495L16.5439 5.13329ZM11.972 3.51917L12.194 2.89062L12.7654 3.09242L12.5434 3.721L11.972 3.51917ZM15.4008 4.72979L15.6228 4.10104L16.1943 4.30287L15.9723 4.93145L15.4008 4.72979ZM13.115 3.92283L13.337 3.29425L13.9083 3.49608L13.6863 4.12466L13.115 3.92283ZM14.2579 4.326L14.48 3.69741L15.0514 3.89925L14.8294 4.52779L14.2579 4.326ZM5.51301 6.71091C3.67202 6.71091 2.17969 8.20324 2.17969 10.0442C2.17969 11.8852 3.67202 13.3776 5.51301 13.3776C7.35401 13.3776 8.84634 11.8852 8.84634 10.0442C8.84438 8.20424 7.35318 6.71299 5.51301 6.71091ZM7.92005 8.90457L7.4653 8.80465C7.2653 8.76053 7.06522 8.72557 6.86322 8.69528C6.83297 8.4935 6.79646 8.29271 6.75372 8.0932L6.65359 7.63861C7.20852 7.90276 7.65568 8.34975 7.92005 8.90457ZM2.84631 10.0442C2.84698 9.90799 2.85806 9.77194 2.87969 9.63732L3.70393 9.4539C3.83039 9.4259 3.95768 9.40265 4.08527 9.38065C4.05304 9.82251 4.05304 10.2661 4.08527 10.708C3.95764 10.686 3.83039 10.6626 3.70393 10.6346L2.87969 10.4513C2.85809 10.3167 2.84695 10.1806 2.84635 10.0442H2.84631ZM4.76172 9.29328C5.26137 9.24868 5.76399 9.24868 6.26364 9.29328C6.30839 9.79292 6.30839 10.2956 6.26364 10.7952C5.76399 10.84 5.26133 10.84 4.76168 10.7952C4.71693 10.2956 4.71697 9.79292 4.76172 9.29328ZM6.93926 9.38065C7.06701 9.40265 7.1943 9.4259 7.32059 9.4539L8.14497 9.63732C8.19119 9.90668 8.19119 10.182 8.14497 10.4513L7.32059 10.6346C7.19434 10.6626 7.06701 10.686 6.93926 10.7083C6.97165 10.2664 6.97165 9.82262 6.93926 9.38065ZM5.91972 7.41095L6.10301 8.23565C6.13101 8.36195 6.1546 8.48924 6.17676 8.61699C5.73474 8.5846 5.29095 8.5846 4.84893 8.61699C4.87106 8.48924 4.89435 8.36195 4.92268 8.23565L5.10593 7.41095C5.37527 7.36521 5.65039 7.36521 5.91972 7.41095ZM4.37306 7.6362L4.27293 8.09095C4.22898 8.29095 4.19397 8.49103 4.16373 8.69303C3.96195 8.72316 3.76116 8.75957 3.56164 8.8022L3.10689 8.90232C3.37146 8.34799 3.81845 7.90139 4.37302 7.63732L4.37306 7.6362ZM3.10623 11.1829L3.56098 11.283C3.76098 11.3269 3.96085 11.3619 4.16306 11.3922C4.19319 11.594 4.2296 11.7948 4.27222 11.9943L4.37235 12.4489C3.8175 12.185 3.37024 11.7383 3.10556 11.1839L3.10623 11.1829ZM5.10622 12.6756L4.92293 11.8509C4.8946 11.7249 4.87135 11.5973 4.84918 11.4699C5.06993 11.486 5.2916 11.4969 5.51326 11.4969C5.73493 11.4969 5.95597 11.486 6.17701 11.4699C6.15489 11.5973 6.13126 11.7249 6.10326 11.8509L5.92001 12.6756C5.65068 12.7213 5.37556 12.7213 5.10622 12.6756ZM6.65289 12.4503L6.75301 11.9956C6.7973 11.7956 6.83197 11.5956 6.86259 11.3935C7.06434 11.3633 7.2651 11.3269 7.46459 11.2843L7.91918 11.1842C7.65505 11.7395 7.20779 12.1869 6.65259 12.4513L6.65289 12.4503ZM2.84635 16.0442H8.17967V16.7109H2.84635V16.0442ZM3.51302 17.3776H7.51301V18.0442H3.51302V17.3776ZM5.17968 14.7109H5.84635V15.3776H5.17968V14.7109ZM3.84635 14.7109H4.51302V15.3776H3.84635V14.7109ZM6.51301 14.7109H7.17968V15.3776H6.51301V14.7109Z"
                                        fill="#034833" />
                                </g>
                                <defs>
                                    <clipPath id="clip0_3756_46">
                                        <rect width="20" height="20" fill="white" transform="translate(0 0.0429688)" />
                                    </clipPath>
                                </defs>
                            </svg>
                            <?php echo rr_kses( $settings['rr_section_sub_title'] ); ?>
                        </h6>
                        <?php endif; ?>
                        <?php
                            if ( !empty($settings['rr_section_title' ]) ) :
                                printf( '<%1$s %2$s>%3$s</%1$s>',
                                tag_escape( $settings['rr_section_title_tag'] ),
                                $this->get_render_attribute_string( 'title_args' ),
                                rr_kses( $settings['rr_section_title' ] )
                                );
                            endif;
                        ?>
                    </div>
                    <div class="section-slider-title-2-button">
                        <button
                            class="section-slider-title-2-button-right team__slider-button-prev wow fadeInLeft animated"
                            data-wow-delay=".4s">
                            <i class="fa-solid fa-arrow-left"></i>
                        </button>
                        <button
                            class="section-slider-title-2-button-right team__slider-button-next wow fadeInLeft animated"
                            data-wow-delay=".5s">
                            <i class="fa-solid fa-arrow-right"></i>
                        </button>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>

        <div class="row p-relative mb-minus-30">
            <div class="col-12">
                <div class="latest-team__item margin-minus-400 mb-30">
                    <div class="swiper card-slide">
                        <div class="swiper-wrapper">
                            <?php foreach ($settings['rr_service_list'] as $key => $item) :
                            // Link
                            if ( !empty($item['rr_service_image_thumb']['url']) ) {
                                $rr_service_image_thumb = !empty($item['rr_service_image_thumb']['id']) ? wp_get_attachment_image_url( $item['rr_service_image_thumb']['id'], $settings['rr_image_size_size']) : $item['rr_service_image_thumb']['url'];
                                $rr_image_alt = get_post_meta($item["rr_service_image_thumb"]["id"], "_wp_attachment_image_alt", true);
                            } 
        

                                if ('2' == $item['rr_services_link_type']) {
                                    $link = get_permalink($item['rr_services_page_link']);
                                    $target = '_self';
                                    $rel = 'nofollow';
                                } else {
                                    $link = !empty($item['rr_services_link']['url']) ? $item['rr_services_link']['url'] : '';
                                    $target = !empty($item['rr_services_link']['is_external']) ? '_blank' : '';
                                    $rel = !empty($item['rr_services_link']['nofollow']) ? 'nofollow' : '';
                                }
                            ?>
                            <div class="swiper-slide latest-team__item-slide wow fadeInLeft animated "
                                data-wow-delay=".2s">
                                <div class="latest-team__item-media">
                                    <div class="latest-item_thumb" data-tilt>
                                        <a href="<?php echo esc_url($link); ?>">
                                            <img src="<?php echo esc_url($rr_service_image_thumb); ?>" alt="image">
                                        </a>
                                    </div>
                                    <div class="latest-team__item-media-img-title d-flex services-box">
                                        <div class="latest-team__item-media-img-title-text">
                                            <h4 class="rr-el-re-Title">
                                                <?php echo rr_kses($item['rr_service_title' ]); ?>

                                            </h4>
                                            <?php if (!empty($item['rr_service_description' ])): ?>
                                            <p class="rr-el-re-dec">
                                                <?php echo rr_kses($item['rr_service_description']); ?></p>
                                            <?php endif; ?>
                                        </div>
                                        <div class="latest-team__item-media-img-title-button ">
                                            <a class="rr-el-icon" href="<?php echo esc_url($link); ?>">
                                                <?php if($item['rr_service_icon_type'] == 'icon') : ?>
                                                <?php if (!empty($item['rr_service_icon']) || !empty($item['rr_service_selected_icon']['value'])) : ?>
                                                <span>
                                                    <?php rr_render_icon($item, 'rr_service_icon', 'rr_service_selected_icon'); ?>
                                                </span>
                                                <?php endif; ?>
                                                <?php elseif( $item['rr_service_icon_type'] == 'image' ) : ?>
                                                <?php if (!empty($item['rr_service_image']['url'])): ?>
                                                <span>
                                                    <img src="<?php echo $item['rr_service_image']['url']; ?>"
                                                        alt="<?php echo get_post_meta(attachment_url_to_postid($item['rr_service_image']['url']), '_wp_attachment_image_alt', true); ?>">
                                                </span>
                                                <?php endif; ?>
                                                <?php else : ?>
                                                <?php if (!empty($item['rr_service_icon_svg'])): ?>
                                                <span>
                                                    <?php echo $item['rr_service_icon_svg']; ?>
                                                </span>
                                                <?php endif; ?>
                                                <?php endif; ?>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php elseif ( $settings['rr_design_style']  == 'layout-6' ):
   // Link
   if ('2' == $settings['rr_services_btn_link_type']) {
       $this->add_render_attribute('rr-button-arg', 'href', get_permalink($settings['rr_services_btn_page_link']));
       $this->add_render_attribute('rr-button-arg', 'target', '_self');
       $this->add_render_attribute('rr-button-arg', 'rel', 'nofollow');
       $this->add_render_attribute('rr-button-arg', 'class', 'rr-btn');
   } else {
       if ( ! empty( $settings['rr_services_btn_link']['url'] ) ) {
           $this->add_link_attributes( 'rr-button-arg', $settings['rr_services_btn_link'] );
           $this->add_render_attribute('rr-button-arg', 'class', 'rr-btn');
       }
   }
   $this->add_render_attribute('title_args', 'class', 'section__title-wrapper-title wow fadeInLeft animated rr-el-title');
?>
<!--choose us-->
<section class="choose-us-4 section-space ele-section">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <?php if ( !empty($settings['rr_section_section_title_show']) ) : ?>
                <div class="section__title-wrapper text-center mb-60 mb-xs-30">
                    <?php if ( !empty($settings['rr_section_section_title_show']) ) : ?>
                    <h6 class="section__title-wrapper-center-subtitle mb-10 wow fadeInLeft animated"
                        data-wow-delay=".2s"><?php echo rr_kses( $settings['rr_section_sub_title'] ); ?></h6>
                    <?php endif; ?>
                    <?php
                        if ( !empty($settings['rr_section_title' ]) ) :
                            printf( '<%1$s %2$s>%3$s</%1$s>',
                            tag_escape( $settings['rr_section_title_tag'] ),
                            $this->get_render_attribute_string( 'title_args' ),
                            rr_kses( $settings['rr_section_title' ] )
                            );
                        endif;
                    ?>
                </div>
                <?php endif; ?>
            </div>
        </div>
        <div class="row mb-minus-30">
            <?php foreach ($settings['rr_service_list'] as $key => $item) :

                if ('2' == $item['rr_services_link_type']) {
                    $link = get_permalink($item['rr_services_page_link']);
                    $target = '_self';
                    $rel = 'nofollow';
                } else {
                    $link = !empty($item['rr_services_link']['url']) ? $item['rr_services_link']['url'] : '';
                    $target = !empty($item['rr_services_link']['is_external']) ? '_blank' : '';
                    $rel = !empty($item['rr_services_link']['nofollow']) ? 'nofollow' : '';
                }
            ?>
            <div
                class="col-xl-<?php echo esc_attr($settings['rr_col_for_desktop']); ?> col-lg-<?php echo esc_attr($settings['rr_col_for_laptop']); ?> col-md-<?php echo esc_attr($settings['rr_col_for_tablet']); ?> col-<?php echo esc_attr($settings['rr_col_for_mobile']); ?>">
                <div class="choose-us-4__item mb-30 services-box">
                    <div class="icon">
                        <?php if($item['rr_service_icon_type'] == 'icon') : ?>
                        <?php if (!empty($item['rr_service_icon']) || !empty($item['rr_service_selected_icon']['value'])) : ?>
                        <span>
                            <?php rr_render_icon($item, 'rr_service_icon', 'rr_service_selected_icon'); ?>
                        </span>
                        <?php endif; ?>
                        <?php elseif( $item['rr_service_icon_type'] == 'image' ) : ?>
                        <?php if (!empty($item['rr_service_image']['url'])): ?>
                        <span>
                            <img src="<?php echo $item['rr_service_image']['url']; ?>"
                                alt="<?php echo get_post_meta(attachment_url_to_postid($item['rr_service_image']['url']), '_wp_attachment_image_alt', true); ?>">
                        </span>
                        <?php endif; ?>
                        <?php else : ?>
                        <?php if (!empty($item['rr_service_icon_svg'])): ?>
                        <span>
                            <?php echo $item['rr_service_icon_svg']; ?>
                        </span>
                        <?php endif; ?>
                        <?php endif; ?>
                    </div>
                    <h3 class="title">
                        <?php if ($item['rr_services_link_switcher'] == 'yes') : ?> <a
                            href="<?php echo esc_url($link); ?>">
                            <?php echo rr_kses($item['rr_service_title' ]); ?></a>
                        <?php else : ?>
                        <?php echo rr_kses($item['rr_service_title' ]); ?>
                        <?php endif; ?>
                    </h3>
                    <?php if (!empty($item['rr_service_description' ])): ?>
                    <p class="dec rr-el-re-dec"><?php echo rr_kses($item['rr_service_description']); ?></p>
                    <?php endif; ?>
                    <a class="choose-btn" href="<?php echo esc_url($link); ?>"><?php echo rr_kses($item['rr_service_btn']); ?> <i
                            class="fa-sharp fa-solid fa-arrow-right"></i></a>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>
<?php elseif ( $settings['rr_design_style']  == 'layout-7' ): 
   // Link
   if ('2' == $settings['rr_services_btn_link_type']) {
       $this->add_render_attribute('rr-button-arg', 'href', get_permalink($settings['rr_services_btn_page_link']));
       $this->add_render_attribute('rr-button-arg', 'target', '_self');
       $this->add_render_attribute('rr-button-arg', 'rel', 'nofollow');
       $this->add_render_attribute('rr-button-arg', 'class', 'rr-btn');
   } else {
       if ( ! empty( $settings['rr_services_btn_link']['url'] ) ) {
           $this->add_link_attributes( 'rr-button-arg', $settings['rr_services_btn_link'] );
           $this->add_render_attribute('rr-button-arg', 'class', 'rr-btn');
       }
   }
   $this->add_render_attribute('title_args', 'class', 'section__title-wrapper-title wow fadeInLeft animated rr-el-title');
?>
<section class="categories section-space-bottom ele-section">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="section__title-wrapper text-center mb-60 mb-xs-30">
                    <?php if ( !empty($settings['rr_section_sub_title']) ) : ?>
                    <h6 class="section__title-wrapper-center-subtitle mb-10 wow fadeInLeft animated"
                        data-wow-delay=".2s"><?php echo rr_kses( $settings['rr_section_sub_title'] ); ?></h6>
                    <?php endif; ?>
                    <?php
                            if ( !empty($settings['rr_section_title' ]) ) :
                                printf( '<%1$s %2$s>%3$s</%1$s>',
                                tag_escape( $settings['rr_section_title_tag'] ),
                                $this->get_render_attribute_string( 'title_args' ),
                                rr_kses( $settings['rr_section_title' ] )
                                );
                            endif;
                        ?>
                </div>
            </div>
        </div>
        <div class="row mb-minus-30">
            <?php foreach ($settings['rr_service_list'] as $key => $item) :
                if ('2' == $item['rr_services_link_type']) {
                    $link = get_permalink($item['rr_services_page_link']);
                    $target = '_self';
                    $rel = 'nofollow';
                } else {
                    $link = !empty($item['rr_services_link']['url']) ? $item['rr_services_link']['url'] : '';
                    $target = !empty($item['rr_services_link']['is_external']) ? '_blank' : '';
                    $rel = !empty($item['rr_services_link']['nofollow']) ? 'nofollow' : '';
                }
            ?>
            
            <div class="col-xl-4 col-lg-4 col-md-6 col-sm-6">
                <div class="categories__item mb-30 services-box">
                    <div class="categories__item-icon">
                        <?php if($item['rr_service_icon_type'] == 'icon') : ?>
                        <?php if (!empty($item['rr_service_icon']) || !empty($item['rr_service_selected_icon']['value'])) : ?>
                        <span class="rr-el-icon">
                            <?php rr_render_icon($item, 'rr_service_icon', 'rr_service_selected_icon'); ?>
                        </span>
                        <?php endif; ?>
                        <?php elseif( $item['rr_service_icon_type'] == 'image' ) : ?>
                        <?php if (!empty($item['rr_service_image']['url'])): ?>
                        <span class="rr-el-icon">
                            <img src="<?php echo $item['rr_service_image']['url']; ?>"
                                alt="<?php echo get_post_meta(attachment_url_to_postid($item['rr_service_image']['url']), '_wp_attachment_image_alt', true); ?>">
                        </span>
                        <?php endif; ?>
                        <?php else : ?>
                        <?php if (!empty($item['rr_service_icon_svg'])): ?>
                        <span class="rr-el-icon">
                            <?php echo $item['rr_service_icon_svg']; ?>
                        </span>
                        <?php endif; ?>
                        <?php endif; ?>
                    </div>
                    <h5 class="categories__item-text">0<?php echo $key + 1; ?></h5>
                    <h3 class="categories__title rr-el-re-Title">
                        <?php if ($item['rr_services_link_switcher'] == 'yes') : ?> <a
                            href="<?php echo esc_url($link); ?>">
                            <?php echo rr_kses($item['rr_service_title' ]); ?></a>
                        <?php else : ?>
                        <?php echo rr_kses($item['rr_service_title' ]); ?>
                        <?php endif; ?>
                    </h3>
                    <?php if (!empty($item['rr_service_description' ])): ?>
                    <p class="categories__item-dec rr-el-re-dec"><?php echo rr_kses($item['rr_service_description']); ?></p>
                    <?php endif; ?>
                    <a href="<?php echo esc_url($link); ?>" class="categories__btn rr-el-btn"><?php echo rr_kses($item['rr_service_btn']); ?> <i
                            class="fa-sharp fa-solid fa-arrow-right"></i></a>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>
<?php else: 
  
    // Link
    if ('2' == $settings['rr_services_btn_link_type']) {
        $this->add_render_attribute('rr-button-arg', 'href', get_permalink($settings['rr_services_btn_page_link']));
        $this->add_render_attribute('rr-button-arg', 'target', '_self');
        $this->add_render_attribute('rr-button-arg', 'rel', 'nofollow');
        $this->add_render_attribute('rr-button-arg', 'class', '');
    } else {
        if ( ! empty( $settings['rr_services_btn_link']['url'] ) ) {
            $this->add_link_attributes( 'rr-button-arg', $settings['rr_services_btn_link'] );
            $this->add_render_attribute('rr-button-arg', 'class', '');
        }
    }
    $this->add_render_attribute('title_args', 'class', 'rr-section-title ele-section-title');
?>

<section class="gray-bg overflow-hidden pt-30 ele-section">
    <div class="service right">
        <div class="container-fluid">
            <div class="row mb-minus-30">
                <?php foreach ($settings['rr_service_list'] as $key => $item) :

                    if ('2' == $item['rr_services_link_type']) {
                        $link = get_permalink($item['rr_services_page_link']);
                        $target = '_self';
                        $rel = 'nofollow';
                    } else {
                        $link = !empty($item['rr_services_link']['url']) ? $item['rr_services_link']['url'] : '';
                        $target = !empty($item['rr_services_link']['is_external']) ? '_blank' : '';
                        $rel = !empty($item['rr_services_link']['nofollow']) ? 'nofollow' : '';
                    }
                ?>
                <div
                    class="col-xl-<?php echo esc_attr($settings['rr_col_for_desktop']); ?> col-lg-<?php echo esc_attr($settings['rr_col_for_laptop']); ?> col-md-<?php echo esc_attr($settings['rr_col_for_tablet']); ?> col-<?php echo esc_attr($settings['rr_col_for_mobile']); ?>">
                    <div class="service__item mb-30 wow fadeInLeft animated services-box" data-wow-delay=".2s">
                        <div class="service__item-icon rr-el-icon">
                            <?php if($item['rr_service_icon_type'] == 'icon') : ?>
                            <?php if (!empty($item['rr_service_icon']) || !empty($item['rr_service_selected_icon']['value'])) : ?>
                            <span>
                                <?php rr_render_icon($item, 'rr_service_icon', 'rr_service_selected_icon'); ?>
                            </span>
                            <?php endif; ?>
                            <?php elseif( $item['rr_service_icon_type'] == 'image' ) : ?>
                            <?php if (!empty($item['rr_service_image']['url'])): ?>
                            <span>
                                <img src="<?php echo $item['rr_service_image']['url']; ?>"
                                    alt="<?php echo get_post_meta(attachment_url_to_postid($item['rr_service_image']['url']), '_wp_attachment_image_alt', true); ?>">
                            </span>
                            <?php endif; ?>
                            <?php else : ?>
                            <?php if (!empty($item['rr_service_icon_svg'])): ?>
                            <span>
                                <?php echo $item['rr_service_icon_svg']; ?>
                            </span>
                            <?php endif; ?>
                            <?php endif; ?>
                        </div>
                        <div class="service__item-content">
                            <h4 class="rr-el-re-Title">
                                <?php if ($item['rr_services_link_switcher'] == 'yes') : ?> <a
                                    href="<?php echo esc_url($link); ?>">
                                    <?php echo rr_kses($item['rr_service_title' ]); ?></a>
                                <?php else : ?>
                                <?php echo rr_kses($item['rr_service_title' ]); ?>
                                <?php endif; ?>
                            </h4>

                            <?php if (!empty($item['rr_service_description' ])): ?>
                            <p class="rr-el-re-dec"><?php echo rr_kses($item['rr_service_description']); ?></p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</section>

<?php endif; 
    }
}

$widgets_manager->register( new RR_Service() ); 