<?php
namespace RRCore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use \Elementor\Repeater;
use \Elementor\Group_Control_Image_Size;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * RR Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class rr_Advanced_Tab_Visa extends Widget_Base {

    use \RRCore\Widgets\RRCoreElementFunctions;

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'advanced_tab_visa';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Advanced Tab Visa', 'rr-core' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'rr-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'rr-core' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'rr-core' ];
	}


	protected function register_controls(){
        $this->register_controls_section();
        $this->style_tab_content();
    }  



	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */

	protected function register_controls_section() {

        // layout Panel
        $this->start_controls_section(
            'rr_layout',
            [
                'label' => esc_html__('Design Layout', 'rr-core'),
            ]
        );
        $this->add_control(
            'rr_design_style',
            [
                'label' => esc_html__('Select Layout', 'rr-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Layout 1', 'rr-core'),
                    'layout-2' => esc_html__('Layout 2', 'rr-core'),
                ],
                'default' => 'layout-1',
            ]
        );

        $this->end_controls_section();

		
        // rr_section_title
        $this->rr_section_title_render_controls('section', 'Section Title', 'Sub Title', 'your title here', $default_description = 'Hic nesciunt galisum aut dolorem aperiam eum soluta quod ea cupiditate.',['layout-1', 'layout-2','layout-3']);

		$this->start_controls_section(
            '_section_price_tabs',
            [
                'label' => __('Advanced Tabs', 'rr-core'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $repeater = new Repeater();

        $repeater->add_control(
            'active',
            [
                'label' => __('Active', 'rr-core'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => __('Show', 'rr-core'),
                'label_off' => __('Hide', 'rr-core'),
                'return_value' => 'yes',
                'default' => false,
                'style_transfer' => true,
            ]
        );
        $repeater->add_control(
            'rr_box_icon_type',
            [
                'label' => esc_html__('Select Icon Type', 'rr-core'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'icon',
                'options' => [
                    'image' => esc_html__('Image', 'rr-core'),
                    'icon' => esc_html__('Icon', 'rr-core'),
                    'svg' => esc_html__('SVG', 'rr-core'),
                ],
    
            ]
        );
        $repeater->add_control(
            'rr_box_icon_svg',
            [
                'show_label' => false,
                'type' => Controls_Manager::TEXTAREA,
                'label_block' => true,
                'placeholder' => esc_html__('SVG Code Here', 'rr-core'),
                'condition' => [
                    'rr_box_icon_type' => 'svg'
                ]
            ]
        );
    
        $repeater->add_control(
            'rr_box_icon_image',
            [
                'label' => esc_html__('Upload Icon Image', 'rr-core'),
                'type' => Controls_Manager::MEDIA,
                'condition' => [
                    'rr_box_icon_type' => 'image',
                ]
            ]
        );
    
        if (rr_is_elementor_version('<', '2.6.0')) {
            $repeater->add_control(
                'rr_box_icon',
                [
                    'show_label' => false,
                    'type' => Controls_Manager::ICON,
                    'label_block' => true,
                    'default' => 'fa fa-star',
                    'condition' => [
                        'rr_box_icon_type' => 'icon'
                    ]
                ]
            );
        } else {
            $repeater->add_control(
                'rr_box_selected_icon',
                [
                    'show_label' => false,
                    'type' => Controls_Manager::ICONS,
                    'fa4compatibility' => 'icon',
                    'label_block' => true,
                    'default' => [
                        'value' => 'fas fa-star',
                        'library' => 'solid',
                    ],
                    'condition' => [
                        'rr_box_icon_type' => 'icon'
                    ]
                ]
            );
        }
        $repeater->add_control(
            'title',
            [
                'type' => Controls_Manager::TEXT,
                'label' => __('Title', 'rr-core'),
                'default' => __('Tab Title', 'rr-core'),
                'placeholder' => __('Type Tab Title', 'rr-core'),
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );
        $repeater->add_control(
            'title_desc',
            [
                'type' => Controls_Manager::TEXTAREA,
                'label' => __('Desc', 'rr-core'),
                'default' => __('Tab Description', 'rr-core'),
                'placeholder' => __('Type Tab Title', 'rr-core'),
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );

        $repeater->add_control(
            'template',
            [
                'label' => __('Section Template', 'rr-core'),
                'placeholder' => __('Select a section template for as tab content', 'rr-core'),
  
                'type' => Controls_Manager::SELECT2,
                'options' => get_elementor_templates()
            ]
        );

        $this->add_control(
            'tabs',
            [
                'show_label' => false,
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'title_field' => '{{title}}',
                'default' => [
                    [
                        'title' => 'Tab 1',
                    ],
                    [
                        'title' => 'Tab 2',
                    ]
                ]
            ]
        );

        $this->end_controls_section();

	}

    // style_tab_content
    protected function style_tab_content(){
        $this->rr_section_style_controls('advanced_tab_section', 'Section Style', '.ele-section');
        $this->rr_basic_style_controls('advanced_tab_sub_title', 'Subtitle Style', '.ele-subtitle');
        $this->rr_basic_style_controls('advanced_tab_title', 'Heading Style', '.ele-heading');
        $this->rr_basic_style_controls('advanced_tab_link', 'Tab Link Style', '.ele-link');
    }

	/**
	 * Render the widget ouRRut on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		?>

<?php if ( $settings['rr_design_style']  == 'layout-2' ): 

?>


<?php else: 
    $this->add_render_attribute('title_args', 'class', 'section__title-wrapper-title wow fadeInLeft  animated rr-section-title ele-heading');
?>
<section class="visa-category-2 section-space overflow-hidden">
    <div class="container">
        <div class="row text-center">
            <div class="col-12">
                <div class="section__title-wrapper text-center mb-60">
                    <?php if ( !empty($settings['rr_section_sub_title']) ) : ?>
                    <h6 class="section__title-wrapper-center-subtitle mb-10 wow fadeInLeft animated"
                        data-wow-delay=".2s">
                        <?php echo rr_kses($settings['rr_section_sub_title']); ?>
                        <svg width="14" height="13" viewBox="0 0 14 13" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <g clip-path="url(#clip0_3800_1057)">
                                <path d="M4.9248 11.3553L6.49525 10.661L5.62485 10.0508L4.9248 11.3553Z"
                                    fill="#83CD20" />
                                <path
                                    d="M4.9248 11.3548L4.99976 8.98047L13.9078 0.980469L5.66407 10.0918L4.9248 11.3548Z"
                                    fill="#83CD20" />
                                <path d="M5 8.98047L13.908 0.980469L0 7.2075L5 8.98047Z" fill="#83CD20" />
                                <path d="M5.66406 10.0918L9.95686 12.9805L13.9078 0.980469L5.66406 10.0918Z"
                                    fill="#034833" />
                            </g>
                            <defs>
                                <clipPath id="clip0_3800_1057">
                                    <rect width="13.908" height="12" fill="white" transform="translate(0 0.980469)" />
                                </clipPath>
                            </defs>
                        </svg>
                    </h6>
                    <?php endif; ?>
                    <?php
                    if ( !empty($settings['rr_section_title' ]) ) :
                        printf( '<%1$s %2$s>%3$s</%1$s>',
                        tag_escape( $settings['rr_section_title_tag'] ),
                        $this->get_render_attribute_string( 'title_args' ),
                        rr_kses( $settings['rr_section_title' ] )
                        );
                    endif;
                    ?>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-6">
                <ul class="nav nav-tabs visa-category-2__tab" id="myTab2" role="tablist">
                    <?php foreach ($settings['tabs'] as $key => $tab):
                        $active = ($key == 0) ? 'active' : '';
                    ?>
                    <li class="nav-item visa-category-2__item" role="presentation">
                        <button class="<?php echo esc_attr($active); ?>" id="student-tab-<?php echo esc_attr($key); ?>"
                            data-bs-toggle="tab" data-bs-target="#student-<?php echo esc_attr($key); ?>" type="button"
                            role="tab" aria-controls="student-<?php echo esc_attr($key); ?>" aria-selected="true">
                            <span class="icon">
                                <?php if($tab['rr_box_icon_type'] == 'icon') : ?>
                                <?php if (!empty($tab['rr_box_icon']) || !empty($tab['rr_box_selected_icon']['value'])) : ?>
                                <span>
                                    <?php rr_render_icon($tab, 'rr_box_icon', 'rr_box_selected_icon'); ?>
                                </span>
                                <?php endif; ?>
                                <?php elseif( $tab['rr_box_icon_type'] == 'image' ) : ?>
                                <?php if (!empty($tab['rr_box_icon_image']['url'])): ?>
                                <span>
                                    <img src="<?php echo $tab['rr_box_icon_image']['url']; ?>"
                                        alt="<?php echo get_post_meta(attachment_url_to_postid($tab['rr_box_icon_image']['url']), '_wp_attachment_image_alt', true); ?>">
                                </span>
                                <?php endif; ?>
                                <?php else : ?>
                                <?php if (!empty($tab['rr_box_icon_svg'])): ?>
                                <div class="contact-inner-img contact-img-<?php echo esc_attr($key); ?>">
                                    <?php echo $tab['rr_box_icon_svg']; ?>
                                </div>
                                <?php endif; ?>
                                <?php endif; ?>
                            </span>
                            <span class="text">
                                <span class="heading"><?php echo rr_kses($tab['title']); ?></span>
                                <span class="paragraph"><?php echo rr_kses($tab['title_desc']);?> </span>
                            </span>
                        </button>
                    </li>
                    <?php endforeach; ?>
                </ul>
            </div>
            <div class="col-lg-6">
                <div class="tab-content">
                    <?php foreach ($settings['tabs'] as $key => $tab):
                        $active = ($key == 0) ? 'active show' : '';
                    ?>
                    <div class="tab-pane fade <?php echo esc_attr($active); ?>"
                        id="student-<?php echo esc_attr($key); ?>" role="tabpanel"
                        aria-labelledby="student-tab-<?php echo esc_attr($key); ?>">
                        <div class="visa-category-2__tab-content">
                            <?php echo \Elementor\Plugin::instance()->frontend->get_builder_content($tab['template'], true); ?>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>
</section>

<?php endif;

	}

}
$widgets_manager->register( new rr_Advanced_Tab_Visa() );