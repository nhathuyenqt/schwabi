<?php
namespace RRCore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Repeater;
use \Elementor\Utils;
use \Elementor\Control_Media;
use RRCore\Elementor\Controls\Group_Control_RRBGGradient;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * RR Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class RR_Filter_Main extends Widget_Base {

    use \RRCore\Widgets\RRCoreElementFunctions;

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'rr_filter';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Filter', 'rr-core' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'rr-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'rr-core' ];
	}

    /**
     * contact form 7 setup.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     *
     * @access protected
     */

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */


	protected function register_controls(){
		$this->register_controls_section();
		$this->style_tab_content();
	}		


	// controls file 
	protected function register_controls_section(){
        // layout Panel
        $this->start_controls_section(
            'rr_layout',
            [
                'label' => esc_html__('Design Layout', 'rr-core'),
            ]
        ); 

        $this->add_control( 
            'rr_design_style',
            [
                'label' => esc_html__('Select Layout', 'rr-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Layout 1', 'rr-core'),
                    'layout-2' => esc_html__('Layout 2', 'rr-core'),
                ],
                'default' => 'layout-1',
            ]
        );

        $this->end_controls_section();
        
        // thumbnail image
        $this->start_controls_section(
            'rr_thumbnail_section',
                [
                    'label' => esc_html__( 'Thumbnail', 'rr-core' ),
                    'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
                ]
            );
    
            $this->add_control(
                'rr_thumbnail_image_before',
                [
                    'label' => esc_html__( 'Choose Before Thumbnail Image', 'rr-core' ),
                    'type' => \Elementor\Controls_Manager::MEDIA,
                    'default' => [
                        'url' => \Elementor\Utils::get_placeholder_image_src(),
                    ],
                ]
            );
            $this->add_control(
                'rr_thumbnail_image_after',
                [
                    'label' => esc_html__( 'Choose After Thumbnail Image', 'rr-core' ),
                    'type' => \Elementor\Controls_Manager::MEDIA,
                    'default' => [
                        'url' => \Elementor\Utils::get_placeholder_image_src(),
                    ],
                ]
            );
    
            $this->add_group_control(
                Group_Control_Image_Size::get_type(),
                [
                    'name' => 'rr_thumbnail_size',
                    'default' => 'full',
                    'exclude' => [
                        'custom'
                    ]
                ]
            );
            $this->end_controls_section();
	}

	// style_tab_content
	protected function style_tab_content(){
        $this->rr_section_style_controls('cta_section', 'Section Style', '.ele-section'); 
        $this->rr_basic_style_controls('cta_title', 'Cta Title', '.rr-el-re-Title');
        $this->rr_basic_style_controls('cta_content', 'Cta Content', '.rr-el-content');
	}


/**
 * Render the widget ouRRut on the frontend.
 *
 * Written in PHP and used to generate the final HTML.
 *
 * @since 1.0.0
 *
 * @access protected
 */
protected function render() {
    $settings = $this->get_settings_for_display();

    ?>

<?php if ( $settings['rr_design_style']  == 'layout-2' ):

    $this->add_render_attribute('title_args', 'class', 'happy-customer__content-wrapper-title rr-el-re-Title');
?>

<?php else: 
    // thumbnail image
    if ( !empty($settings['rr_thumbnail_image_before']['url']) ) {
        $rr_thumbnail_image_before = !empty($settings['rr_thumbnail_image_before']['id']) ? wp_get_attachment_image_url( $settings['rr_thumbnail_image_before']['id'], $settings['rr_thumbnail_size_size']) : $settings['rr_thumbnail_image_before']['url'];
        $rr_thumbnail_image_alt = get_post_meta($settings["rr_thumbnail_image_before"]["id"], "_wp_attachment_image_alt", true);
    }
        // thumbnail image
        if ( !empty($settings['rr_thumbnail_image_after']['url']) ) {
            $rr_thumbnail_image_after = !empty($settings['rr_thumbnail_image_after']['id']) ? wp_get_attachment_image_url( $settings['rr_thumbnail_image_after']['id'], $settings['rr_thumbnail_size_size']) : $settings['rr_thumbnail_image_after']['url'];
            $rr_thumbnail_image_alt = get_post_meta($settings["rr_thumbnail_image_after"]["id"], "_wp_attachment_image_alt", true);
        }
    $this->add_render_attribute('title_args', 'class', 'title wow fadeInLeft animated rr-el-re-Title');   
?>
<div class="filter__area filter__space">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="filter__media filter__container">
                    <div class="pic pic--left" data-background="<?php echo esc_url($rr_thumbnail_image_before); ?>"></div>
                    <div class="pic pic--right" data-background="<?php echo esc_url($rr_thumbnail_image_after); ?>"></div>
                    <div class="comparison-ctrl">
                        <img class="img-fluid" src="<?php echo get_template_directory_uri(  ); ?>/assets/imgs/filter/ctrl.svg" alt="icon not found">
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php endif; 
	}
}

$widgets_manager->register( new RR_Filter_Main() );