<?php
namespace RRCore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Repeater;
use \Elementor\Utils;
use \Elementor\Control_Media;
use RRCore\Elementor\Controls\Group_Control_RRBGGradient;
use RRCore\Elementor\Controls\Group_Control_RRGradient;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * RR Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class rr_Info_Banner extends Widget_Base {

    use \RRCore\Widgets\RRCoreElementFunctions;

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'info-banner';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Info Banner', 'rr-core' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'rr-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'rr-core' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'rr-core' ];
	}
    /**
         * contact form 7 setup.
         *
         * Adds different input fields to allow the user to change and customize the widget settings.
         *
         * @since 1.0.0
         *
         * @access protected
         */

         public function get_rr_contact_form(){
            if ( ! class_exists( 'WPCF7' ) ) {
                return;
            }
            $rr_cfa         = array();
            $rr_cf_args     = array( 'posts_per_page' => -1, 'post_type'=> 'wpcf7_contact_form' );
            $rr_forms       = get_posts( $rr_cf_args );
            $rr_cfa         = ['0' => esc_html__( 'Select Form', 'rr-core' ) ];
            if( $rr_forms ){
                foreach ( $rr_forms as $rr_form ){
                    $rr_cfa[$rr_form->ID] = $rr_form->post_title;
                }
            }else{
                $rr_cfa[ esc_html__( 'No contact form found', 'rr-core' ) ] = 0;
            }
            return $rr_cfa;
        }
	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */

    protected function register_controls(){
        $this->register_controls_section();
        $this->style_tab_content();
    }  

	protected function register_controls_section() {

        // layout Panel
        $this->start_controls_section(
            'rr_layout',
            [
                'label' => esc_html__('Design Layout', 'rr-core'),
            ]
        );
        $this->add_control(
            'rr_design_style',
            [
                'label' => esc_html__('Select Layout', 'rr-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Layout 1', 'rr-core'),
                    'layout-2' => esc_html__('Layout 2', 'rr-core'),
                    'layout-3' => esc_html__('Layout 3', 'rr-core'),
                    'layout-4' => esc_html__('Layout 4', 'rr-core'),
                ],
                'default' => 'layout-1',
            ]
        );

        $this->end_controls_section();

        $this->rr_section_title_render_controls('info_banner', 'Section Title', 'Sub Title', 'your title here', $default_description = 'Hic nesciunt galisum aut dolorem aperiam eum soluta quod ea cupiditate.');

        // button
        $this->rr_button_render('banner', 'Button', ['layout-1', 'layout-4']);        

        // _rr_image
		$this->start_controls_section(
            '_rr_image',
            [
                'label' => esc_html__('Thumbnail', 'rr-core'),
            ]
        );
        $this->add_control(
            'rr_image',
            [
                'label' => esc_html__( 'Choose Image', 'rr-core' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Image_Size::get_type(),
            [
                'name' => 'rr_image_size',
                'default' => 'full',
                'exclude' => [
                    'custom'
                ]
            ]
        );
        $this->end_controls_section();
        $this->start_controls_section(
            'rr-core_contact',
            [
                'label' => esc_html__('Contact Form', 'rr-core'),
                'condition' => [
                    'rr_design_style' => 'layout-1'
                ]
            ]
        );
        $this->add_control(
            'rr_contact_title',
            [
                'label'       => esc_html__( 'Title', 'rr-core' ),
                'type'        => \Elementor\Controls_Manager::TEXT,
                'default'     => esc_html__( 'Make an Appointment', 'rr-core' ),
                'placeholder' => esc_html__( 'Your Heading Text', 'rr-core' ),
                'label_block' => true,
            ]
        );
        $this->add_control(
            'rr_contact_subtitle',
            [
                'label'       => esc_html__( 'SubTitle', 'rr-core' ),
                'type'        => \Elementor\Controls_Manager::TEXT,
                'default'     => esc_html__( 'Contact us', 'rr-core' ),
                'placeholder' => esc_html__( 'Your Heading Sub Text', 'rr-core' ),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'rr-core_select_contact_form',
            [
                'label'   => esc_html__( 'Select Form', 'rr-core' ),
                'type'    => Controls_Manager::SELECT,
                'default' => '0',
                'options' => $this->get_rr_contact_form(), 
            ]
        );

        $this->
        end_controls_section(); 
	}

    // style_tab_content
    protected function style_tab_content(){
        $this->rr_section_style_controls('info_banner_section', 'Section - Style', '.rr-el-section'); 
        $this->rr_basic_style_controls('section_sub_title', 'Section - Sub Title', '.rr-el-sub-title');
        $this->rr_basic_style_controls('section_title', 'Section - Title', '.rr-el-title');
        $this->rr_basic_style_controls('section_desc', 'Section - Description', '.rr-el-desc');
        $this->rr_basic_style_controls('contact_title', 'Contact - Title', '.rr-con-title');
        $this->rr_basic_style_controls('contact_subtitle', 'Contact - Sub Title', '.rr-con-subtitle');
        $this->rr_link_controls_style('repiter_btn', 'Banner - Button', '.rr-el-btn');
        $this->rr_section_style_controls('info_banner_box', 'Form - Box Style', '.rr-form-section'); 
    }

	/**
	 * Render the widget ouRRut on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		?>

<?php if ( $settings['rr_design_style']  == 'layout-2' ):
    $bloginfo = get_bloginfo( 'name' );
    if ( !empty($settings['rr_image']['url']) ) {
        $rr_image = !empty($settings['rr_image']['id']) ? wp_get_attachment_image_url( $settings['rr_image']['id'], $settings['rr_image_size_size']) : $settings['rr_image']['url'];
        $rr_image_alt = get_post_meta($settings["rr_image"]["id"], "_wp_attachment_image_alt", true);
    }

    $this->add_render_attribute('title_args', 'class', 'rr-payment__title');
?>

<?php else:

    $bloginfo = get_bloginfo( 'name' );
    if ( !empty($settings['rr_image']['url']) ) {
        $rr_image = !empty($settings['rr_image']['id']) ? wp_get_attachment_image_url( $settings['rr_image']['id'], $settings['rr_image_size_size']) : $settings['rr_image']['url'];
        $rr_image_alt = get_post_meta($settings["rr_image"]["id"], "_wp_attachment_image_alt", true);
    }

    $this->add_render_attribute('title_args', 'class', 'banner__title banner-4__title banner-5__title rr-payment__title rr-el-title');
    // Link
    if ('2' == $settings['rr_banner_btn_link_type']) {
        $this->add_render_attribute('rr-button-arg', 'href', get_permalink($settings['rr_banner_btn_page_link']));
        $this->add_render_attribute('rr-button-arg', 'target', '_self');
        $this->add_render_attribute('rr-button-arg', 'rel', 'nofollow');
        $this->add_render_attribute('rr-button-arg', 'class', 'rr-btn btn-hover-white banner-4__btn-wrapper-btn rr-el-btn');
    } else {
        if ( ! empty( $settings['rr_banner_btn_link']['url'] ) ) {
            $this->add_link_attributes( 'rr-button-arg', $settings['rr_banner_btn_link'] );
            $this->add_render_attribute('rr-button-arg', 'class', 'rr-btn btn-hover-white banner-4__btn-wrapper-btn rr-el-btn');
        }
    }
    
?>
<section class="banner__area banner-4 banner-5  p-relative rr-el-section">
    <div class="banner__thumb-bg banner-5__thumb-bg" data-background="<?php echo esc_url($rr_image); ?>"></div>
    <div class="container">
        <div class="banner banner__space banner-4__space banner-5__space">
            <div class="row">
                <div class="col-12">
                    <div class="banner-5__wrapper">
                        <div class="banner__content banner-4__content banner-5__content p-relative z-index-1">
                            <?php if ( !empty($settings['rr_info_banner_sub_title']) ) : ?>
                            <h6 class="banner-5__subtitle rr-el-sub-title">
                                <?php echo rr_kses( $settings['rr_info_banner_sub_title'] ); ?></h6>
                            <?php endif; ?>
                            <?php
                                    if ( !empty($settings['rr_info_banner_title' ]) ) :
                                        printf( '<%1$s %2$s>%3$s</%1$s>',
                                        tag_escape( $settings['rr_info_banner_title_tag'] ),
                                        $this->get_render_attribute_string( 'title_args' ),
                                        rr_kses( $settings['rr_info_banner_title' ] )
                                        );
                                    endif;
                                ?>
                            <?php if ( !empty($settings['rr_info_banner_description']) ) : ?>
                            <p class="rr-el-desc" data-animation="pixfix-fadeInUp" data-delay="1200ms" data-duration="1400ms">
                                <?php echo rr_kses( $settings['rr_info_banner_description'] ); ?></p>
                            <?php endif; ?>
                            <a <?php echo $this->get_render_attribute_string( 'rr-button-arg' ); ?>><?php echo rr_kses($settings['rr_banner_btn_text']);?><i
                                    class="fa-solid fa-arrow-right"></i></a>
                        </div>
                        <div class="banner-5__form-wrapper rr-form-section">
                            <h6 class="banner-5__form-wrapper-subtitle wow fadeInLeft animated rr-con-subtitle" data-wow-delay=".3s"><?php echo rr_kses($settings['rr_contact_subtitle']); ?></h6>
                            <h3 class="banner-5__form-wrapper-title wow fadeInLeft animated rr-con-title" data-wow-delay=".5s"><?php echo rr_kses($settings['rr_contact_title']); ?></h3>
                            <div class="banner-5__form-wrapper-form" id="contact-us__form">
                                <?php if( !empty($settings['rr-core_select_contact_form']) ) : ?>
                                <?php echo do_shortcode( '[contact-form-7  id="'.$settings['rr-core_select_contact_form'].'"]' ); ?>
                                <?php else : ?>
                                <?php echo '<div class="alert alert-info"><p class="m-0">' . __('Please Select contact form.', 'rr-core' ). '</p></div>'; ?>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php endif; 
	}
}

$widgets_manager->register( new rr_Info_Banner() );