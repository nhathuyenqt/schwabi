<?php
namespace RRCore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Repeater;
use \Elementor\Utils;
use RRCore\Elementor\Controls\Group_Control_RRBGGradient;
use RRCore\Elementor\Controls\Group_Control_RRGradient;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * RR Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class rr_Shop extends Widget_Base {

    use \RRCore\Widgets\RRCoreElementFunctions;

    /**
     * Retrieve the widget name.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name() {
        return 'rr-shop';
    }

    /**
     * Retrieve the widget title.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title() {
        return __( 'Shop', 'rr-core' );
    }

    /**
     * Retrieve the widget icon.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'rr-icon';
    }

    /**
     * Retrieve the list of categories the widget belongs to.
     *
     * Used to determine where to display the widget in the editor.
     *
     * Note that currently Elementor supports only one category.
     * When multiple categories passed, Elementor uses the first one.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return array Widget categories.
     */
    public function get_categories() {
        return [ 'rr-core' ];
    }

    /**
     * Retrieve the list of scripts the widget depended on.
     *
     * Used to set scripts dependencies required to run the widget.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return array Widget scripts dependencies.
     */
    public function get_script_depends() {
        return [ 'rr-core' ];
    }

    /**
     * Register the widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     *
     * @access protected
     */

    protected function register_controls(){
        $this->register_controls_section();
        $this->style_tab_content();
    }
    protected function register_controls_section() {

        // layout Panel
        $this->start_controls_section(
            'rr_layout',
            [
                'label' => esc_html__('Design Layout', 'rr-core'),
            ]
        );
        $this->add_control(
            'rr_design_style',
            [
                'label' => esc_html__('Select Layout', 'rr-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Layout 1', 'rr-core'),
                    'layout-2' => esc_html__('Layout 2', 'rr-core'),
                    'layout-3' => esc_html__('Layout 3', 'rr-core'),
                ],
                'default' => 'layout-1',
            ]
        );

        $this->end_controls_section();


        // shop group
        $this->start_controls_section( 
            'rr_shops',
            [
                'label' => esc_html__('Shops List', 'rr-core'),
                'description' => esc_html__( 'Control all the style settings from Style tab', 'rr-core' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'rr_shops_hot_switcher',
            [
                'label' => esc_html__( 'Hot Product', 'rr-core' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Yes', 'rr-core' ),
                'label_off' => esc_html__( 'No', 'rr-core' ),
                'return_value' => 'yes',
                'default' => 'yes',
                'separator' => 'before',
            ]
        );


        $this->add_control(
            'rr_shop_discound_number', [
                'label' => esc_html__('Discount Number', 'rr-core'),
                'description' => rr_get_allowed_html_desc( 'basic' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('-80%', 'rr-core'),
            ]
        );
        $this->add_control(
            'rr_shops_discound_switcher',
            [
                'label' => esc_html__( 'Discount Product', 'rr-core' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Yes', 'rr-core' ),
                'label_off' => esc_html__( 'No', 'rr-core' ),
                'return_value' => 'yes',
                'default' => 'yes',
                'separator' => 'before',
            ]
        );
        $this->add_control(
            'repeater_condition',
            [
                'label' => __( 'Field condition', 'rr-core' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'style_1' => __( 'Style 1', 'rr-core' ),
                ],
                'default' => 'style_1',
                'frontend_available' => true,
                'style_transfer' => true,
            ]
        );
        // rating
        $this->add_control(
            'rr_testi_rating',
            [
                'label' => esc_html__('Select Rating Count', 'rr-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    '1' => esc_html__('Single Star', 'rr-core'),
                    '2' => esc_html__('2 Star', 'rr-core'),
                    '3' => esc_html__('3 Star', 'rr-core'),
                    '4' => esc_html__('4 Star', 'rr-core'),
                    '5' => esc_html__('5 Star', 'rr-core'),
                ],
                'default' => '5',
            ]
        );

       
        $this->add_control(
            'rr_shop_number', [
                'label' => esc_html__('Number Field', 'rr-core'),
                'description' => rr_get_allowed_html_desc( 'basic' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('a', 'rr-core'),
                'condition' => [
                    'repeater_condition' => 'style_2'
                ]
            ]
        );

        $this->add_control(
            'rr_shop_title', [
                'label' => esc_html__('Title', 'rr-core'),
                'description' => rr_get_allowed_html_desc( 'basic' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('shop Title', 'rr-core'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'rr_shop_price',
            [
                'label' => esc_html__('Regular Price', 'rr-core'),
                'description' => rr_get_allowed_html_desc( 'intermediate' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('230$', 'rr-core'),
                'label_block' => true,
            ]
        );
        $this->add_control(
            'rr_shop_price_descount',
            [
                'label' => esc_html__('Old Price', 'rr-core'),
                'description' => rr_get_allowed_html_desc( 'intermediate' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('250$', 'rr-core'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'rr_shops_link_switcher',
            [
                'label' => esc_html__( 'Add shops link', 'rr-core' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Yes', 'rr-core' ),
                'label_off' => esc_html__( 'No', 'rr-core' ),
                'return_value' => 'yes',
                'default' => 'yes',
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'rr_shops_link_type',
            [
                'label' => esc_html__( 'shop Link Type', 'rr-core' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    '1' => 'Custom Link',
                    '2' => 'Internal Page',
                ],
                'default' => '1',
                'condition' => [
                    'rr_shops_link_switcher' => 'yes'
                ]
            ]
        );

        $this->add_control(
            'rr_shops_link',
            [
                'label' => esc_html__( 'shop Link link', 'rr-core' ),
                'type' => \Elementor\Controls_Manager::URL,
                'dynamic' => [
                    'active' => true,
                ],
                'placeholder' => esc_html__( 'htRRs://your-link.com', 'rr-core' ),
                'show_external' => true,
                'default' => [
                    'url' => '#',
                    'is_external' => false,
                    'nofollow' => false,
                ],
                'condition' => [
                    'rr_shops_link_type' => '1',
                    'rr_shops_link_switcher' => 'yes',
                ]
            ]
        );

        $this->add_control(
            'rr_shops_page_link',
            [
                'label' => esc_html__( 'Select shop Link Page', 'rr-core' ),
                'type' => \Elementor\Controls_Manager::SELECT2,
                'label_block' => true,
                'options' => rr_get_all_pages(),
                'condition' => [
                    'rr_shops_link_type' => '2',
                    'rr_shops_link_switcher' => 'yes',
                ]
            ]
        );
        $this->add_control(
            'rr_image_thumb',
            [
                'label' => esc_html__( 'Choose Image', 'rr-core' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ], 
            ]
        );
        $this->add_group_control(
            Group_Control_Image_Size::get_type(),
            [
                'name' => 'rr_image_size',
                'default' => 'full',
                'exclude' => [
                    'custom'
                ]
            ]
        );

        $this->add_control(
            'rr_shop_btn', [
                'label' => esc_html__('Button', 'rr-core'),
                'description' => rr_get_allowed_html_desc( 'basic' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('Add To Cart', 'rr-core'),
                'label_block' => true,
            ]
        );      

        $this->end_controls_section();
        // shop group
        $this->start_controls_section( 
            'rr_shop_link',
            [
                'label' => esc_html__('Shops Link', 'rr-core'),
                'description' => esc_html__( 'Control all the style settings from Style tab', 'rr-core' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'rr_shop_shop_link',
            [
                'label' => esc_html__( 'Shop Link', 'text-domain' ),
                'type' => Controls_Manager::URL,
                'options' => [ 'url', 'is_external', 'nofollow' ],
                'default' => [
                    'url' => '',
                    'is_external' => true,
                    'nofollow' => true,
                ],
                'label_block' => true,
            ]
        );        
        
        $this->add_control(
            'rr_shop_cart_link',
            [
                'label' => esc_html__( 'Shop Wishlist Link', 'text-domain' ),
                'type' => Controls_Manager::URL,
                'options' => [ 'url', 'is_external', 'nofollow' ],
                'default' => [
                    'url' => '',
                    'is_external' => true,
                    'nofollow' => true,
                ],
                'label_block' => true,
            ]
        );       
        
        $this->add_control(
            'rr_shop_wishlist_link',
            [
                'label' => esc_html__( 'Shop Card Link', 'text-domain' ),
                'type' => Controls_Manager::URL,
                'options' => [ 'url', 'is_external', 'nofollow' ],
                'default' => [
                    'url' => '',
                    'is_external' => true,
                    'nofollow' => true,
                ],
                'label_block' => true,
            ]
        );

        $this->end_controls_section();

    }

    // style_tab_content
    protected function style_tab_content(){

        $this->rr_section_style_controls('shops_section', 'Section Style', '.ele-section');
        $this->rr_basic_style_controls('shops_title', 'Shops Title', '.rr-el-re-Title');
        $this->rr_basic_style_controls('shops_desc', 'Shops Price Old', '.rr-el-re-price');
        $this->rr_basic_style_controls('shops_price_old', 'Shops Price', '.rr-el-re-price-2');
        $this->rr_link_controls_style('repiter_btn', 'Shops - Button', '.rr-el-btn');
        
    }

    /**
     * Render the widget ouRRut on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     *
     * @access protected
     */
    protected function render() {
        $settings = $this->get_settings_for_display();

        ?>

<?php if ( $settings['rr_design_style']  == 'layout-2' ):
  
    $this->add_render_attribute('title_args', 'class', 'rr-video-title rr-el-title');
?>


<?php else: 
  
    $this->add_render_attribute('title_args', 'class', 'rr-section-title wow rrfadeUp rr-el-title');
    // Link
    if ( !empty($settings['rr_image_thumb']['url']) ) {
    $rr_image_thumb = !empty($settings['rr_image_thumb']['id']) ? wp_get_attachment_image_url( $settings['rr_image_thumb']['id'], $settings['rr_image_size_size']) : $settings['rr_image_thumb']['url'];
    $rr_image_alt = get_post_meta($settings["rr_image_thumb"]["id"], "_wp_attachment_image_alt", true);
    } 
    if ('2' == $settings['rr_shops_link_type']) {
        $link = get_permalink($settings['rr_shops_page_link']);
        $target = '_self';
        $rel = 'nofollow';
    } else {
        $link = !empty($settings['rr_shops_link']['url']) ? $settings['rr_shops_link']['url'] : '';
        $target = !empty($settings['rr_shops_link']['is_external']) ? '_blank' : '';
        $rel = !empty($settings['rr_shops_link']['nofollow']) ? 'nofollow' : '';
    }
?>

<div class="rr-fea-product__item rr-pro-img ele-section">
    <div class="rr-fea-product__thumb fix p-relative">
        <?php if(!empty($rr_image_thumb)) : ?>
        <img src="<?php echo esc_url($rr_image_thumb); ?>" alt="<?php echo esc_attr($rr_image_alt); ?>">
        <?php endif; ?>
        <?php if (!empty($settings['rr_shops_discound_switcher' ])): ?>
        <div class="rr-fea-product__thumb-text">
            <span><?php echo rr_kses($settings['rr_shop_discound_number']); ?></span>
        </div>
        <?php endif; ?>

        <div class="rr-fea-product__icon-box icon-box-3 rr-product-action">

            <div class="product-action-btn mb-6">
                <a href="<?php echo esc_url($settings['rr_shop_shop_link']['url']); ?>"
                    class="icon-btn woosq-btn woosq-btn-896 " data-id="896" data-effect="mfp-3d-unfold">
                    <svg width="20" height="18" viewBox="0 0 20 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path
                            d="M17.612 2.41452C17.1722 1.96607 16.65 1.61034 16.0752 1.36763C15.5005 1.12492 14.8844 1 14.2623 1C13.6401 1 13.0241 1.12492 12.4493 1.36763C11.8746 1.61034 11.3524 1.96607 10.9126 2.41452L9.99977 3.34476L9.08699 2.41452C8.19858 1.50912 6.99364 1.00047 5.73725 1.00047C4.48085 1.00047 3.27591 1.50912 2.38751 2.41452C1.4991 3.31992 1 4.5479 1 5.82833C1 7.10875 1.4991 8.33674 2.38751 9.24214L3.30029 10.1724L9.99977 17L16.6992 10.1724L17.612 9.24214C18.0521 8.79391 18.4011 8.26171 18.6393 7.67596C18.8774 7.0902 19 6.46237 19 5.82833C19 5.19428 18.8774 4.56645 18.6393 3.9807C18.4011 3.39494 18.0521 2.86275 17.612 2.41452Z"
                            stroke="#001D08" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                    </svg>
                </a>
            </div>

            <div class="product-action-btn mb-6">
                <a href="<?php echo esc_url($settings['rr_shop_cart_link']['url']); ?>"
                    class="icon-btn woosq-btn woosq-btn-896 " data-id="896" data-effect="mfp-3d-unfold">
                    <svg width="16" height="18" viewBox="0 0 16 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M11.8887 1L14.9997 3.90909L11.8887 6.81818" stroke="#001D08" stroke-width="1.5"
                            stroke-linecap="round" stroke-linejoin="round" />
                        <path
                            d="M1 8.27282V6.81827C1 6.04673 1.32777 5.30679 1.91121 4.76123C2.49464 4.21567 3.28595 3.90918 4.11106 3.90918H14.9998"
                            stroke="#001D08" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                        <path d="M4.11106 16.9998L1 14.0907L4.11106 11.1816" stroke="#001D08" stroke-width="1.5"
                            stroke-linecap="round" stroke-linejoin="round" />
                        <path
                            d="M14.9998 9.72705V11.1816C14.9998 11.9531 14.672 12.6931 14.0886 13.2386C13.5051 13.7842 12.7138 14.0907 11.8887 14.0907H1"
                            stroke="#001D08" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                    </svg>
                </a>
            </div>

            <div class="product-action-btn">
                <a href="<?php echo esc_url($settings['rr_shop_wishlist_link']['url']); ?>"
                    class="icon-btn woosq-btn woosq-btn-896 " data-id="896" data-effect="mfp-3d-unfold">
                    <svg width="24" height="18" viewBox="0 0 24 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M1 9C1 9 5 1 12 1C19 1 23 9 23 9C23 9 19 17 12 17C5 17 1 9 1 9Z" stroke="#001D08"
                            stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                        <path
                            d="M12 12C13.6569 12 15 10.6569 15 9C15 7.34315 13.6569 6 12 6C10.3431 6 9 7.34315 9 9C9 10.6569 10.3431 12 12 12Z"
                            stroke="#001D08" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                    </svg>
                </a>
            </div>


        </div>

        <?php if (!empty($settings['rr_shops_hot_switcher' ])): ?>
        <div class="product-action-btn-5">
            <h5>Hot</h5>
        </div>
        <?php endif; ?>
    </div>

    <div class="rr-fea-product__content">
        <div class="rr-fea-product__star">
            <?php
                $rr_rating = $settings['rr_testi_rating'];
                    for($i=1; $i<=$rr_rating; $i++) :
            ?>
            <i class="fa-solid fa-star"></i>
            <?php endfor; ?>
        </div>
        <h4 class="rr-fea-product__title-sm rr-el-re-Title"><a
                href="<?php echo esc_url($link); ?>"><?php echo rr_kses($settings['rr_shop_title' ]); ?></a></h4>
        <div class="rr-product-content-price">
            <span class="product-item-3-price">
                <span class="price">
                    <span class="woocs_price_code d-flex gap-6">
                        <del aria-hidden="true">
                            <?php if (!empty($settings['rr_shop_price_descount' ])): ?>
                            <span
                                class="woocommerce-price-amount amount rr-el-re-price-2"><?php echo rr_kses($settings['rr_shop_price_descount']); ?></span>
                            <?php endif; ?>
                        </del>
                        <?php if (!empty($settings['rr_shop_price' ])): ?>
                        <span
                            class="woocommerce-price-amount amount body-color rr-el-re-price"><?php echo rr_kses($settings['rr_shop_price']); ?></span>
                        <?php endif; ?>
                    </span>
                </span>
            </span>
        </div>
        <div class="rr-fea-product__link-box">
            <a href="<?php echo esc_url($link); ?>" class="cart-button icon-btn button rr-btn-cart rr-el-btn">
                <span></span><?php echo rr_kses($settings['rr_shop_btn']); ?>
            </a>
        </div>
    </div>
</div>
<?php endif; 
    }
}

$widgets_manager->register( new rr_Shop() ); 