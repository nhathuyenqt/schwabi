<?php
namespace RRCore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Repeater;
use \Elementor\Utils;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * RR Core
 * 
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class Our_Coaching extends Widget_Base {

    use \RRCore\Widgets\RRCoreElementFunctions;

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'our_coaching';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'our coaching', 'rr-core' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'rr-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'rr-core' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'rr-core' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
    protected static function get_profile_names()
    {
        return [
            '500px' => esc_html__('500px', 'rr-core'),
            'apple' => esc_html__('Apple', 'rr-core'),
            'behance' => esc_html__('Behance', 'rr-core'),
            'bitbucket' => esc_html__('BitBucket', 'rr-core'),
            'codepen' => esc_html__('CodePen', 'rr-core'),
            'delicious' => esc_html__('Delicious', 'rr-core'),
            'deviantart' => esc_html__('DeviantArt', 'rr-core'),
            'digg' => esc_html__('Digg', 'rr-core'),
            'dribbble' => esc_html__('Dribbble', 'rr-core'),
            'email' => esc_html__('Email', 'rr-core'),
            'facebook-f' => esc_html__('Facebook', 'rr-core'),
            'flickr' => esc_html__('Flicker', 'rr-core'),
            'foursquare' => esc_html__('FourSquare', 'rr-core'),
            'github' => esc_html__('Github', 'rr-core'),
            'houzz' => esc_html__('Houzz', 'rr-core'),
            'instagram' => esc_html__('Instagram', 'rr-core'),
            'jsfiddle' => esc_html__('JS Fiddle', 'rr-core'),
            'linkedin-in' => esc_html__('LinkedIn', 'rr-core'),
            'medium' => esc_html__('Medium', 'rr-core'),
            'pinterest-p' => esc_html__('Pinterest', 'rr-core'),
            'product-hunt' => esc_html__('Product Hunt', 'rr-core'),
            'reddit' => esc_html__('Reddit', 'rr-core'),
            'slideshare' => esc_html__('Slide Share', 'rr-core'),
            'snapchat' => esc_html__('Snapchat', 'rr-core'),
            'soundcloud' => esc_html__('SoundCloud', 'rr-core'),
            'spotify' => esc_html__('Spotify', 'rr-core'),
            'stack-overflow' => esc_html__('StackOverflow', 'rr-core'),
            'tripadvisor' => esc_html__('TripAdvisor', 'rr-core'),
            'tumblr' => esc_html__('Tumblr', 'rr-core'),
            'twitch' => esc_html__('Twitch', 'rr-core'),
            'twitter' => esc_html__('Twitter', 'rr-core'),
            'vimeo' => esc_html__('Vimeo', 'rr-core'),
            'vk' => esc_html__('VK', 'rr-core'),
            'website' => esc_html__('Website', 'rr-core'),
            'whatsapp' => esc_html__('WhatsApp', 'rr-core'),
            'wordpress' => esc_html__('WordPress', 'rr-core'),
            'xing' => esc_html__('Xing', 'rr-core'),
            'yelp' => esc_html__('Yelp', 'rr-core'),
            'youtube' => esc_html__('YouTube', 'rr-core'),
        ];
    }
    
    protected function register_controls(){
        $this->register_controls_section();
        $this->style_tab_content();
    }  

	protected function register_controls_section() {

        // layout Panel
        $this->start_controls_section(
            'rr_layout',
            [
                'label' => esc_html__('Design Layout', 'rr-core'),
            ]
        );
        $this->add_control(
            'rr_design_style',
            [
                'label' => esc_html__('Select Layout', 'rr-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Layout 1', 'rr-core'),
                    'layout-2' => esc_html__('Layout 2', 'rr-core'),
                ],
                'default' => 'layout-1',
            ]
        );

        $this->end_controls_section();

        
        // title/content
        $this->rr_section_title_render_controls('section', 'Section Title', 'Sub Title', 'your title here', $default_description = 'Hic nesciunt galisum aut dolorem aperiam eum soluta quod ea cupiditate.' );

        // Features group
        $this->start_controls_section(
            'rr_coaching',
            [
                'label' => esc_html__('Features List', 'rr-core'),
                'description' => esc_html__( 'Control all the style settings from Style tab', 'rr-core' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $repeater = new \Elementor\Repeater();


        $repeater->add_control(
            'rr_coaching_title', [
                'label' => esc_html__('Title', 'rr-core'),
                'description' => rr_get_allowed_html_desc( 'basic' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('coaching Title', 'rr-core'),
                'label_block' => true,
            ]
        );

        $repeater->add_control(
            'rr_coaching_desc', [
                'label' => esc_html__('Description', 'rr-core'),
                'description' => rr_get_allowed_html_desc( 'basic' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('coaching Description', 'rr-core'),
                'label_block' => true,
            ]
        );

        $repeater->add_control(
            'rr_coaching_link',
            [
                'label' => esc_html__( 'coaching Link link', 'rr-core' ),
                'type' => \Elementor\Controls_Manager::URL,
                'dynamic' => [
                    'active' => true,
                ],
                'placeholder' => esc_html__( 'htRRs://your-link.com', 'rr-core' ),
                'show_external' => true,
                'default' => [
                    'url' => '#',
                    'is_external' => false,
                    'nofollow' => false,
                ],
            ]
        );

        $this->add_control(
            'rr_coaching_list',
            [
                'label' => esc_html__('Coaching - List', 'rr-core'),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'rr_coaching_title' => esc_html__('Discover', 'rr-core'),
                    ],
                    [
                        'rr_coaching_title' => esc_html__('Define', 'rr-core')
                    ],
                    [
                        'rr_coaching_title' => esc_html__('Develop', 'rr-core')
                    ]
                ],
                'title_field' => '{{{ rr_coaching_title }}}',
            ]
        );
        $this->end_controls_section();
                // _rr_image
		$this->start_controls_section(
            '_rr_image',
            [
                'label' => esc_html__('Thumbnail', 'rr-core'),
            ]
        );
        $this->add_control(
            'rr_image_bg',
            [
                'label' => esc_html__( 'Choose BG Image', 'rr-core' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );
        $this->add_control(
            'rr_image',
            [
                'label' => esc_html__( 'Choose Image', 'rr-core' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );


        $this->add_group_control(
            Group_Control_Image_Size::get_type(),
            [
                'name' => 'rr_image_size',
                'default' => 'full',
                'exclude' => [
                    'custom'
                ]
            ]
        );

        $this->end_controls_section();
        
        $this->start_controls_section(
            '_section_social',
            [
                'label' => esc_html__('Social Profiles', 'rr-core'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'show_profiles',
            [
                'label' => esc_html__('Show Profiles', 'rr-core'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Show', 'rr-core'),
                'label_off' => esc_html__('Hide', 'rr-core'),
                'return_value' => 'yes',
                'default' => 'yes',
                'separator' => 'before',
                'style_transfer' => true,
            ]
        );

        $repeater = new Repeater();

        $repeater->add_control(
            'name',
            [
                'label' => esc_html__('Profile Name', 'rr-core'),
                'type' => Controls_Manager::SELECT2,
                'label_block' => true,
                'select2options' => [
                    'allowClear' => false,
                ],
                'options' => self::get_profile_names()
            ]
        );

        $repeater->add_control(
            'link', [
                'label' => esc_html__('Profile Link', 'rr-core'),
                'placeholder' => esc_html__('Add your profile link', 'rr-core'),
                'type' => Controls_Manager::URL,
                'label_block' => true,
                'autocomplete' => false,
                'show_external' => false,
                'condition' => [
                    'name!' => 'email'
                ],
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );
        $this->add_control(
            'profiles',
            [
                'show_label' => false,
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'title_field' => '<# print(name.slice(0,1).toUpperCase() + name.slice(1)) #>',
                'default' => [
                    [
                        'link' => ['url' => 'htRRs://facebook.com/'],
                        'name' => 'facebook'
                    ],
                    [
                        'link' => ['url' => 'htRRs://linkedin.com/'],
                        'name' => 'linkedin'
                    ],
                    [
                        'link' => ['url' => 'htRRs://twitter.com/'],
                        'name' => 'twitter'
                    ]
                ],
            ]
        );
        $this->end_controls_section();

	}

    // style_tab_content
    protected function style_tab_content(){
        $this->rr_section_style_controls('coaching_section', 'Section - Style', '.rr-el-section'); 
        $this->rr_basic_style_controls('repiter_sub_title', 'Section - Sub Title', '.rr-el-sub-title');
        $this->rr_basic_style_controls('coaching_title', 'Section Title', '.rr-el-re-Title');
        $this->rr_basic_style_controls('repiter_rp_title', 'Features - Rp Title', '.rr-el-rp-title');
        $this->rr_basic_style_controls('repiter_rp_desc', 'Features - desc', '.rr-el-rp-desc');
        $this->rr_section_style_controls('coaching_box', 'Features - Box', '.rr-el-box'); 
        $this->rr_link_controls_style('features_icon', 'Features - Icon', '.rr-el-icon');
    } 

	/**
	 * Render the widget ouRRut on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		?>

<?php if ( $settings['rr_design_style']  == 'layout-2' ) : 
?>

<?php else: 

if ( !empty($settings['rr_image']['url']) ) {
    $rr_image = !empty($settings['rr_image']['id']) ? wp_get_attachment_image_url( $settings['rr_image']['id'], $settings['rr_image_size_size']) : $settings['rr_image']['url'];
    $rr_image_alt = get_post_meta($settings["rr_image"]["id"], "_wp_attachment_image_alt", true);
}
if ( !empty($settings['rr_image_bg']['url']) ) {
    $rr_image_bg = !empty($settings['rr_image_bg']['id']) ? wp_get_attachment_image_url( $settings['rr_image_bg']['id'], $settings['rr_image_size_size']) : $settings['rr_image_bg']['url'];
    $rr_image_alt = get_post_meta($settings["rr_image_bg"]["id"], "_wp_attachment_image_alt", true);
}
    $this->add_render_attribute('title_args', 'class', 'section__title-wrapper-title wow fadeInLeft animated rr-el-re-Title'); 
?>
<section class="section-space-top gray-bg  p-relative overflow-hidden">
    <div class="coaching__area rr-el-section position-relative overflow-hidden section-space-top bottom custom-width border">
        <div class="coaching__bg-img" data-background="<?php echo esc_url($rr_image_bg);?>"></div>
        <div class="container">
            <div class="row">
                <div class="section__title-wrapper mb-60">
                    <?php if ( !empty($settings['rr_section_sub_title']) ) : ?>
                    <h6 class="section__title-wrapper-black-subtitle mb-10 wow fadeInLeft animated rr-el-sub-title"
                        data-wow-delay=".2s">
                        <svg width="20" height="21" viewBox="0 0 20 21" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <g clip-path="url(#clip0_3756_125)">
                                <path
                                    d="M19.3 2.67377C19.2618 2.59399 19.1936 2.53259 19.1103 2.50302L12.1959 0.0621048C12.0224 0.000729911 11.832 0.0918964 11.7706 0.265396L10.2 4.70972H9.51302V3.57639C9.513 3.42331 9.47783 3.27229 9.41023 3.13495C9.34263 2.99761 9.2444 2.87762 9.12311 2.78424C9.00182 2.69086 8.86071 2.62656 8.71066 2.59632C8.5606 2.56608 8.4056 2.57069 8.25761 2.60981L0.248416 4.7208V4.7268C0.177823 4.74455 0.115123 4.78523 0.0701599 4.84247C0.0251971 4.89971 0.000518721 4.97027 0 5.04305L0 19.043C0 19.5953 0.447749 20.043 0.999998 20.043H10.3333C10.8856 20.043 11.3333 19.5953 11.3333 19.043V16.0184L14.0066 16.9622C14.1803 17.0233 14.3707 16.9324 14.4319 16.7587L19.3143 2.92847C19.3287 2.88716 19.3349 2.8434 19.3325 2.79969C19.33 2.75598 19.319 2.71319 19.2999 2.67377H19.3ZM8.42769 3.25264C8.47703 3.23964 8.52869 3.23812 8.57871 3.24819C8.62873 3.25827 8.67577 3.27968 8.71623 3.31076C8.7567 3.34193 8.78947 3.38197 8.81202 3.4278C8.83456 3.47363 8.84628 3.52402 8.84627 3.5751V4.70972H2.90366L8.42769 3.25264ZM10.6666 19.043C10.6666 19.1314 10.6315 19.2162 10.569 19.2787C10.5065 19.3412 10.4217 19.3764 10.3333 19.3764H0.999998C0.911593 19.3764 0.826808 19.3412 0.764296 19.2787C0.701784 19.2162 0.666665 19.1314 0.666665 19.043V5.37638H10.3333C10.4217 5.37638 10.5065 5.4115 10.569 5.47402C10.6315 5.53653 10.6666 5.62131 10.6666 5.70972V19.043ZM13.4067 6.64542L13.8333 6.44313L14.0366 6.86842L12.417 11.452C12.3877 11.5354 12.3926 11.627 12.4306 11.7068L12.7776 12.4327L12.6704 12.737L12.0093 12.0525C11.9734 12.0151 11.9294 11.9866 11.8806 11.9692C11.8318 11.9518 11.7797 11.9461 11.7283 11.9524L11.3333 12.0024V11.5557L11.6176 11.4197C11.6974 11.3816 11.7588 11.3134 11.7884 11.2301L12.4551 9.34479L13.4067 6.64542ZM14.0353 8.87034L14.7121 9.95775L14.5963 10.2854L13.7866 9.57642L14.0353 8.87034ZM11.3333 10.516V9.6L11.6613 9.58633L11.3333 10.516ZM11.9001 8.90942L11.3333 8.93271V8.489L12.1494 8.20434L11.9001 8.90942ZM13.9141 16.2224L11.3333 15.3114V12.6743L11.6456 12.6353L12.5667 13.5881C12.598 13.6199 12.6353 13.6452 12.6765 13.6624C12.7177 13.6795 12.762 13.6882 12.8066 13.688C12.8304 13.6882 12.8541 13.6856 12.8773 13.6804C12.9328 13.6683 12.9843 13.6423 13.0268 13.6047C13.0694 13.5671 13.1017 13.5193 13.1206 13.4657L13.4539 12.5227C13.4834 12.4393 13.4785 12.3477 13.4402 12.2681L13.0916 11.543L13.5477 10.2514L14.527 11.1098C14.5878 11.1631 14.6659 11.1925 14.7468 11.1925C14.7752 11.1925 14.8036 11.1887 14.8311 11.1814C14.8837 11.1676 14.9322 11.1411 14.9723 11.1043C15.0124 11.0675 15.0429 11.0214 15.0611 10.9701L15.3944 10.0271C15.411 9.97996 15.4168 9.9297 15.4114 9.88002C15.406 9.83035 15.3894 9.78253 15.363 9.74013L14.3196 8.06405L14.7103 6.9578C14.7249 6.91647 14.7312 6.87267 14.7289 6.8289C14.7265 6.78513 14.7156 6.74225 14.6966 6.70272L14.2901 5.85247C14.2712 5.81295 14.2447 5.77754 14.2121 5.74826C14.1796 5.71898 14.1416 5.6964 14.1003 5.68181C14.059 5.66722 14.0152 5.66091 13.9715 5.66324C13.9277 5.66557 13.8849 5.67649 13.8454 5.69538L12.9946 6.10213C12.9552 6.121 12.9199 6.14745 12.8906 6.17998C12.8614 6.21251 12.8389 6.25048 12.8244 6.29172L12.4333 7.39934L11.3333 7.78305V5.70972C11.3329 5.53913 11.2888 5.3715 11.2051 5.22286C11.1214 5.07422 11.0009 4.94954 10.8553 4.86076L11.4001 3.31601L11.5223 2.96947L12.2891 0.802812L18.5753 3.02172L13.9141 16.2224Z"
                                    fill="#034833" />
                                <path
                                    d="M16.5439 5.13329L16.7657 4.50454L17.3374 4.7062L17.1155 5.33495L16.5439 5.13329ZM11.972 3.51917L12.194 2.89062L12.7654 3.09242L12.5434 3.721L11.972 3.51917ZM15.4008 4.72979L15.6228 4.10104L16.1943 4.30287L15.9723 4.93145L15.4008 4.72979ZM13.115 3.92283L13.337 3.29425L13.9083 3.49608L13.6863 4.12466L13.115 3.92283ZM14.2579 4.326L14.48 3.69741L15.0514 3.89925L14.8294 4.52779L14.2579 4.326ZM5.51301 6.71091C3.67202 6.71091 2.17969 8.20324 2.17969 10.0442C2.17969 11.8852 3.67202 13.3776 5.51301 13.3776C7.35401 13.3776 8.84634 11.8852 8.84634 10.0442C8.84438 8.20424 7.35318 6.71299 5.51301 6.71091ZM7.92005 8.90457L7.4653 8.80465C7.2653 8.76053 7.06522 8.72557 6.86322 8.69528C6.83297 8.4935 6.79646 8.29271 6.75372 8.0932L6.65359 7.63861C7.20852 7.90276 7.65568 8.34975 7.92005 8.90457ZM2.84631 10.0442C2.84698 9.90799 2.85806 9.77194 2.87969 9.63732L3.70393 9.4539C3.83039 9.4259 3.95768 9.40265 4.08527 9.38065C4.05304 9.82251 4.05304 10.2661 4.08527 10.708C3.95764 10.686 3.83039 10.6626 3.70393 10.6346L2.87969 10.4513C2.85809 10.3167 2.84695 10.1806 2.84635 10.0442H2.84631ZM4.76172 9.29328C5.26137 9.24868 5.76399 9.24868 6.26364 9.29328C6.30839 9.79292 6.30839 10.2956 6.26364 10.7952C5.76399 10.84 5.26133 10.84 4.76168 10.7952C4.71693 10.2956 4.71697 9.79292 4.76172 9.29328ZM6.93926 9.38065C7.06701 9.40265 7.1943 9.4259 7.32059 9.4539L8.14497 9.63732C8.19119 9.90668 8.19119 10.182 8.14497 10.4513L7.32059 10.6346C7.19434 10.6626 7.06701 10.686 6.93926 10.7083C6.97165 10.2664 6.97165 9.82262 6.93926 9.38065ZM5.91972 7.41095L6.10301 8.23565C6.13101 8.36195 6.1546 8.48924 6.17676 8.61699C5.73474 8.5846 5.29095 8.5846 4.84893 8.61699C4.87106 8.48924 4.89435 8.36195 4.92268 8.23565L5.10593 7.41095C5.37527 7.36521 5.65039 7.36521 5.91972 7.41095ZM4.37306 7.6362L4.27293 8.09095C4.22898 8.29095 4.19397 8.49103 4.16373 8.69303C3.96195 8.72316 3.76116 8.75957 3.56164 8.8022L3.10689 8.90232C3.37146 8.34799 3.81845 7.90139 4.37302 7.63732L4.37306 7.6362ZM3.10623 11.1829L3.56098 11.283C3.76098 11.3269 3.96085 11.3619 4.16306 11.3922C4.19319 11.594 4.2296 11.7948 4.27222 11.9943L4.37235 12.4489C3.8175 12.185 3.37024 11.7383 3.10556 11.1839L3.10623 11.1829ZM5.10622 12.6756L4.92293 11.8509C4.8946 11.7249 4.87135 11.5973 4.84918 11.4699C5.06993 11.486 5.2916 11.4969 5.51326 11.4969C5.73493 11.4969 5.95597 11.486 6.17701 11.4699C6.15489 11.5973 6.13126 11.7249 6.10326 11.8509L5.92001 12.6756C5.65068 12.7213 5.37556 12.7213 5.10622 12.6756ZM6.65289 12.4503L6.75301 11.9956C6.7973 11.7956 6.83197 11.5956 6.86259 11.3935C7.06434 11.3633 7.2651 11.3269 7.46459 11.2843L7.91918 11.1842C7.65505 11.7395 7.20779 12.1869 6.65259 12.4513L6.65289 12.4503ZM2.84635 16.0442H8.17967V16.7109H2.84635V16.0442ZM3.51302 17.3776H7.51301V18.0442H3.51302V17.3776ZM5.17968 14.7109H5.84635V15.3776H5.17968V14.7109ZM3.84635 14.7109H4.51302V15.3776H3.84635V14.7109ZM6.51301 14.7109H7.17968V15.3776H6.51301V14.7109Z"
                                    fill="#034833" />
                            </g>
                            <defs>
                                <clipPath id="clip0_3756_125">
                                    <rect width="20" height="20" fill="white" transform="translate(0 0.0429688)" />
                                </clipPath>
                            </defs>
                        </svg>
                        <?php echo rr_kses( $settings['rr_section_sub_title'] ); ?>
                    </h6>
                    <?php endif; ?>
                    <?php
                        if ( !empty($settings['rr_section_title' ]) ) :
                            printf( '<%1$s %2$s>%3$s</%1$s>',
                            tag_escape( $settings['rr_section_title_tag'] ),
                            $this->get_render_attribute_string( 'title_args' ),
                            rr_kses( $settings['rr_section_title' ] )
                            );
                        endif;
                    ?>
                </div>
            </div>
            <div class="row align-items-center">
                <div class="col-md-8">
                    <div class="coaching__content">
                        <?php foreach ($settings['rr_coaching_list'] as $key => $item) :

                        // thumbnail image
                        if ( !empty($item['rr_coaching_main_image']['url']) ) {
                            $rr_coaching_main_image = !empty($item['rr_coaching_main_image']['id']) ? wp_get_attachment_image_url( $item['rr_coaching_main_image']['id'], 'full' ) : $item['rr_coaching_main_image']['url'];
                            $rr_coaching_main_image_alt = get_post_meta($item["rr_coaching_main_image"]["id"], "_wp_attachment_image_alt", true);
                        }
                    ?>
                        <div class="coaching__content-box wow fadeInLeft animated rr-el-box" data-wow-delay=".4s">
                            <div class="coaching__content-box-text">
                                <?php if ( !empty($item['rr_coaching_title']) ) : ?>
                                <h5 class="rr-el-rp-title"><?php echo rr_kses($item['rr_coaching_title']); ?></h5>
                                <?php endif; ?>
                                <?php if ( !empty($item['rr_coaching_desc']) ) : ?>
                                <p class="rr-el-rp-desc"><?php echo rr_kses($item['rr_coaching_desc']);?></p>
                                <?php endif; ?>
                            </div>
                            <div class="coaching__content-box-button">
                                <a class="rr-el-icon" href="<?php echo esc_url($item['rr_coaching_link']['url']);?>"><i class="fa-solid fa-arrow-right"></i></a>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="coaching__media">
                        <div class="coaching__media-thumb" data-tilt>
                            <?php if(!empty($rr_image)) : ?>
                            <img src="<?php echo esc_url($rr_image); ?>" alt="<?php echo esc_attr($rr_image_alt); ?>">
                            <?php endif; ?>
                        </div>
                        <div class="coaching__media-social">
                            <div class="coaching__media-social-icon">
                                <?php
                                foreach ($settings['profiles'] as $profile) :
                                    $icon = $profile['name'];
                                    $url = esc_url($profile['link']['url']);
                                    
                                    printf('<a target="_blank" rel="noopener"  href="%s" ><i class="fa-brands fa-%s"></i></a>',
                                        $url,
                                        esc_attr($icon)
                                    );
                                endforeach; 
                            ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php endif;
	}
}
$widgets_manager->register( new Our_Coaching() );