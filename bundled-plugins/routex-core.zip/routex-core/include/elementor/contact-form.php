<?php
namespace RRCore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Repeater;
use \Elementor\Utils;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * RR Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class rr_Contact_Form extends Widget_Base {

	 use \RRCore\Widgets\RRCoreElementFunctions;

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'contact-form';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Contact Form', 'rr-core' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'rr-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'rr-core' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'rr-core' ];
	}
    /**
         * contact form 7 setup.
         *
         * Adds different input fields to allow the user to change and customize the widget settings.
         *
         * @since 1.0.0
         *
         * @access protected
         */

    public function get_rr_contact_form(){
        if ( ! class_exists( 'WPCF7' ) ) {
            return;
        }
        $rr_cfa         = array();
        $rr_cf_args     = array( 'posts_per_page' => -1, 'post_type'=> 'wpcf7_contact_form' );
        $rr_forms       = get_posts( $rr_cf_args );
        $rr_cfa         = ['0' => esc_html__( 'Select Form', 'rr-core' ) ];
        if( $rr_forms ){
            foreach ( $rr_forms as $rr_form ){
                $rr_cfa[$rr_form->ID] = $rr_form->post_title;
            }
        }else{
            $rr_cfa[ esc_html__( 'No contact form found', 'rr-core' ) ] = 0;
        }
        return $rr_cfa;
    }

  /**
     * Register the widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     *
     * @access protected
     */


    protected static function get_profile_names()
    {
        return [
            'apple' => esc_html__('Apple', 'rr-core'),
            'behance' => esc_html__('Behance', 'rr-core'),
            'bitbucket' => esc_html__('BitBucket', 'rr-core'),
            'codepen' => esc_html__('CodePen', 'rr-core'),
            'delicious' => esc_html__('Delicious', 'rr-core'),
            'deviantart' => esc_html__('DeviantArt', 'rr-core'),
            'digg' => esc_html__('Digg', 'rr-core'),
            'dribbble' => esc_html__('Dribbble', 'rr-core'),
            'email' => esc_html__('Email', 'rr-core'),
            'facebook-f' => esc_html__('Facebook', 'rr-core'),
            'flickr' => esc_html__('Flicker', 'rr-core'),
            'foursquare' => esc_html__('FourSquare', 'rr-core'),
            'github' => esc_html__('Github', 'rr-core'),
            'houzz' => esc_html__('Houzz', 'rr-core'),
            'instagram' => esc_html__('Instagram', 'rr-core'),
            'jsfiddle' => esc_html__('JS Fiddle', 'rr-core'),
            'linkedin-in' => esc_html__('LinkedIn', 'rr-core'),
            'medium' => esc_html__('Medium', 'rr-core'),
            'pinterest' => esc_html__('Pinterest', 'rr-core'),
            'product-hunt' => esc_html__('Product Hunt', 'rr-core'),
            'reddit' => esc_html__('Reddit', 'rr-core'),
            'slideshare' => esc_html__('Slide Share', 'rr-core'),
            'snapchat' => esc_html__('Snapchat', 'rr-core'),
            'soundcloud' => esc_html__('SoundCloud', 'rr-core'),
            'spotify' => esc_html__('Spotify', 'rr-core'),
            'stack-overflow' => esc_html__('StackOverflow', 'rr-core'),
            'tripadvisor' => esc_html__('TripAdvisor', 'rr-core'),
            'tumblr' => esc_html__('Tumblr', 'rr-core'),
            'twitch' => esc_html__('Twitch', 'rr-core'),
            'twitter' => esc_html__('Twitter', 'rr-core'),
            'vimeo' => esc_html__('Vimeo', 'rr-core'),
            'vk' => esc_html__('VK', 'rr-core'),
            'website' => esc_html__('Website', 'rr-core'),
            'whatsapp' => esc_html__('WhatsApp', 'rr-core'),
            'wordpress' => esc_html__('WordPress', 'rr-core'),
            'xing' => esc_html__('Xing', 'rr-core'),
            'yelp' => esc_html__('Yelp', 'rr-core'),
            'youtube' => esc_html__('YouTube', 'rr-core'),
        ];
    }
	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */

    protected function register_controls(){
		$this->register_controls_section();
		$this->style_tab_content();
	}	

	protected function register_controls_section() {

        // layout Panel
        $this->start_controls_section(
            'rr_layout',
            [
                'label' => esc_html__('Design Layout', 'rr-core'),
            ]
        );
        $this->add_control(
            'rr_design_style',
            [
                'label' => esc_html__('Select Layout', 'rr-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Layout 1', 'rr-core'),
                    'layout-2' => esc_html__('Layout 2', 'rr-core'),
                    'layout-3' => esc_html__('Layout 3', 'rr-core'),
                    'layout-4' => esc_html__('Layout 4', 'rr-core'),
                    'layout-5' => esc_html__('Layout 5', 'rr-core'),
                    'layout-6' => esc_html__('Layout 6', 'rr-core'),
                ],
                'default' => 'layout-1',
            ]
        );

        $this->end_controls_section();

        // title/content
        $this->rr_section_title_render_controls('section', 'Section Title', 'Sub Title', 'your title here', $default_description = 'Hic nesciunt galisum aut dolorem aperiam eum soluta quod ea cupiditate.',['layout-1', 'layout-2', 'layout-3', 'layout-4', 'layout-5', 'layout-6']);

        // social info
        $this->start_controls_section(
            'rr_shap_section',
                [
                    'label' => esc_html__( 'Shape', 'rr-core' ),
                    'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
                    'condition' => [
                        'rr_design_style' => ['layout-6']
                    ]
                ]
            );
    
            $this->add_control(
                'rr_shape_switcher',
                [
                    'label' => esc_html__( 'Shape', 'rr-core' ),
                    'type' => \Elementor\Controls_Manager::SWITCHER,
                    'label_on' => esc_html__( 'Yes', 'rr-core' ),
                    'label_off' => esc_html__( 'No', 'rr-core' ),
                    'return_value' => 'yes',
                    'default' => 'yes',
                    'separator' => 'before',
                ]
            );
    
            $this->end_controls_section();
        $this->start_controls_section(
            'rr-core_contact',
            [
                'label' => esc_html__('Contact Form', 'rr-core'),
            ]
        );

        $this->add_control(
            'rr-core_select_contact_form',
            [
                'label'   => esc_html__( 'Select Form', 'rr-core' ),
                'type'    => Controls_Manager::SELECT,
                'default' => '0',
                'options' => $this->get_rr_contact_form(),
            ]
        );

        $this->
        end_controls_section(); 

        // _rr_image
        $this->start_controls_section(
            '_rr_image',
            [
                'label' => esc_html__('Thumbnail', 'rr-core'),
                'condition' => [
                    'rr_design_style' => ['layout-1', 'layout-2', 'layout-4', 'layout-6']
                ]
            ]
        );

        $this->add_control(
            'rr_image',
            [
                'label' => esc_html__( 'Choose Image', 'rr-core' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Image_Size::get_type(),
            [
                'name' => 'rr_image_size',
                'default' => 'full',
                'exclude' => [
                    'custom'
                ]
            ]
        );

        $this->end_controls_section();
         
         // Extra Contact Section
         $this->start_controls_section(
            'rr_extra_contact',
            [
                'label' => esc_html__('Contact Info', 'rr-core'),
                'condition' => [
                    'rr_design_style' => ['layout-5']
                ]
            ]
        );
           
        $repeater = new \Elementor\Repeater();
        
        $repeater->add_control(
            'rr_contact_title',
            [
                'label' => esc_html__('Contact Title', 'rr-core'),
                'type' => Controls_Manager::TEXT,
                'title' => esc_html__('Enter Contact Title', 'rr-core'),
                'label_block' => true,
                'default'   => ' Mistakes To Avoid',
            ]
        );
        $this->add_control(
            'rr_contact_list_main',
            [
            'label'       => esc_html__( 'Contact List', 'rr-core' ),
            'type'        => \Elementor\Controls_Manager::REPEATER,
            'fields'      => $repeater->get_controls(),
            'default'     => [
                [
                'rr_extra_contact_title'   => esc_html__( ' Mistakes To Avoid', 'rr-core' ),
                ],
                [
                'rr_extra_contact_title'   => esc_html__( 'Your Startup', 'rr-core' ),
                ],
                [
                'rr_extra_contact_title'   => esc_html__( 'Knew About Fonts', 'rr-core' ),
                ],
                [
                'rr_extra_contact_title'   => esc_html__( 'Knew About Fonts', 'rr-core' ),
                ],
            ],
            'title_field' => '{{{ rr_extra_contact_title }}}',
            ]
        );

        $this->end_controls_section();
        

	}

    protected function style_tab_content(){
        $this->rr_section_style_controls('comint_section', 'Section - Style', '.rr-el-section');
        $this->rr_basic_style_controls('section_title', 'Section - Title', '.rr-el-title');
        $this->rr_basic_style_controls('contact_subtitle', 'contact - Sub Title', '.rr-el-subtitle');
        $this->rr_basic_style_controls('contact_desc', 'contact - Description', '.rr-el-desc');
        $this->rr_section_style_controls('comint_section_box', 'Contact - Box', '.rr-el-box');
	}

	/**
	 * Render the widget ouRRut on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		?>

<?php if ( $settings['rr_design_style']  == 'layout-2' ):
    $this->add_render_attribute('title_args', 'class', 'section__title-wrapper2-title wow fadeInLeft animated rr-el-title');
    if ( !empty($settings['rr_image']['url']) ) {
        $rr_image = !empty($settings['rr_image']['id']) ? wp_get_attachment_image_url( $settings['rr_image']['id'], $settings['rr_image_size_size']) : $settings['rr_image']['url'];
        $rr_image_alt = get_post_meta($settings["rr_image"]["id"], "_wp_attachment_image_alt", true);
    }
?>

<section class="ticket-booking section-space-top gray-bg position-relative z-1 rr-el-section">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="ticket-booking-wrapper">
                    <div class="ticket-booking-wrapper__from">
                        <div class="section__title-wrapper2 section__title-wrapper2-2 mb-40">
                            <?php if ( !empty($settings['rr_section_sub_title']) ) : ?>
                            <h6 class="section__title-wrapper2-black-subtitle white mb-10 wow fadeInLeft animated"
                                data-wow-delay=".3s">
                                <svg width="52" height="10" viewBox="0 0 52 10" fill="none"
                                    xmlns="http://www.w3.org/2000/svg">
                                    <g clip-path="url(#clip0_3800_135)">
                                        <path
                                            d="M4.78951 2.14437C5.58938 2.36766 6.41161 2.50135 7.24102 2.54299L13.9245 3.26714C15.4366 3.43986 16.9277 3.76256 18.3758 4.23048C19.165 4.49614 19.9243 4.84349 20.6413 5.2669C21.4175 5.78994 22.2251 6.26475 23.0596 6.68864C23.5625 6.92402 24.1122 7.04215 24.6674 7.03411C25.2786 6.99856 25.8565 6.7438 26.2951 6.3166C27.1388 5.44628 27.3713 4.38993 27.9228 3.71228C28.1509 3.37951 28.494 3.14288 28.8861 3.04791C29.3064 2.95474 29.7447 2.98472 30.1484 3.13427C31.0548 3.46398 31.8151 4.10423 32.2943 4.94135C32.8723 5.79839 33.3241 6.775 33.9818 7.69183C34.6219 8.67698 35.5705 9.42226 36.6791 9.81116C37.261 9.97733 37.8777 9.97733 38.4596 9.81116C39.0109 9.64765 39.5192 9.36403 39.9478 8.9807C40.7142 8.27735 41.3115 7.40973 41.6951 6.44282C42.0804 5.55257 42.3595 4.68889 42.7448 3.93151C43.1867 2.89622 43.989 2.05634 45.003 1.56765C46.0171 1.07897 47.1739 0.974642 48.259 1.27404C48.8354 1.41933 49.3741 1.6859 49.8393 2.05594C50.3044 2.42599 50.6852 2.89102 50.9564 3.41996C51.39 4.23627 51.5965 5.15404 51.5543 6.07742C51.5377 6.66905 51.4115 7.25247 51.1822 7.79813C51.0294 8.18346 50.9231 8.37613 50.9564 8.40271C50.9896 8.42928 51.149 8.26318 51.3749 7.89778C51.701 7.3528 51.9029 6.74258 51.9662 6.11063C52.0934 5.09968 51.9274 4.07346 51.4879 3.1542C51.2001 2.52884 50.7812 1.97266 50.2596 1.52332C49.7381 1.07399 49.126 0.742013 48.465 0.549886C47.6576 0.314234 46.8078 0.262331 45.9777 0.397987C45.1477 0.533642 44.3586 0.85342 43.6682 1.33384C42.9171 1.89515 42.3149 2.63192 41.9143 3.47975C41.4825 4.31021 41.1769 5.18716 40.7982 6.01762C40.464 6.84506 39.946 7.58567 39.2834 8.18347C38.9811 8.47409 38.6083 8.68086 38.2017 8.78339C37.7951 8.88592 37.3687 8.88064 36.9648 8.7681C36.0933 8.44143 35.3501 7.84273 34.8455 7.06068C34.2675 6.2568 33.8157 5.28018 33.1845 4.33678C32.8635 3.84764 32.4818 3.40117 32.0485 3.00804C31.5919 2.61118 31.0613 2.30862 30.4872 2.11779C29.8948 1.91517 29.2578 1.88068 28.6469 2.01814C28.0271 2.17131 27.4813 2.53834 27.1056 3.05455C26.4014 3.99795 26.1622 5.04765 25.5908 5.5725C25.3315 5.83263 24.9872 5.99065 24.6209 6.01762C24.2173 6.02071 23.8179 5.9345 23.4516 5.76517C22.6493 5.36762 21.8707 4.92396 21.1196 4.43644C20.342 3.99071 19.5177 3.632 18.6615 3.36681C17.1463 2.91365 15.5874 2.62192 14.0109 2.49649C11.1541 2.25731 8.86208 2.18423 7.2676 2.1045C6.44264 2.02614 5.61152 2.03952 4.78951 2.14437Z"
                                            fill="white" />
                                        <path
                                            d="M6.5238 6.2697C6.57695 6.13018 5.85945 5.7382 4.77653 5.08712C4.23175 4.76158 3.5873 4.36296 2.89636 3.89126C2.55089 3.65873 2.23199 3.39963 1.83337 3.13388C1.66268 3.0178 1.50459 2.88421 1.36167 2.73527C1.24212 2.61795 1.14726 2.47789 1.08265 2.32336C1.04943 2.19713 1.08265 2.20377 1.08265 2.15726C1.17899 2.06916 1.29914 2.01139 1.42811 1.99117L2.71699 1.64571C3.5408 1.41982 4.27825 1.20058 4.89611 0.981341C6.13183 0.582721 6.88921 0.263819 6.8427 0.124302C6.7962 -0.0152149 5.99897 0.0379361 4.71674 0.250534C4.05237 0.356832 3.32156 0.502993 2.48446 0.675728L1.15572 0.968051C0.816039 1.02987 0.504512 1.19726 0.265472 1.4464C0.117425 1.61431 0.0226135 1.82242 -0.00692081 2.04432C-0.0341129 2.24825 -0.0113082 2.45574 0.0595198 2.6489C0.170868 2.94985 0.347895 3.2222 0.577725 3.44614C0.76497 3.63879 0.974636 3.80831 1.20223 3.95105C1.58756 4.23009 1.97953 4.47591 2.35157 4.70179C3.0155 5.09883 3.70842 5.44528 4.42442 5.7382C5.66014 6.25641 6.47065 6.40257 6.5238 6.2697Z"
                                            fill="white" />
                                    </g>
                                    <defs>
                                        <clipPath id="clip0_3800_135">
                                            <rect width="52" height="9.86585" fill="white"
                                                transform="matrix(-1 0 0 1 52 0.0664062)" />
                                        </clipPath>
                                    </defs>
                                </svg>
                                <?php echo rr_kses( $settings['rr_section_sub_title'] ); ?>
                                <svg width="52" height="10" viewBox="0 0 52 10" fill="none"
                                    xmlns="http://www.w3.org/2000/svg">
                                    <g clip-path="url(#clip0_3800_139)">
                                        <path
                                            d="M47.2095 2.14437C46.4096 2.36766 45.5874 2.50135 44.758 2.54299L38.0745 3.26714C36.5625 3.43986 35.0713 3.76256 33.6232 4.23048C32.834 4.49614 32.0748 4.84349 31.3577 5.2669C30.5815 5.78994 29.7739 6.26475 28.9394 6.68864C28.4366 6.92402 27.8868 7.04215 27.3317 7.03411C26.7204 6.99856 26.1425 6.7438 25.704 6.3166C24.8602 5.44628 24.6277 4.38993 24.0763 3.71228C23.8482 3.37951 23.505 3.14288 23.1129 3.04791C22.6926 2.95474 22.2543 2.98472 21.8506 3.13427C20.9442 3.46398 20.1839 4.10423 19.7047 4.94135C19.1267 5.79839 18.675 6.775 18.0172 7.69183C17.3771 8.67698 16.4285 9.42226 15.3199 9.81116C14.738 9.97733 14.1213 9.97733 13.5394 9.81116C12.9881 9.64765 12.4799 9.36403 12.0512 8.9807C11.2848 8.27735 10.6875 7.40973 10.3039 6.44282C9.91861 5.55257 9.63957 4.68889 9.25423 3.93151C8.81236 2.89622 8.01001 2.05634 6.99598 1.56765C5.98195 1.07897 4.82509 0.974642 3.74 1.27404C3.16364 1.41933 2.62491 1.6859 2.15977 2.05594C1.69463 2.42599 1.3138 2.89102 1.04267 3.41996C0.609026 4.23627 0.40251 5.15404 0.444721 6.07742C0.461366 6.66905 0.587529 7.25247 0.816785 7.79813C0.969589 8.18346 1.07589 8.37613 1.04267 8.40271C1.00945 8.42928 0.849998 8.26318 0.624113 7.89778C0.297997 7.3528 0.0960956 6.74258 0.0328167 6.11063C-0.094422 5.09968 0.0716196 4.07346 0.511162 3.1542C0.798973 2.52884 1.21785 1.97266 1.73939 1.52332C2.26094 1.07399 2.87299 0.742013 3.53404 0.549886C4.3414 0.314234 5.19125 0.262331 6.02128 0.397987C6.85131 0.533642 7.64045 0.85342 8.33077 1.33384C9.08192 1.89515 9.6841 2.63192 10.0847 3.47975C10.5165 4.31021 10.8221 5.18716 11.2008 6.01762C11.535 6.84506 12.053 7.58567 12.7156 8.18347C13.0179 8.47409 13.3907 8.68086 13.7973 8.78339C14.204 8.88592 14.6303 8.88064 15.0342 8.7681C15.9058 8.44143 16.6489 7.84273 17.1536 7.06068C17.7316 6.2568 18.1833 5.28018 18.8145 4.33678C19.1355 3.84764 19.5172 3.40117 19.9505 3.00804C20.4071 2.61118 20.9377 2.30862 21.5118 2.11779C22.1043 1.91517 22.7412 1.88068 23.3521 2.01814C23.9719 2.17131 24.5177 2.53834 24.8934 3.05455C25.5977 3.99795 25.8368 5.04765 26.4082 5.5725C26.6675 5.83263 27.0118 5.99065 27.3782 6.01762C27.7818 6.02071 28.1811 5.9345 28.5475 5.76517C29.3497 5.36762 30.1284 4.92396 30.8794 4.43644C31.657 3.99071 32.4814 3.632 33.3375 3.36681C34.8527 2.91365 36.4116 2.62192 37.9881 2.49649C40.8449 2.25731 43.1369 2.18423 44.7314 2.1045C45.5564 2.02614 46.3875 2.03952 47.2095 2.14437Z"
                                            fill="white" />
                                        <path
                                            d="M45.4762 6.2697C45.4231 6.13018 46.1406 5.7382 47.2235 5.08712C47.7683 4.76158 48.4127 4.36296 49.1036 3.89126C49.4491 3.65873 49.768 3.39963 50.1666 3.13388C50.3373 3.0178 50.4954 2.88421 50.6383 2.73527C50.7579 2.61795 50.8527 2.47789 50.9173 2.32336C50.9506 2.19713 50.9173 2.20377 50.9173 2.15726C50.821 2.06916 50.7009 2.01139 50.5719 1.99117L49.283 1.64571C48.4592 1.41982 47.7218 1.20058 47.1039 0.981341C45.8682 0.582721 45.1108 0.263819 45.1573 0.124302C45.2038 -0.0152149 46.001 0.0379361 47.2833 0.250534C47.9476 0.356832 48.6784 0.502993 49.5155 0.675728L50.8443 0.968051C51.184 1.02987 51.4955 1.19726 51.7345 1.4464C51.8826 1.61431 51.9774 1.82242 52.0069 2.04432C52.0341 2.24825 52.0113 2.45574 51.9405 2.6489C51.8291 2.94985 51.6521 3.2222 51.4223 3.44614C51.235 3.63879 51.0254 3.80831 50.7978 3.95105C50.4124 4.23009 50.0205 4.47591 49.6484 4.70179C48.9845 5.09883 48.2916 5.44528 47.5756 5.7382C46.3399 6.25641 45.5294 6.40257 45.4762 6.2697Z"
                                            fill="white" />
                                    </g>
                                    <defs>
                                        <clipPath id="clip0_3800_139">
                                            <rect width="52" height="9.86585" fill="white"
                                                transform="translate(0 0.0664062)" />
                                        </clipPath>
                                    </defs>
                                </svg>
                            </h6>
                            <?php endif; ?>
                            <?php if ( !empty($settings['rr_section_title' ]) ) :
                                    printf( '<%1$s %2$s>%3$s</%1$s>',
                                    tag_escape( $settings['rr_section_title_tag'] ),
                                    $this->get_render_attribute_string( 'title_args' ),
                                    rr_kses( $settings['rr_section_title' ] )
                                    );
                                endif;?>
                        </div>
                        <?php if( !empty($settings['rr-core_select_contact_form']) ) : ?>
                        <?php echo do_shortcode( '[contact-form-7  id="'.$settings['rr-core_select_contact_form'].'"]' ); ?>
                        <?php else : ?>
                        <?php echo '<div class="alert alert-info"><p class="m-0">' . __('Please Select contact form.', 'rr-core' ). '</p></div>'; ?>
                        <?php endif; ?>

                    </div>
                    <div class="ticket-booking-wrapper__media">
                        <?php if(!empty($rr_image)) : ?>
                        <img src="<?php echo esc_url($rr_image); ?>" alt="<?php echo esc_attr($rr_image_alt); ?>">
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php elseif ( $settings['rr_design_style']  == 'layout-3' ):
    $this->add_render_attribute('title_args', 'class', 'teamdetail__from-content-title wow fadeInLeft rr-el-title');
    if ( !empty($settings['rr_image']['url']) ) {
        $rr_image = !empty($settings['rr_image']['id']) ? wp_get_attachment_image_url( $settings['rr_image']['id'], $settings['rr_image_size_size']) : $settings['rr_image']['url'];
        $rr_image_alt = get_post_meta($settings["rr_image"]["id"], "_wp_attachment_image_alt", true);
    }
?>
<div class="teamdetail__from pt-30 overflow-hidden">
    <div class="teamdetail__from-content rr-el-section">
        <?php if ( !empty($settings['rr_section_title' ]) ) :
            printf( '<%1$s %2$s>%3$s</%1$s>',
            tag_escape( $settings['rr_section_title_tag'] ),
            $this->get_render_attribute_string( 'title_args' ),
            rr_kses( $settings['rr_section_title' ] )
            );
        endif;?>

        <?php if ( !empty($settings['rr_section_description']) ) : ?>
        <p class="wow fadeInLeft rr-el-desc" data-wow-delay=".4s">
            <?php echo rr_kses( $settings['rr_section_description'] ); ?></p>
        <?php endif; ?>

        <div class="row">
            <?php if( !empty($settings['rr-core_select_contact_form']) ) : ?>
            <?php echo do_shortcode( '[contact-form-7  id="'.$settings['rr-core_select_contact_form'].'"]' ); ?>
            <?php else : ?>
            <?php echo '<div class="alert alert-info"><p class="m-0">' . __('Please Select contact form.', 'rr-core' ). '</p></div>'; ?>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php elseif ( $settings['rr_design_style']  == 'layout-4' ):
    $this->add_render_attribute('title_args', 'class', 'section__title-wrapper-title wow fadeInLeft rr-el-title');
    if ( !empty($settings['rr_image']['url']) ) {
        $rr_image = !empty($settings['rr_image']['id']) ? wp_get_attachment_image_url( $settings['rr_image']['id'], $settings['rr_image_size_size']) : $settings['rr_image']['url'];
        $rr_image_alt = get_post_meta($settings["rr_image"]["id"], "_wp_attachment_image_alt", true);
    }
?>
<section
    class="contact-us__area contact-us__space border bg-gray section-space-top mb-120 custom-width overflow-hidden rr-el-section">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-6">
                <div class="contact-us__widget mb-30" data-tilt>
                    <?php if(!empty($rr_image)) : ?>
                    <img src="<?php echo esc_url($rr_image); ?>" alt="<?php echo esc_attr($rr_image_alt); ?>">
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="contact-us__title-wrapper">
                    <div class="section__title-wrapper mb-40">
                        <?php if ( !empty($settings['rr_section_sub_title']) ) : ?>
                        <h6 class="section__title-wrapper-black-subtitle mb-10 wow fadeInLeft animated rr-el-subtitle"
                            data-wow-delay=".2s"><?php echo rr_kses( $settings['rr_section_sub_title'] ); ?>
                            <svg width="14" height="12" viewBox="0 0 14 12" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <g clip-path="url(#clip0_3843_1169)">
                                    <path d="M4.92578 10.3748L6.49623 9.68052L5.62583 9.07031L4.92578 10.3748Z"
                                        fill="#83CD20" />
                                    <path d="M4.92578 10.3743L5.00073 8L13.9088 0L5.66505 9.1113L4.92578 10.3743Z"
                                        fill="#83CD20" />
                                    <path d="M5 8L13.908 0L0 6.22704L5 8Z" fill="#83CD20" />
                                    <path d="M5.66406 9.1113L9.95686 12L13.9078 0L5.66406 9.1113Z" fill="#034833" />
                                </g>
                                <defs>
                                    <clipPath id="clip0_3843_1169">
                                        <rect width="13.908" height="12" fill="white" />
                                    </clipPath>
                                </defs>
                            </svg>
                        </h6>
                        <?php endif; ?>
                        <?php if ( !empty($settings['rr_section_title' ]) ) :
                        printf( '<%1$s %2$s>%3$s</%1$s>',
                        tag_escape( $settings['rr_section_title_tag'] ),
                        $this->get_render_attribute_string( 'title_args' ),
                        rr_kses( $settings['rr_section_title' ] )
                        );
                        endif;?>
                    </div>

                    <div class="contact-us__form-wrapper  rr-el-box">
                        <?php if( !empty($settings['rr-core_select_contact_form']) ) : ?>
                        <?php echo do_shortcode( '[contact-form-7  id="'.$settings['rr-core_select_contact_form'].'"]' ); ?>
                        <?php else : ?>
                        <?php echo '<div class="alert alert-info"><p class="m-0">' . __('Please Select contact form.', 'rr-core' ). '</p></div>'; ?>
                        <?php endif; ?>
                    </div>

                </div>
            </div>
        </div>
    </div>
</section>

<?php elseif ( $settings['rr_design_style']  == 'layout-5' ):
    $this->add_render_attribute('title_args', 'class', 'section__title-wrapper-title wow fadeInLeft  animated rr-el-title');
    if ( !empty($settings['rr_image']['url']) ) {
        $rr_image = !empty($settings['rr_image']['id']) ? wp_get_attachment_image_url( $settings['rr_image']['id'], $settings['rr_image_size_size']) : $settings['rr_image']['url'];
        $rr_image_alt = get_post_meta($settings["rr_image"]["id"], "_wp_attachment_image_alt", true);
    }
?>

<section class="contact-info__area contact-us__area contact-us rr-el-section ">
    <div class="container contact-info__shadow rr-el-box">
        <div class="row align-items-center">
            <div class="col-xl-6 col-lg-6">
                <div class="contact-info__content">
                    <div class="section__title-wrapper mb-20">
                        <?php if ( !empty($settings['rr_section_sub_title']) ) : ?>
                        <h6 class="section__title-wrapper-black-subtitle mb-10 wow fadeInLeft  animated rr-el-subtitle"
                            data-wow-delay=".2s">
                            <svg width="20" height="20" viewBox="0 0 20 20" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <g clip-path="url(#clip0_3830_53335)">
                                    <path
                                        d="M19.3 2.6308C19.2618 2.55102 19.1936 2.48962 19.1103 2.46005L12.1959 0.019136C12.0224 -0.0422388 11.832 0.0489276 11.7706 0.222427L10.2 4.66675H9.51302V3.53342C9.513 3.38035 9.47783 3.22932 9.41023 3.09198C9.34263 2.95464 9.2444 2.83466 9.12311 2.74127C9.00182 2.64789 8.86071 2.5836 8.71066 2.55335C8.5606 2.52311 8.4056 2.52773 8.25761 2.56684L0.248416 4.67783V4.68383C0.177823 4.70158 0.115123 4.74226 0.0701599 4.7995C0.0251971 4.85674 0.000518721 4.9273 0 5.00008L0 19.0001C0 19.5523 0.447749 20.0001 0.999998 20.0001H10.3333C10.8856 20.0001 11.3333 19.5523 11.3333 19.0001V15.9755L14.0066 16.9192C14.1803 16.9803 14.3707 16.8894 14.4319 16.7157L19.3143 2.8855C19.3287 2.84419 19.3349 2.80043 19.3325 2.75672C19.33 2.71301 19.319 2.67022 19.2999 2.6308H19.3ZM8.42769 3.20967C8.47703 3.19667 8.52869 3.19515 8.57871 3.20523C8.62873 3.2153 8.67577 3.23671 8.71623 3.2678C8.7567 3.29896 8.78947 3.339 8.81202 3.38483C8.83456 3.43066 8.84628 3.48105 8.84627 3.53213V4.66675H2.90366L8.42769 3.20967ZM10.6666 19.0001C10.6666 19.0885 10.6315 19.1732 10.569 19.2358C10.5065 19.2983 10.4217 19.3334 10.3333 19.3334H0.999998C0.911593 19.3334 0.826808 19.2983 0.764296 19.2358C0.701784 19.1732 0.666665 19.0885 0.666665 19.0001V5.33342H10.3333C10.4217 5.33342 10.5065 5.36853 10.569 5.43105C10.6315 5.49356 10.6666 5.57834 10.6666 5.66675V19.0001ZM13.4067 6.60246L13.8333 6.40016L14.0366 6.82545L12.417 11.4091C12.3877 11.4924 12.3926 11.5841 12.4306 11.6638L12.7776 12.3897L12.6704 12.6941L12.0093 12.0095C11.9734 11.9721 11.9294 11.9436 11.8806 11.9262C11.8318 11.9089 11.7797 11.9031 11.7283 11.9094L11.3333 11.9594V11.5127L11.6176 11.3767C11.6974 11.3386 11.7588 11.2704 11.7884 11.1871L12.4551 9.30182L13.4067 6.60246ZM14.0353 8.82737L14.7121 9.91478L14.5963 10.2424L13.7866 9.53345L14.0353 8.82737ZM11.3333 10.4731V9.55703L11.6613 9.54337L11.3333 10.4731ZM11.9001 8.86645L11.3333 8.88974V8.44603L12.1494 8.16137L11.9001 8.86645ZM13.9141 16.1794L11.3333 15.2684V12.6314L11.6456 12.5923L12.5667 13.5451C12.598 13.577 12.6353 13.6022 12.6765 13.6194C12.7177 13.6366 12.762 13.6453 12.8066 13.645C12.8304 13.6452 12.8541 13.6426 12.8773 13.6374C12.9328 13.6253 12.9843 13.5993 13.0268 13.5617C13.0694 13.5241 13.1017 13.4763 13.1206 13.4227L13.4539 12.4797C13.4834 12.3964 13.4785 12.3047 13.4402 12.2251L13.0916 11.5001L13.5477 10.2084L14.527 11.0668C14.5878 11.1201 14.6659 11.1495 14.7468 11.1495C14.7752 11.1495 14.8036 11.1457 14.8311 11.1384C14.8837 11.1246 14.9322 11.0982 14.9723 11.0613C15.0124 11.0245 15.0429 10.9785 15.0611 10.9272L15.3944 9.98411C15.411 9.93699 15.4168 9.88673 15.4114 9.83705C15.406 9.78738 15.3894 9.73956 15.363 9.69716L14.3196 8.02108L14.7103 6.91483C14.7249 6.8735 14.7312 6.8297 14.7289 6.78593C14.7265 6.74216 14.7156 6.69928 14.6966 6.65975L14.2901 5.8095C14.2712 5.76998 14.2447 5.73457 14.2121 5.70529C14.1796 5.67601 14.1416 5.65343 14.1003 5.63884C14.059 5.62426 14.0152 5.61795 13.9715 5.62028C13.9277 5.6226 13.8849 5.63353 13.8454 5.65242L12.9946 6.05916C12.9552 6.07803 12.9199 6.10448 12.8906 6.13701C12.8614 6.16954 12.8389 6.20751 12.8244 6.24875L12.4333 7.35637L11.3333 7.74008V5.66675C11.3329 5.49616 11.2888 5.32853 11.2051 5.17989C11.1214 5.03125 11.0009 4.90658 10.8553 4.81779L11.4001 3.27305L11.5223 2.9265L12.2891 0.759843L18.5753 2.97875L13.9141 16.1794Z"
                                        fill="#034833"></path>
                                    <path
                                        d="M16.5439 5.09032L16.7657 4.46157L17.3374 4.66324L17.1155 5.29198L16.5439 5.09032ZM11.972 3.4762L12.194 2.84766L12.7654 3.04945L12.5434 3.67803L11.972 3.4762ZM15.4008 4.68682L15.6228 4.05807L16.1943 4.2599L15.9723 4.88849L15.4008 4.68682ZM13.115 3.87986L13.337 3.25128L13.9083 3.45311L13.6863 4.0817L13.115 3.87986ZM14.2579 4.28303L14.48 3.65445L15.0514 3.85628L14.8294 4.48482L14.2579 4.28303ZM5.51301 6.66794C3.67202 6.66794 2.17969 8.16027 2.17969 10.0013C2.17969 11.8423 3.67202 13.3346 5.51301 13.3346C7.35401 13.3346 8.84634 11.8423 8.84634 10.0013C8.84438 8.16127 7.35318 6.67002 5.51301 6.66794ZM7.92005 8.8616L7.4653 8.76169C7.2653 8.71756 7.06522 8.6826 6.86322 8.65231C6.83297 8.45053 6.79646 8.24974 6.75372 8.05023L6.65359 7.59565C7.20852 7.85979 7.65568 8.30679 7.92005 8.8616ZM2.84631 10.0013C2.84698 9.86502 2.85806 9.72897 2.87969 9.59435L3.70393 9.41093C3.83039 9.38293 3.95768 9.35968 4.08527 9.33768C4.05304 9.77954 4.05304 10.2232 4.08527 10.665C3.95764 10.643 3.83039 10.6196 3.70393 10.5916L2.87969 10.4083C2.85809 10.2737 2.84695 10.1376 2.84635 10.0013H2.84631ZM4.76172 9.25031C5.26137 9.20572 5.76399 9.20572 6.26364 9.25031C6.30839 9.74995 6.30839 10.2526 6.26364 10.7522C5.76399 10.797 5.26133 10.797 4.76168 10.7522C4.71693 10.2526 4.71697 9.74995 4.76172 9.25031ZM6.93926 9.33768C7.06701 9.35968 7.1943 9.38293 7.32059 9.41093L8.14497 9.59435C8.19119 9.86371 8.19119 10.139 8.14497 10.4083L7.32059 10.5916C7.19434 10.6196 7.06701 10.643 6.93926 10.6653C6.97165 10.2234 6.97165 9.77965 6.93926 9.33768ZM5.91972 7.36798L6.10301 8.19269C6.13101 8.31898 6.1546 8.44627 6.17676 8.57402C5.73474 8.54163 5.29095 8.54163 4.84893 8.57402C4.87106 8.44627 4.89435 8.31898 4.92268 8.19269L5.10593 7.36798C5.37527 7.32224 5.65039 7.32224 5.91972 7.36798ZM4.37306 7.59323L4.27293 8.04798C4.22898 8.24798 4.19397 8.44806 4.16373 8.65006C3.96195 8.68019 3.76116 8.7166 3.56164 8.75923L3.10689 8.85935C3.37146 8.30502 3.81845 7.85842 4.37302 7.59435L4.37306 7.59323ZM3.10623 11.1399L3.56098 11.24C3.76098 11.284 3.96085 11.319 4.16306 11.3493C4.19319 11.551 4.2296 11.7518 4.27222 11.9513L4.37235 12.4059C3.8175 12.142 3.37024 11.6954 3.10556 11.1409L3.10623 11.1399ZM5.10622 12.6326L4.92293 11.8079C4.8946 11.6819 4.87135 11.5543 4.84918 11.4269C5.06993 11.443 5.2916 11.4539 5.51326 11.4539C5.73493 11.4539 5.95597 11.443 6.17701 11.4269C6.15489 11.5543 6.13126 11.6819 6.10326 11.8079L5.92001 12.6326C5.65068 12.6783 5.37556 12.6783 5.10622 12.6326ZM6.65289 12.4073L6.75301 11.9526C6.7973 11.7526 6.83197 11.5527 6.86259 11.3505C7.06434 11.3203 7.2651 11.2839 7.46459 11.2413L7.91918 11.1412C7.65505 11.6965 7.20779 12.144 6.65259 12.4083L6.65289 12.4073ZM2.84635 16.0013H8.17967V16.6679H2.84635V16.0013ZM3.51302 17.3346H7.51301V18.0012H3.51302V17.3346ZM5.17968 14.6679H5.84635V15.3346H5.17968V14.6679ZM3.84635 14.6679H4.51302V15.3346H3.84635V14.6679ZM6.51301 14.6679H7.17968V15.3346H6.51301V14.6679Z"
                                        fill="#034833"></path>
                                </g>
                                <defs>
                                    <clipPath id="clip0_3830_53335">
                                        <rect width="20" height="20" fill="white"></rect>
                                    </clipPath>
                                </defs>
                            </svg><?php echo rr_kses( $settings['rr_section_sub_title'] ); ?>
                        </h6>
                        <?php endif; ?>
                        <?php if ( !empty($settings['rr_section_title' ]) ) :
                        printf( '<%1$s %2$s>%3$s</%1$s>',
                        tag_escape( $settings['rr_section_title_tag'] ),
                        $this->get_render_attribute_string( 'title_args' ),
                        rr_kses( $settings['rr_section_title' ] )
                        );
                        endif;?>
                    </div>
                    <div class="contact-info__content-text wow fadeInLeft  animated" data-wow-delay=".4s">
                        <?php if ( !empty($settings['rr_section_description']) ) : ?>
                        <p class="rr-el-desc"><?php echo rr_kses( $settings['rr_section_description'] ); ?></p>
                        <?php endif; ?>
                        <div class="contact-info__content-text-list mt-20">
                            <ul>
                                <?php foreach($settings['rr_contact_list_main'] as $key => $item) : ?>
                                <li><i class="fa-solid fa-check"></i><?php echo rr_kses($item['rr_contact_title']); ?>
                                </li>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-6 col-lg-6">
                <div class="contact-us__title-wrapper">
                    <div class="contact-us__form-wrapper p-0">
                        <?php if( !empty($settings['rr-core_select_contact_form']) ) : ?>
                        <?php echo do_shortcode( '[contact-form-7  id="'.$settings['rr-core_select_contact_form'].'"]' ); ?>
                        <?php else : ?>
                        <?php echo '<div class="alert alert-info"><p class="m-0">' . __('Please Select contact form.', 'rr-core' ). '</p></div>'; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php elseif ( $settings['rr_design_style']  == 'layout-6' ):
    $this->add_render_attribute('title_args', 'class', 'apply-form-4__title rr-el-title');
    if ( !empty($settings['rr_image']['url']) ) {
        $rr_image = !empty($settings['rr_image']['id']) ? wp_get_attachment_image_url( $settings['rr_image']['id'], $settings['rr_image_size_size']) : $settings['rr_image']['url'];
        $rr_image_alt = get_post_meta($settings["rr_image"]["id"], "_wp_attachment_image_alt", true);
    }
?>
<section class="apply-form-4__area rr-el-section">
    <div class="apply-form-4__bg__1 d-none d-xl-block"></div>
    <div class="apply-form-4__bg__2"></div>
    <div class="apply-form-4__thumb__bg" data-background="<?php echo esc_url($rr_image); ?>"></div>
    <?php if ( !empty($settings['rr_shape_switcher']) ) : ?>
    <div class="apply-form-4__shape upDown d-none d-xxl-block">
        <img src="<?php echo get_template_directory_uri(  ); ?>/assets/imgs/apply-form-4/apply-form-4-shape.png"
            alt="image not found">
    </div>
    <?php endif; ?>
    <div class="container">
        <div class="row">
            <div class="col-xl-6 col-lg-6">
                <div class="apply-form-4__wrapper">
                    <div class="apply-form-4__top mb-40">
                        <span class="rr-el-subtitle"><?php echo rr_kses( $settings['rr_section_sub_title'] ); ?></span>
                        <?php if ( !empty($settings['rr_section_title' ]) ) :
                        printf( '<%1$s %2$s>%3$s</%1$s>',
                        tag_escape( $settings['rr_section_title_tag'] ),
                        $this->get_render_attribute_string( 'title_args' ),
                        rr_kses( $settings['rr_section_title' ] )
                        );
                        endif;?>
                        <p class="apply-form-4__dec rr-el-desc"><?php echo rr_kses( $settings['rr_section_description'] ); ?></p>
                    </div>
                    <?php if( !empty($settings['rr-core_select_contact_form']) ) : ?>
                    <?php echo do_shortcode( '[contact-form-7  id="'.$settings['rr-core_select_contact_form'].'"]' ); ?>
                    <?php else : ?>
                    <?php echo '<div class="alert alert-info"><p class="m-0">' . __('Please Select contact form.', 'rr-core' ). '</p></div>'; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</section>
<?php else :
    $this->add_render_attribute('title_args', 'class', 'section__title-wrapper-title wow fadeInLeft animated rr-el-title');

    if ( !empty($settings['rr_image']['url']) ) {
        $rr_image = !empty($settings['rr_image']['id']) ? wp_get_attachment_image_url( $settings['rr_image']['id'], $settings['rr_image_size_size']) : $settings['rr_image']['url'];
        $rr_image_alt = get_post_meta($settings["rr_image"]["id"], "_wp_attachment_image_alt", true);
    }
?>
<section class="contact-us__area border bg-gray section-space-top pb-337 custom-width overflow-hidden rr-el-section">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-6">
                <div class="contact-us__widget mb-30" data-tilt>
                    <?php if(!empty($rr_image)) : ?>
                    <img src="<?php echo esc_url($rr_image); ?>" alt="<?php echo esc_attr($rr_image_alt); ?>">
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="contact-us__title-wrapper">
                    <div class="section__title-wrapper mb-40">
                        
                        <?php if ( !empty($settings['rr_section_sub_title']) ) : ?>
                        <h6 class="section__title-wrapper-black-subtitle mb-10 wow fadeInLeft animated rr-el-subtitle"
                            data-wow-delay=".2s"><?php echo rr_kses( $settings['rr_section_sub_title'] ); ?>
                            <svg width="14" height="12" viewBox="0 0 14 12" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <g clip-path="url(#clip0_3843_1169)">
                                    <path d="M4.92578 10.3748L6.49623 9.68052L5.62583 9.07031L4.92578 10.3748Z"
                                        fill="#83CD20" />
                                    <path d="M4.92578 10.3743L5.00073 8L13.9088 0L5.66505 9.1113L4.92578 10.3743Z"
                                        fill="#83CD20" />
                                    <path d="M5 8L13.908 0L0 6.22704L5 8Z" fill="#83CD20" />
                                    <path d="M5.66406 9.1113L9.95686 12L13.9078 0L5.66406 9.1113Z" fill="#034833" />
                                </g>
                                <defs>
                                    <clipPath id="clip0_3843_1169">
                                        <rect width="13.908" height="12" fill="white" />
                                    </clipPath>
                                </defs>
                            </svg>
                        </h6>
                        <?php endif; ?>
                        <?php if ( !empty($settings['rr_section_title' ]) ) :
                        printf( '<%1$s %2$s>%3$s</%1$s>',
                        tag_escape( $settings['rr_section_title_tag'] ),
                        $this->get_render_attribute_string( 'title_args' ),
                        rr_kses( $settings['rr_section_title' ] )
                        );
                        endif;?>
                    </div>

                    <div class="contact-us__form-wrapper  rr-el-box">
                        <?php if( !empty($settings['rr-core_select_contact_form']) ) : ?>
                        <?php echo do_shortcode( '[contact-form-7  id="'.$settings['rr-core_select_contact_form'].'"]' ); ?>
                        <?php else : ?>
                        <?php echo '<div class="alert alert-info"><p class="m-0">' . __('Please Select contact form.', 'rr-core' ). '</p></div>'; ?>
                        <?php endif; ?>
                    </div>

                </div>
            </div>
        </div>
    </div>
</section>

<?php endif; 
	}
}

$widgets_manager->register( new rr_Contact_Form() );