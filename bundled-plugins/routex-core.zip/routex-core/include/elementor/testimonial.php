<?php
namespace RRCore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Repeater;
use \Elementor\Utils;
use RRCore\Elementor\Controls\Group_Control_RRBGGradient;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * RR Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class rr_Testimonial extends Widget_Base {

    use \RRCore\Widgets\RRCoreElementFunctions;

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'rr-testimonial';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Testimonial', 'rr-core' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'rr-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'rr-core' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'rr-core' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */

    protected function register_controls(){
        $this->register_controls_section();
        $this->style_tab_content();
    }   

	protected function register_controls_section() {

        // layout Panel
        $this->start_controls_section(
            'rr_layout',
            [
                'label' => esc_html__('Design Layout', 'rr-core'),
            ]
        );
        $this->add_control(
            'rr_design_style',
            [
                'label' => esc_html__('Select Layout', 'rr-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Layout 1', 'rr-core'),
                    'layout-2' => esc_html__('Layout 2', 'rr-core'),
                    'layout-3' => esc_html__('Layout 3', 'rr-core'),
                    'layout-4' => esc_html__('Layout 4', 'rr-core'),
                    'layout-5' => esc_html__('Layout 5', 'rr-core'),
                    'layout-6' => esc_html__('Layout 6', 'rr-core'),
                ],
                'default' => 'layout-1',
            ]
        );

        $this->end_controls_section();

        
        // rr_section_title
        $this->rr_section_title_render_controls('section', 'Section Title', 'Sub Title', 'your title here', $default_description = 'Hic nesciunt galisum aut dolorem aperiam eum soluta quod ea cupiditate.',['layout-3', 'layout-6', 'layout-7']);

        
        // Review group
        $this->start_controls_section(
            'review_list',
            [
                'label' => esc_html__( 'Review List', 'rr-core' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
                
            ]
        );
        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'repeater_condition',
            [
                'label' => __( 'Field condition', 'rr-core' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'style_1' => __( 'Style 1', 'rr-core' ),
                    'style_2' => __( 'Style 2', 'rr-core' ),
                    'style_3' => __( 'Style 3', 'rr-core' ),
                ],
                'default' => 'style_1',
                'frontend_available' => true,
                'style_transfer' => true,
            ]
        );

        $repeater->add_control(
            'brand_logo',
            [
                'label' => esc_html__('Client Image', 'rr-core'),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
                'condition' => [
                    'repeater_condition' => ['style_1','style_2']
                ]

            ]
        );
        $repeater->add_control(
            'quote_logo',
            [
                'label' => esc_html__('Quote Image', 'rr-core'),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
                'condition' => [
                    'repeater_condition' => ['style_2']
                ]

            ]
        );

        $repeater->add_control(
            'review_content',
            [
                'label' => esc_html__( 'Review Content', 'rr-core' ),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'rows' => 10,
                'default' => 'Aklima The standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested. Sections Bonorum et Malorum original.',
                'placeholder' => esc_html__( 'Type your review content here', 'rr-core' ),
            ]
        );

        $repeater->add_control(
            'reviewer_name', [
                'label' => esc_html__( 'Reviewer Name', 'rr-core' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__( 'Rasalina William' , 'rr-core' ),
                'label_block' => true,
                'condition' => [
                    'repeater_condition' => ['style_1', 'style_2']
                ]
            ]
        );

        $repeater->add_control(
            'reviewer_title', [
                'label' => esc_html__( 'Reviewer Title', 'rr-core' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__( '- CEO at YES Germany' , 'rr-core' ),
                'label_block' => true,
                'condition' => [
                    'repeater_condition' => ['style_1', 'style_2']
                ]
            ]
        );

      // rating
      $repeater->add_control(
        'rr_testi_rating',
        [
            'label' => esc_html__('Select Rating Count', 'rr-core'),
            'type' => Controls_Manager::SELECT,
            'options' => [
                '1' => esc_html__('Single Star', 'rr-core'),
                '2' => esc_html__('2 Star', 'rr-core'),
                '3' => esc_html__('3 Star', 'rr-core'),
                '4' => esc_html__('4 Star', 'rr-core'),
                '5' => esc_html__('5 Star', 'rr-core'),
            ],
            'default' => '5',
            'condition' => [
                'repeater_condition' => ['style_1']
            ]
        ]
    );

        $this->add_control(
            'reviews_list',
            [
                'label' => esc_html__( 'Review List', 'rr-core' ),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' =>  $repeater->get_controls(),
                'default' => [
                    [
                        'reviewer_name' => esc_html__( 'Rasalina William', 'rr-core' ),
                        'reviewer_title' => esc_html__( 'CEO at YES Germany', 'rr-core' ),
                        'review_content' => esc_html__( 'Construction can be defined as the art of building something. These construction quotes will put into perspective the fact that construction can be', 'rr-core' ),
                    ],
                    [
                        'reviewer_name' => esc_html__( 'Rasalina William 2', 'rr-core' ),
                        'reviewer_title' => esc_html__( 'CEO at YES Germany', 'rr-core' ),
                        'review_content' => esc_html__( 'Construction can be defined as the art of building something. These construction quotes will put into perspective the fact that construction can be', 'rr-core' ),
                    ],
                    [
                        'reviewer_name' => esc_html__( 'Rasalina William 3', 'rr-core' ),
                        'reviewer_title' => esc_html__( 'CEO at YES Germany', 'rr-core' ),
                        'review_content' => esc_html__( 'Construction can be defined as the art of building something. These construction quotes will put into perspective the fact that construction can be', 'rr-core' ),
                    ],

                ],
                'title_field' => '{{{ reviewer_name }}}',
            ]
        );
        $this->add_group_control(
            Group_Control_Image_Size::get_type(),
            [
                'name' => 'rr_image_size',
                'default' => 'full',
                'exclude' => ['custom'],
                'separator' => 'none',
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'testimonial_thumb',
            [
                'label' => esc_html__( 'Image', 'rr-core' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
                'condition' => [
                    'rr_design_style' => ['layout-1', 'layout-2', 'layout-3', 'layout-5', 'layout-6']
                ]
            ]
        );
        
        $this->add_control(
            'testimonial_image',
            [
                'label' => esc_html__('Client Image', 'rr-core'),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
            ]
        );
        $this->add_control(
            'testimonial_image_2',
            [
                'label' => esc_html__('Client Image 02', 'rr-core'),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
                'condition' => [
                    'rr_design_style' => ['layout-6']
                ]
            ]
        );
        $this->add_group_control(
            Group_Control_Image_Size::get_type(),
            [
                'name' => 'thumbnail',
                'default' => 'full',
                'exclude' => ['custom'],
                'separator' => 'none',
            ]
        );

        $this->end_controls_section();
      // section column
      $this->rr_columns('col', ['layout-1', 'layout-2', 'layout-4']);
      
        // Skill
        $this->start_controls_section(
            'rr_progress_bar',
            [
                'label' => esc_html__('Skill Bar', 'rr-core'),
                'condition' => [
                    'rr_design_style' => ['layout-6']
                ]
            ]
        );
        
        $this->add_control(
            'rr_skill_box_title',
            [
                'type' => Controls_Manager::TEXT,
                'label' => esc_html__( 'Skill Title', 'rr-core' ),
                'default' => esc_html__( 'Design', 'rr-core' ),
                'placeholder' => esc_html__( 'Type a skill name', 'rr-core' ),
                'label_block' => true
            ]
        );

        $this->add_control(
            'rr_skill_num',
            [
                'label'       => esc_html__( 'Skill Number', 'rr-core' ),
                'type'        => \Elementor\Controls_Manager::TEXT,
                'default'     => esc_html__( '85', 'rr-core' ),
                'placeholder' => esc_html__( 'Your Number', 'rr-core' ),
            ]
        );

        $this->end_controls_section();
	}

    // style_tab_content
    protected function style_tab_content(){
        $this->rr_section_style_controls('testimonial_section', 'Section Style', '.ele-section');
        $this->rr_basic_style_controls('section_sub_title', 'Section - Sub Title', '.rr-el-sub-title');
        $this->rr_basic_style_controls('section_title', 'Section - Title', '.rr-el-title');
        $this->rr_basic_style_controls('testimonial_title', 'Testimonial Title', '.rr-el-re-Title');
        $this->rr_basic_style_controls('testimonial_desc', 'Testimonial Description', '.rr-el-re-dec');
        $this->rr_basic_style_controls('testimonial_designation', 'testimonial Designation', '.rr-el-re-designation');
        $this->rr_section_style_controls('testimonial_box', 'Testimonial Box Style', '.ele-section-box');
    }

	/**
	 * Render the widget ouRRut on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
    
		?>

<!--testimonial style 3 -->
<?php if ( $settings['rr_design_style']  == 'layout-2' ):
    $this->add_render_attribute('title_args', 'class', 'section__title mb-0 title-animation rr-el-title');   
    if ( !empty($settings['testimonial_image']['url']) ) {
        $rr_testimonial_image_url = !empty($settings['testimonial_image']['id']) ? wp_get_attachment_image_url( $settings['testimonial_image']['id'], $settings['thumbnail_size']) : $settings['testimonial_image']['url'];
        $rr_testimonial_image_alt = get_post_meta($settings["testimonial_image"]["id"], "_wp_attachment_image_alt", true);
    }  
?>
<section class="testimonial__area section-space-bottom gray-bg ele-section">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-7">
                <div class="testimonial__media" data-tilt>
                    <?php if(!empty($rr_testimonial_image_url)) : ?>
                    <img src="<?php echo esc_url($rr_testimonial_image_url); ?>"
                        alt="<?php echo esc_attr($rr_testimonial_image_alt); ?>" class="height-693">
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-lg-5">
                <div class="testimonial__content testimonial__content-2 wow fadeInLeft animated" data-wow-delay=".3s">
                    <div class="swiper-wrapper">
                        <?php foreach ($settings['reviews_list'] as $index => $item) : 
                            if ( !empty($item['brand_logo']['url']) ) {
                            $rr_brand_logo = !empty($item['brand_logo']['id']) ? wp_get_attachment_image_url( $item['brand_logo']['id'], $settings['rr_image_size_size']) : $item['brand_logo']['url'];
                            $rr_brand_logo_alt = get_post_meta($item["brand_logo"]["id"], "_wp_attachment_image_alt", true);
                            }
                        ?>
                        <div class="swiper-slide">
                            <div class="testimonial__content-text testimonial__content-2-text ele-section-box">
                                <div class="testimonial__content-text-icon">
                                    <svg width="69" height="56" viewBox="0 0 69 56" fill="none"
                                        xmlns="http://www.w3.org/2000/svg">
                                        <path
                                            d="M7.43939 26.8064V26.8069C7.43939 28.1023 8.47095 29.1339 9.76631 29.1339H27.0513V52.6373H3.54785V26.8069C3.54785 14.7491 12.7638 4.80069 24.5036 3.63028V7.536C19.9667 8.0915 15.7593 10.2317 12.6344 13.5947C9.29795 17.1854 7.44223 21.9048 7.43939 26.8064ZM66.8325 29.1339V52.6373H43.329V26.8069C43.329 14.7489 52.5455 4.79947 64.3113 3.63006V7.5342C54.6836 8.69306 47.2205 16.8812 47.2205 26.8069C47.2205 28.1023 48.2521 29.1339 49.5475 29.1339H66.8325Z"
                                            stroke="#50FEA8" stroke-width="2" />
                                    </svg>
                                </div>
                                <?php if ( !empty($item['review_content']) ) : ?>
                                <p class="rr-el-re-dec mb-0"><?php echo rr_kses($item['review_content']); ?></p>
                                <?php endif; ?>
                                <div class="testimonial__content-text-title">
                                <?php if(!empty($rr_brand_logo)) : ?>
                                    <div class="testimonial__content-text-title-img">
                                        <img src="<?php echo esc_url($rr_brand_logo); ?>"
                                            alt="<?php echo esc_attr($rr_brand_logo_alt); ?>">
                                    </div>
                                <?php endif; ?>
                                    <div class="testimonial__content-text-title-name testimonial__content-2-text-name">
                                        <?php if(!empty($item['reviewer_name']) ) : ?>
                                        <h6 class="rr-el-re-Title"><?php echo rr_kses($item['reviewer_name']); ?></h6>
                                        <?php endif; ?>
                                        <?php if(!empty($item['reviewer_title'])) : ?>
                                        <span class="mb-0 rr-el-re-designation">
                                            <?php echo rr_kses($item['reviewer_title']); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    <div class="swiper-pagination testimonial__content-2-swiper-pagination"></div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php elseif ( $settings['rr_design_style']  == 'layout-3' ):
    $this->add_render_attribute('title_args', 'class', 'section__title-wrapper-title wow fadeInLeft animated rr-el-title');  

    if ( !empty($settings['testimonial_image']['url']) ) {
        $rr_testimonial_image_url = !empty($settings['testimonial_image']['id']) ? wp_get_attachment_image_url( $settings['testimonial_image']['id'], $settings['thumbnail_size']) : $settings['testimonial_image']['url'];
        $rr_testimonial_image_alt = get_post_meta($settings["testimonial_image"]["id"], "_wp_attachment_image_alt", true);
    }  
 
?>
<section class="testimonial__area section-space-top position-relative overflow-hidden ele-section">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <?php if ( !empty($settings['rr_section_section_title_show']) ) : ?>
                <div class="section__title-wrapper text-center mb-50">
                    <?php if ( !empty($settings['rr_section_sub_title']) ) : ?>
                    <h6 class="section__title-wrapper-center-subtitle mb-10 wow fadeInLeft animated rr-el-sub-title"
                        data-wow-delay=".2s"><?php echo rr_kses( $settings['rr_section_sub_title'] ); ?>
                        <svg width="14" height="13" viewBox="0 0 14 13" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <g clip-path="url(#clip0_5704_705)">
                                <path d="M4.9248 11.3357L6.49525 10.6415L5.62485 10.0312L4.9248 11.3357Z"
                                    fill="#83CD20" />
                                <path
                                    d="M4.9248 11.3353L4.99976 8.96094L13.9078 0.960938L5.66407 10.0722L4.9248 11.3353Z"
                                    fill="#83CD20" />
                                <path d="M5 8.96094L13.908 0.960938L0 7.18797L5 8.96094Z" fill="#83CD20" />
                                <path d="M5.66406 10.0722L9.95686 12.9609L13.9078 0.960938L5.66406 10.0722Z"
                                    fill="#034833" />
                            </g>
                            <defs>
                                <clipPath id="clip0_5704_705">
                                    <rect width="13.908" height="12" fill="white" transform="translate(0 0.960938)" />
                                </clipPath>
                            </defs>
                        </svg>
                    </h6>
                    <?php endif; ?>
                    <?php
                        if ( !empty($settings['rr_section_title' ]) ) :
                            printf( '<%1$s %2$s>%3$s</%1$s>',
                            tag_escape( $settings['rr_section_title_tag'] ),
                            $this->get_render_attribute_string( 'title_args' ),
                            rr_kses( $settings['rr_section_title' ] )
                            );
                        endif;
                    ?>
                </div>
                <?php endif; ?>
            </div>
        </div>
        <div class="row align-items-center row-reverse">
            <div class="col-lg-6">
                <div class="testimonial__media" data-tilt>
                    <?php if(!empty($rr_testimonial_image_url)) : ?>
                    <img src="<?php echo esc_url($rr_testimonial_image_url); ?>"
                        alt="<?php echo esc_attr($rr_testimonial_image_alt); ?>" class="height-611">
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="testimonial__content testimonial__content-3 wow fadeInLeft animated" data-wow-delay=".4s">
                    <div class="swiper-wrapper">
                        <?php foreach ($settings['reviews_list'] as $index => $item) : 

                            if ( !empty($item['brand_logo']['url']) ) {
                            $rr_brand_logo = !empty($item['brand_logo']['id']) ? wp_get_attachment_image_url( $item['brand_logo']['id'], $settings['rr_image_size_size']) : $item['brand_logo']['url'];
                            $rr_brand_logo_alt = get_post_meta($item["brand_logo"]["id"], "_wp_attachment_image_alt", true);
                            }

                            if ( !empty($item['quote_logo']['url']) ) {
                            $rr_quote_logo = !empty($item['quote_logo']['id']) ? wp_get_attachment_image_url( $item['quote_logo']['id'], $settings['rr_image_size_size']) : $item['quote_logo']['url'];
                            $rr_quote_logo_alt = get_post_meta($item["quote_logo"]["id"], "_wp_attachment_image_alt", true);
                            
                            }
                        ?>
                        <div class="swiper-slide">
                            <div class="testimonial__content-text testimonial__content-3-text ele-section-box">
                                <div class="testimonial__bg-img"
                                    data-background="<?php echo esc_url($rr_quote_logo); ?>"></div>
                                <?php if ( !empty($item['review_content']) ) : ?>
                                <p class="rr-el-re-dec mb-0"><?php echo rr_kses($item['review_content']); ?></p>
                                <?php endif; ?>
                                <div class="testimonial__content-text-title">
                                <?php if(!empty($rr_brand_logo)) : ?>
                                    <div class="testimonial__content-text-title-img">
                                        <img src="<?php echo esc_url($rr_brand_logo); ?>"
                                            alt="<?php echo esc_attr($rr_brand_logo_alt); ?>">
                                    </div>
                                <?php endif; ?>
                                    <div class="testimonial__content-text-title-name testimonial__content-3-text-name">
                                        <?php if(!empty($item['reviewer_name']) ) : ?>
                                        <h6 class="rr-el-re-Title"><?php echo rr_kses($item['reviewer_name']); ?></h6>
                                        <?php endif; ?>
                                        <?php if(!empty($item['reviewer_title'])) : ?>
                                        <span class="mb-0 rr-el-re-designation">
                                            <?php echo rr_kses($item['reviewer_title']); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    <div class="section-slider-title-7-button section-slider-title-7-button-2">
                        <button
                            class="section-slider-title-7-button-right color-gray testimonial-prev wow fadeInLeft animated"
                            data-wow-delay=".8s">
                            <i class="fa-solid fa-arrow-left"></i>
                        </button>
                        <button
                            class="section-slider-title-7-button-right color-gray testimonial-next wow fadeInLeft animated"
                            data-wow-delay="1s">
                            <i class="fa-solid fa-arrow-right"></i>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php elseif ( $settings['rr_design_style']  == 'layout-4' ):
    $this->add_render_attribute('title_args', 'class', 'section__title-wrapper-title wow fadeInLeft animated rr-el-title');  

    if ( !empty($settings['testimonial_image']['url']) ) {
        $rr_testimonial_image_url = !empty($settings['testimonial_image']['id']) ? wp_get_attachment_image_url( $settings['testimonial_image']['id'], $settings['thumbnail_size']) : $settings['testimonial_image']['url'];
        $rr_testimonial_image_alt = get_post_meta($settings["testimonial_image"]["id"], "_wp_attachment_image_alt", true);
    }  
?>
<section class="story__area pt-100 section-space-bottom">
    <div class="container">
        <div class="row mb-minus-30">
            <?php foreach ($settings['reviews_list'] as $index => $item) : 
            if ( !empty($item['brand_logo']['url']) ) {
            $rr_brand_logo = !empty($item['brand_logo']['id']) ? wp_get_attachment_image_url( $item['brand_logo']['id'], $settings['rr_image_size_size']) : $item['brand_logo']['url'];
            $rr_brand_logo_alt = get_post_meta($item["brand_logo"]["id"], "_wp_attachment_image_alt", true);
            }
           
        ?>
            <div
                class="col-xl-<?php echo esc_attr($settings['rr_col_for_desktop']); ?> col-lg-<?php echo esc_attr($settings['rr_col_for_laptop']); ?> col-md-<?php echo esc_attr($settings['rr_col_for_tablet']); ?> col-<?php echo esc_attr($settings['rr_col_for_mobile']); ?>">
                <div class="story__content mb-30 wow fadeInLeft animated"
                    data-wow-delay=".2s">
                    <div class="story__content-icon mb-20">
                        <svg width="73" height="55" viewBox="0 0 73 55" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path
                                d="M44.0341 14.5451L44.0344 14.5452L44.0367 14.5351C44.1306 14.1282 44.4712 13.8476 44.914 13.8476H62.0595C62.3775 13.8476 62.5532 13.9188 62.6535 14.0223C62.7551 14.127 62.8182 14.3042 62.8182 14.6063V17.1783C62.7817 17.6376 62.6405 18.0558 62.3993 18.4017L43.3594 43.51L43.3591 43.5098L43.3527 43.5194C43.106 43.8894 42.5749 44.0166 42.1685 43.7665L42.1686 43.7664L42.1611 43.7622L36.9788 40.8874C36.8253 40.7614 36.7424 40.6291 36.7066 40.4683C36.6684 40.2962 36.6803 40.074 36.7524 39.7656L44.0341 14.5451ZM17.3297 14.5451L17.3301 14.5452L17.3329 14.5322C17.4256 14.0999 17.8286 13.8155 18.2719 13.8471L18.2719 13.8476H18.2855H35.3551C35.6731 13.8476 35.8487 13.9188 35.9491 14.0223C36.0506 14.127 36.1137 14.3042 36.1137 14.6063V17.1783C36.0772 17.6377 35.9361 18.0559 35.6947 18.4018L16.7306 43.5103L16.7303 43.5101L16.7241 43.5194C16.4777 43.889 15.9518 44.0134 15.5485 43.7342L15.5398 43.7282L15.5306 43.7232L10.2736 40.8867C10.1206 40.7609 10.0379 40.6288 10.0022 40.4683C9.96395 40.2962 9.97581 40.074 10.048 39.7656L17.3297 14.5451Z"
                                stroke="#83CD20" stroke-width="0.379325" />
                        </svg>
                    </div>
                    <div class="story__content-text">
                        <?php if ( !empty($item['review_content']) ) : ?>
                        <p class="rr-el-re-dec"><?php echo rr_kses($item['review_content']); ?></p>
                        <?php endif; ?>
                    </div>
                    <div class="story__content-details d-flex mt-40">
                        <div class="story__content-details-img">
                            <?php if(!empty($rr_brand_logo)) : ?>
                            <img src="<?php echo esc_url($rr_brand_logo); ?>"
                                alt="<?php echo esc_attr($rr_brand_logo_alt); ?>">
                            <?php endif; ?>
                        </div>
                        <div class="story__content-details-name">
                            <?php if(!empty($item['reviewer_name']) ) : ?>
                            <h6 class="rr-el-re-Title"><?php echo rr_kses($item['reviewer_name']); ?></h6>
                            <?php endif; ?>
                            <?php if(!empty($item['reviewer_title'])) : ?>
                            <span class="rr-el-re-designation">
                                <?php echo rr_kses($item['reviewer_title']); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>
<?php elseif ( $settings['rr_design_style']  == 'layout-5' ):
    $this->add_render_attribute('title_args', 'class', 'section__title-wrapper-title wow fadeInLeft animated rr-el-title');  

    if ( !empty($settings['testimonial_image']['url']) ) {
        $rr_testimonial_image_url = !empty($settings['testimonial_image']['id']) ? wp_get_attachment_image_url( $settings['testimonial_image']['id'], $settings['thumbnail_size']) : $settings['testimonial_image']['url'];
        $rr_testimonial_image_alt = get_post_meta($settings["testimonial_image"]["id"], "_wp_attachment_image_alt", true);
    }  
?>
<section class="testi-5__area section-space p-relative testi-bg z-1">
    <div class="testi-5__bg-img" data-background="<?php echo esc_url($rr_testimonial_image_url); ?>"></div>
    <div class="container">
        <div class="row  mb-minus-65">
            <div class="col-12">
                <div class="swiper testi-5__wrap testi-5__item-slide">
                    <div class="swiper-wrapper">
                        <?php foreach ($settings['reviews_list'] as $index => $item) : 
                            if ( !empty($item['brand_logo']['url']) ) {
                            $rr_brand_logo = !empty($item['brand_logo']['id']) ? wp_get_attachment_image_url( $item['brand_logo']['id'], $settings['rr_image_size_size']) : $item['brand_logo']['url'];
                            $rr_brand_logo_alt = get_post_meta($item["brand_logo"]["id"], "_wp_attachment_image_alt", true);
                            }
                        ?>
                        <div class="swiper-slide text-center mb-65">
                            <div class="testi-5__item">
                            <?php if(!empty($rr_brand_logo)) : ?>
                                <div class="testi-5__item-thumb">
                                    <img src="<?php echo esc_url($rr_brand_logo); ?>"
                                        alt="<?php echo esc_attr($rr_brand_logo_alt); ?>">
                                </div>
                            <?php endif; ?>
                                <?php if(!empty($item['reviewer_name']) ) : ?>
                                <h4 class="testi-5__item-title"><?php echo rr_kses($item['reviewer_name']); ?></h4>
                                <?php endif; ?>
                                <?php if(!empty($item['reviewer_title']) ) : ?>
                                <span
                                    class="testi-5__item-subtitle"><?php echo rr_kses($item['reviewer_title']); ?></span>
                                <?php endif; ?>
                                <?php if(!empty($item['review_content']) ) : ?>
                                <p class="testi-5__item-dec"><?php echo rr_kses($item['review_content']); ?></p>
                                <?php endif; ?>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    <div class="swiper-pagination"></div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php elseif ( $settings['rr_design_style']  == 'layout-6' ):
    $this->add_render_attribute('title_args', 'class', 'section__title-wrapper-title wow fadeInLeft animated rr-el-title');  

    if ( !empty($settings['testimonial_image']['url']) ) {
        $rr_testimonial_image_url = !empty($settings['testimonial_image']['id']) ? wp_get_attachment_image_url( $settings['testimonial_image']['id'], $settings['thumbnail_size']) : $settings['testimonial_image']['url'];
        $rr_testimonial_image_alt = get_post_meta($settings["testimonial_image"]["id"], "_wp_attachment_image_alt", true);
    }  
    if ( !empty($settings['testimonial_image_2']['url']) ) {
        $testimonial_image_2 = !empty($settings['testimonial_image_2']['id']) ? wp_get_attachment_image_url( $settings['testimonial_image_2']['id'], $settings['thumbnail_size']) : $settings['testimonial_image_2']['url'];
        $rr_testimonial_image_alt = get_post_meta($settings["testimonial_image_2"]["id"], "_wp_attachment_image_alt", true);
    }  
?>

<section class="testimonial-4__area p-relative z-1 overflow-hidden black-bg ele-section">
    <div class="testimonial-4__bg-img" data-background="<?php echo esc_url($rr_testimonial_image_url); ?>"></div>
    <div class="container-fluid">
        <div class="testimonial-4__wrapper">
            <div class="testimonial-4__wrapper-thumb">
                <?php if(!empty($testimonial_image_2)) : ?>
                <img src="<?php echo esc_url($testimonial_image_2); ?>"
                    alt="<?php echo esc_attr($rr_testimonial_image_alt); ?>">
                <?php endif; ?>
                <div class="pie-item text-center">
                    <div class="piechart" data-percent="<?php echo rr_kses($settings['rr_skill_num']); ?>"><span><?php echo rr_kses($settings['rr_skill_num']); ?></span>%</div>
                    <h4><?php echo rr_kses($settings['rr_skill_box_title']); ?></h4>
                </div>
            </div>
            <div class="testimonial-4__wrapper-content">
                <div class="testimonial-4__all-content-wrap">
                    <?php if ( !empty($settings['rr_section_section_title_show']) ) : ?>
                    <div class="section__title-wrapper text-center mb-60 mb-xs-30 rr-el-sub-title">
                        <?php if ( !empty($settings['rr_section_sub_title']) ) : ?>
                        <h6 class="section__title-wrapper-center-subtitle mb-10 wow fadeInLeft animated"
                            data-wow-delay=".2s"><?php echo rr_kses( $settings['rr_section_sub_title'] ); ?></h6>
                        <?php endif; ?>
                        <?php
                        if ( !empty($settings['rr_section_title' ]) ) :
                            printf( '<%1$s %2$s>%3$s</%1$s>',
                            tag_escape( $settings['rr_section_title_tag'] ), 
                            $this->get_render_attribute_string( 'title_args' ),
                            rr_kses( $settings['rr_section_title' ] )
                            );
                        endif;
                    ?>
                    </div>
                    <?php endif; ?>
                    <div class="swiper testi-slide-4">
                        <div class="swiper-wrapper">
                            <?php foreach ($settings['reviews_list'] as $index => $item) : 
                                if ( !empty($item['brand_logo']['url']) ) {
                                $rr_brand_logo = !empty($item['brand_logo']['id']) ? wp_get_attachment_image_url( $item['brand_logo']['id'], $settings['rr_image_size_size']) : $item['brand_logo']['url'];
                                $rr_brand_logo_alt = get_post_meta($item["brand_logo"]["id"], "_wp_attachment_image_alt", true);
                                }
                            ?>
                            <div class="swiper-slide">
                                <div class="testimonial-4__slider ele-section-box">
                                    <div class="media">
                                    <?php if(!empty($rr_brand_logo)) : ?>
                                        <div class="title-img">
                                            <img src="<?php echo esc_url($rr_brand_logo); ?>"
                                                alt="<?php echo esc_attr($rr_brand_logo_alt); ?>">
                                        </div>
                                    <?php endif; ?>
                                        <div class="icon">
                                            <ul>
                                                <?php
                                                $rr_rating = $item['rr_testi_rating'];
                                                for($i=1; $i<=$rr_rating; $i++) :
                                            ?>
                                                <li>
                                                    <svg width="19" height="17" viewBox="0 0 19 17" fill="none"
                                                        xmlns="http://www.w3.org/2000/svg">
                                                        <path
                                                            d="M9.39024 0L11.4985 6.21885H18.3209L12.8014 10.0623L14.9097 16.2812L9.39024 12.4377L3.8708 16.2812L5.97904 10.0623L0.459591 6.21885H7.282L9.39024 0Z"
                                                            fill="#FFC400" />
                                                    </svg>
                                                </li>
                                                <?php endfor; ?>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="text">
                                        <?php if ( !empty($item['review_content']) ) : ?>
                                        <p class="rr-el-re-dec"><?php echo rr_kses($item['review_content']); ?></p>
                                        <?php endif; ?>
                                        <div class="title-wrap">
                                            <?php if(!empty($item['reviewer_name']) ) : ?>
                                            <h3 class="title rr-el-re-Title">
                                                <?php echo rr_kses($item['reviewer_name']); ?></h3>
                                            <?php endif; ?>
                                            <?php if(!empty($item['reviewer_title']) ) : ?>
                                            <span
                                                class="rr-el-re-designation"><?php echo rr_kses($item['reviewer_title']); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    <div class="swiper-pagination"></div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php else:
    $this->add_render_attribute('title_args', 'class', 'testimonial__title-wrapper-title wow fadeInLeft animated rr-el-title');      
    if ( !empty($settings['testimonial_image']['url']) ) {
        $rr_testimonial_image_url = !empty($settings['testimonial_image']['id']) ? wp_get_attachment_image_url( $settings['testimonial_image']['id'], $settings['thumbnail_size']) : $settings['testimonial_image']['url'];
        $rr_testimonial_image_alt = get_post_meta($settings["testimonial_image"]["id"], "_wp_attachment_image_alt", true);
    }    
?>
<section class="testimonial__area section-space-top gray-bg ele-section">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-5">
                <div class="testimonial__media" data-tilt>
                    <?php if(!empty($rr_testimonial_image_url)) : ?>
                    <img src="<?php echo esc_url($rr_testimonial_image_url); ?>"
                        alt="<?php echo esc_attr($rr_testimonial_image_alt); ?>">
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-lg-7">
                <div class="testimonial__content swiper wow fadeInLeft animated" data-wow-delay=".3s">
                    <div class="swiper-wrapper">
                        <?php foreach ($settings['reviews_list'] as $index => $item) : 
                            if ( !empty($item['brand_logo']['url']) ) {
                            $rr_brand_logo = !empty($item['brand_logo']['id']) ? wp_get_attachment_image_url( $item['brand_logo']['id'], $settings['rr_image_size_size']) : $item['brand_logo']['url'];
                            $rr_brand_logo_alt = get_post_meta($item["brand_logo"]["id"], "_wp_attachment_image_alt", true);
                            }
                        ?>
                        <div class="swiper-slide">
                            <div class="testimonial__content-text ele-section-box">
                                <div class="testimonial__content-text-icon">
                                    <svg width="73" height="56" viewBox="0 0 73 56" fill="none"
                                        xmlns="http://www.w3.org/2000/svg">
                                        <path
                                            d="M36.8723 41.0882C36.493 40.7847 36.4172 40.4054 36.5689 39.7605L43.8519 14.5354C43.9657 14.0423 44.383 13.7009 44.914 13.7009H62.0595C62.7423 13.7009 63.0078 14.0044 63.0078 14.6492V17.2286C62.9699 17.7218 62.8181 18.177 62.5526 18.5563L43.5105 43.6676C43.2071 44.1228 42.5622 44.2745 42.0691 43.971L36.8723 41.0882ZM10.1679 41.0882C9.78857 40.7847 9.71272 40.4054 9.86444 39.7605L17.1475 14.5354C17.2613 14.0044 17.7544 13.663 18.2855 13.7009H35.3551C36.0378 13.7009 36.3034 14.0044 36.3034 14.6492V17.2286C36.2654 17.7218 36.1137 18.177 35.8482 18.5563L16.8819 43.6676C16.5785 44.1228 15.9336 44.2745 15.4405 43.9331L10.1679 41.0882Z"
                                            fill="white" />
                                    </svg>
                                </div>
                                <?php if ( !empty($item['review_content']) ) : ?>
                                <p class="rr-el-re-dec mb-0"><?php echo rr_kses($item['review_content']); ?></p>
                                <?php endif; ?>
                                <div class="testimonial__content-text-title">
                                <?php if(!empty($rr_brand_logo)) : ?>
                                    <div class="testimonial__content-text-title-img">
                                        <img src="<?php echo esc_url($rr_brand_logo); ?>"
                                            alt="<?php echo esc_attr($rr_brand_logo_alt); ?>">
                                    </div>
                                <?php endif; ?>
                                    <div class="testimonial__content-text-title-name">
                                        <?php if(!empty($item['reviewer_name']) ) : ?>
                                        <h6 class="rr-el-re-Title"><?php echo rr_kses($item['reviewer_name']); ?></h6>
                                        <?php endif; ?>
                                        <?php if(!empty($item['reviewer_title'])) : ?>
                                        <span class="mb-0 rr-el-re-designation">
                                            <?php echo rr_kses($item['reviewer_title']); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    <div class="testimonial__content-button d-flex">
                        <div class="testimonial__content-button-border"></div>
                        <button class="testimonial-prev testimonial__content-button-btn"><i
                                class="fa-solid fa-arrow-left"></i></button>
                        <button class="testimonial-next testimonial__content-button-btn"><i
                                class="fa-solid fa-arrow-right"></i></button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php endif; 
	}
}

$widgets_manager->register( new rr_Testimonial() );