<?php
namespace RRCore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Repeater;
use \Elementor\Utils;
use RRCore\Elementor\Controls\Group_Control_RRBGGradient;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * RR Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class RR_Trining extends Widget_Base {

    use \RRCore\Widgets\RRCoreElementFunctions;

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'rr_trining';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Trining', 'rr-core' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'rr-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'rr-core' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'rr-core' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */

    protected function register_controls(){
        $this->register_controls_section();
        $this->style_tab_content();
    }   

	protected function register_controls_section() {

        // layout Panel
        $this->start_controls_section(
            'rr_layout',
            [
                'label' => esc_html__('Design Layout', 'rr-core'),
            ]
        );
        $this->add_control(
            'rr_design_style',
            [
                'label' => esc_html__('Select Layout', 'rr-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Layout 1', 'rr-core'),
                    'layout-2' => esc_html__('Layout 2', 'rr-core'),
                ],
                'default' => 'layout-1',
            ]
        );

        $this->end_controls_section();
        
        // rr_section_title
        $this->rr_section_title_render_controls('section', 'Section Title', 'Sub Title', 'your title here', $default_description = 'Hic nesciunt galisum aut dolorem aperiam eum soluta quod ea cupiditate.',['layout-1']);
        $this->start_controls_section(
            'trining_main',
            [
                'label' => esc_html__( 'Section Title', 'rr-core' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
         
            ]
        );
        
        $this->add_control(
            'trining_title', [
                'label' => esc_html__( 'Trining Title', 'rr-core' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__( 'Trining & Cetification' , 'rr-core' ),
                'label_block' => true,
             
            ]
        );
        $this->add_control(
            'trining_desc', [
                'label' => esc_html__( 'Section Description', 'rr-core' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__( 'Immigration Trainings Your Choice' , 'rr-core' ),
                'label_block' => true,
              
            ]
        );

        $this->end_controls_section();
        
        // Review group
        $this->start_controls_section( 
            'review_list',
            [
                'label' => esc_html__( 'Review List', 'rr-core' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
                
            ]
        );
        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'repeater_condition',
            [
                'label' => __( 'Field condition', 'rr-core' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'style_1' => __( 'Style 1', 'rr-core' ),
                    'style_2' => __( 'Style 2', 'rr-core' ),
                    'style_2' => __( 'Style 2', 'rr-core' ),
                ],
                'default' => 'style_1',
                'frontend_available' => true,
                'style_transfer' => true,
            ]
        );

        $repeater->add_control(
            'brand_logo',
            [
                'label' => esc_html__('Client Image', 'rr-core'),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
                'condition' => [
                    'repeater_condition' => ['style_1','style_2']
                ]

            ]
        );

        $repeater->add_control(
            'reviewer_title', [
                'label' => esc_html__( 'Reviewer Title', 'rr-core' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__( '- CEO at YES Germany' , 'rr-core' ),
                'label_block' => true,
                'condition' => [
                    'repeater_condition' => ['style_1', 'style_2']
                ]
            ]
        );

        $repeater->add_control(
            'reviewer_title_url',
            [
                'label' => esc_html__( 'Url', 'text-domain' ),
                'type' => Controls_Manager::URL,
                'options' => [ 'url', 'is_external', 'nofollow' ],
                'default' => [
                    'url' => '',
                    'is_external' => true,
                    'nofollow' => true,
                ],
                'label_block' => true,
            ]
        );

        $this->add_control(
            'reviews_list',
            [
                'label' => esc_html__( 'Review List', 'rr-core' ),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' =>  $repeater->get_controls(),
                'default' => [
                    [
                        'reviewer_name' => esc_html__( 'Rasalina William', 'rr-core' ),
                        'reviewer_title' => esc_html__( 'CEO at YES Germany', 'rr-core' ),
                        'review_content' => esc_html__( 'Construction can be defined as the art of building something. These construction quotes will put into perspective the fact that construction can be', 'rr-core' ),
                    ],
                    [
                        'reviewer_name' => esc_html__( 'Rasalina William 2', 'rr-core' ),
                        'reviewer_title' => esc_html__( 'CEO at YES Germany', 'rr-core' ),
                        'review_content' => esc_html__( 'Construction can be defined as the art of building something. These construction quotes will put into perspective the fact that construction can be', 'rr-core' ),
                    ],
                    [
                        'reviewer_name' => esc_html__( 'Rasalina William 3', 'rr-core' ),
                        'reviewer_title' => esc_html__( 'CEO at YES Germany', 'rr-core' ),
                        'review_content' => esc_html__( 'Construction can be defined as the art of building something. These construction quotes will put into perspective the fact that construction can be', 'rr-core' ),
                    ],

                ],
                'title_field' => '{{{ reviewer_name }}}',
            ]
        );
        $this->add_group_control(
            Group_Control_Image_Size::get_type(),
            [
                'name' => 'rr_image_size',
                'default' => 'full',
                'exclude' => ['custom'],
                'separator' => 'none',
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'testimonial_thumb',
            [
                'label' => esc_html__( 'Image', 'rr-core' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
                'condition' => [
                    'rr_design_style' => ['layout-1', 'layout-2', 'layout-3', 'layout-5', 'layout-6']
                ]
            ]
        );
        
        $this->add_control(
            'testimonial_image',
            [
                'label' => esc_html__('Client Image', 'rr-core'),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Image_Size::get_type(),
            [
                'name' => 'thumbnail',
                'default' => 'full',
                'exclude' => ['custom'],
                'separator' => 'none',
            ]
        );

        $this->end_controls_section();
        // button
        $this->rr_button_render('about', 'Button', ['layout-1']);
                
	}

    // style_tab_content
    protected function style_tab_content(){
        $this->rr_section_style_controls('testimonial_section', 'Section Style', '.ele-section');
        $this->rr_basic_style_controls('section_sub_title', 'Section - Sub Title', '.rr-el-sub-title');
        $this->rr_basic_style_controls('section_title', 'Section - Title', '.rr-el-title');
        $this->rr_basic_style_controls('testimonial_title', 'Testimonial Title', '.rr-el-re-Title');
        $this->rr_basic_style_controls('testimonial_desc', 'Testimonial Description', '.rr-el-re-dec');
        $this->rr_basic_style_controls('testimonial_designation', 'testimonial Designation', '.rr-el-re-designation');
        $this->rr_section_style_controls('testimonial_box', 'Testimonial Box Style', '.ele-section-box');
    }

	/**
	 * Render the widget ouRRut on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
    
		?>

<!--testimonial style 3 -->
<?php if ( $settings['rr_design_style']  == 'layout-2' ):
    $this->add_render_attribute('title_args', 'class', 'section__title mb-0 title-animation rr-el-title');   
    if ( !empty($settings['testimonial_image']['url']) ) {
        $rr_testimonial_image_url = !empty($settings['testimonial_image']['id']) ? wp_get_attachment_image_url( $settings['testimonial_image']['id'], $settings['thumbnail_size']) : $settings['testimonial_image']['url'];
        $rr_testimonial_image_alt = get_post_meta($settings["testimonial_image"]["id"], "_wp_attachment_image_alt", true);
    }  
?>


<?php else:
    $this->add_render_attribute('title_args', 'class', 'trining__content-title rr-el-title');      
    if ( !empty($settings['testimonial_image']['url']) ) {
        $rr_testimonial_image_url = !empty($settings['testimonial_image']['id']) ? wp_get_attachment_image_url( $settings['testimonial_image']['id'], $settings['thumbnail_size']) : $settings['testimonial_image']['url'];
        $rr_testimonial_image_alt = get_post_meta($settings["testimonial_image"]["id"], "_wp_attachment_image_alt", true);
    } 
    // Link
if ('2' == $settings['rr_about_btn_link_type']) {
    $this->add_render_attribute('rr-button-arg', 'href', get_permalink($settings['rr_about_btn_page_link']));
    $this->add_render_attribute('rr-button-arg', 'target', '_self');
    $this->add_render_attribute('rr-button-arg', 'rel', 'nofollow');
    $this->add_render_attribute('rr-button-arg', 'class', 'rr-btn btn-white mt-40rr-el-btn');
} else {
    if ( ! empty( $settings['rr_about_btn_link']['url'] ) ) {
        $this->add_link_attributes( 'rr-button-arg', $settings['rr_about_btn_link'] );
        $this->add_render_attribute('rr-button-arg', 'class', 'rr-btn btn-white mt-40 rr-el-btn');
    }
}   
?>
   <section class="trining__area h-5-bg p-relative overflow-hidden section-space-top z-1">
        <div class="trining__shape">
            <img src="<?php echo get_template_directory_uri(  ); ?>/assets/imgs/home-5/trinning-bg-shape.png" alt="img not found">
        </div>
        <div class="container">
            <div class="row">
                <div class="col-lg-6">
                <?php if ( !empty($settings['rr_section_section_title_show']) ) : ?>
                <div class="trining__content">
                    <div class="trining__content-shape">
                        <img src="<?php echo get_template_directory_uri(  ); ?>/assets/imgs/home-5/trinning-content-bg-shape.png"
                            alt="img not found">
                    </div>
                    <?php if ( !empty($settings['rr_section_sub_title']) ) : ?>
                    <h6 class="trining__content-subtitle"><?php echo rr_kses( $settings['rr_section_sub_title'] ); ?>
                    </h6>
                    <?php endif; ?>
                    <?php
                        if ( !empty($settings['rr_section_title' ]) ) :
                            printf( '<%1$s %2$s>%3$s</%1$s>',
                            tag_escape( $settings['rr_section_title_tag'] ),
                            $this->get_render_attribute_string( 'title_args' ),
                            rr_kses( $settings['rr_section_title' ] )
                            );
                        endif;
                    ?>
                    <p class="trining__content-dec"><?php echo rr_kses( $settings['rr_section_description'] ); ?></p>
                    <a <?php echo $this->get_render_attribute_string( 'rr-button-arg' ); ?>><?php echo rr_kses($settings['rr_about_btn_text']); ?><i
                    class="fa-solid fa-arrow-right"></i></a>
                </div>
                <?php endif; ?>
                </div>
                <div class="col-lg-6">
                    <div class="trining__title-wrap">
                        <h6 class="trining__subtitle"><?php echo rr_kses($settings['trining_title']);?></h6>
                        <h2 class="trining__title"><?php echo rr_kses($settings['trining_desc']);?></h2>
                    </div>
                </div>
            </div>
            <div class="swiper trining__slider">
                <div class="swiper-wrapper">
                <?php foreach ($settings['reviews_list'] as $index => $item) : 
                    if ( !empty($item['brand_logo']['url']) ) {
                    $rr_brand_logo = !empty($item['brand_logo']['id']) ? wp_get_attachment_image_url( $item['brand_logo']['id'], $settings['rr_image_size_size']) : $item['brand_logo']['url'];
                    $rr_brand_logo_alt = get_post_meta($item["brand_logo"]["id"], "_wp_attachment_image_alt", true);
                    }
                ?>
                <div class="swiper-slide trining__slider-item">
                    <div class="trining__slider-item-thumb">
                        <img src="<?php echo esc_url($rr_brand_logo); ?>"
                            alt="<?php echo esc_attr($rr_brand_logo_alt); ?>">
                        <div class="trining__slider-item-thumb-icon"><i class="fa-solid fa-plus"></i></div>
                        <h3 class="trining__slider-item-thumb-title"><a
                                href="<?php echo rr_kses($item['reviewer_title_url']['url']);?>"><?php echo rr_kses($item['reviewer_title']); ?></a>
                        </h3>
                    </div>
                </div>
                <?php endforeach; ?>
                </div>
            </div>
        </div>
    </section>

<?php endif; 
	}
}

$widgets_manager->register( new RR_Trining() );