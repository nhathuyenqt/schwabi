<?php
namespace RRCore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Group_Control_Background;
use \Elementor\Control_Media;
use \Elementor\Repeater;
use \Elementor\Group_Control_Typography;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Utils;
use RRCore\Elementor\Controls\Group_Control_RRBGGradient;
use RRCore\Elementor\Controls\Group_Control_RRGradient;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * RR Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class rr_Hero_Banner extends Widget_Base {

    use \RRCore\Widgets\RRCoreElementFunctions;

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'hero-banner';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Hero Banner', 'rr-core' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'rr-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'rr-core' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'rr-core' ];
	}

    public function get_rr_contact_form(){
        if ( ! class_exists( 'WPCF7' ) ) {
            return;
        }
        $rr_cfa         = array();
        $rr_cf_args     = array( 'posts_per_page' => -1, 'post_type'=> 'wpcf7_contact_form' );
        $rr_forms       = get_posts( $rr_cf_args );
        $rr_cfa         = ['0' => esc_html__( 'Select Form', 'rr-core' ) ];
        if( $rr_forms ){
            foreach ( $rr_forms as $rr_form ){
                $rr_cfa[$rr_form->ID] = $rr_form->post_title;
            }
        }else{
            $rr_cfa[ esc_html__( 'No contact form found', 'rr-core' ) ] = 0;
        }
        return $rr_cfa;
    }


	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
    protected function register_controls(){
        $this->register_controls_section();
        $this->style_tab_content();
    }  


	protected function register_controls_section() {

        // layout Panel
        $this->start_controls_section(
            'rr_layout',
            [
                'label' => esc_html__('Design Layout', 'rr-core'),
            ]
        );
        $this->add_control(
            'rr_design_style',
            [
                'label' => esc_html__('Select Layout', 'rr-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Layout 1', 'rr-core'),
                    'layout-2' => esc_html__('Layout 2', 'rr-core')
                ],
                'default' => 'layout-1',
            ]
        );

        $this->end_controls_section();

        $this->rr_section_title_render_controls('banner', 'Banner Title', 'Sub Title', 'your title here', $default_description = 'Hic nesciunt galisum aut dolorem aperiam eum soluta quod ea cupiditate.',['layout-1', 'layout-2','layout-3','layout-4','layout-5']);
        // button
        $this->rr_button_render('banner', 'Button', ['layout-1', 'layout-2']);
    

        // thumbnail image
        $this->start_controls_section(
        'rr_thumbnail_section',
            [
                'label' => esc_html__( 'Thumbnail', 'rr-core' ),
                'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control( 
            'rr_thumbnail_image',
            [
                'label' => esc_html__( 'Choose Thumbnail Image', 'rr-core' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );       
         $this->add_control( 
            'rr_thumbnail_image2',
            [
                'label' => esc_html__( 'Choose Thumbnail Image 02', 'rr-core' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Image_Size::get_type(),
            [
                'name' => 'rr_thumbnail_size',
                'default' => 'full',
                'exclude' => [
                    'custom'
                ]
            ]
        );
        $this->end_controls_section();
        // thumbnail image
        $this->start_controls_section(
        'rr_shap_section',
            [
                'label' => esc_html__( 'Shape', 'rr-core' ),
                'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'rr_banner_shape_switcher',
            [
                'label' => esc_html__( 'Banner Shape', 'rr-core' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Yes', 'rr-core' ),
                'label_off' => esc_html__( 'No', 'rr-core' ),
                'return_value' => 'yes',
                'default' => 'yes',
                'separator' => 'before',
            ]
        );

        $this->add_control( 
            'rr_shape_image_left',
            [
                'label' => esc_html__( 'Choose Left Tower Shape', 'rr-core' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );

         $this->add_control( 
            'rr_shape_image_right',
            [
                'label' => esc_html__( 'Choose Right Tower Shape ', 'rr-core' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Image_Size::get_type(),
            [
                'name' => 'rr_shape_size',
                'default' => 'full',
                'exclude' => [
                    'custom'
                ]
            ]
        );
        $this->end_controls_section();

        // hero slider
        $this->start_controls_section(
            'rr-core_hero_sider_area',
            [
                'label' => esc_html__('Hero Slider Area', 'rr-core'),
                'condition' => [
                    'rr_design_style' => 'layout-4'
                ]
            ]
        );

        // repeter field with text 
        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'rr-core_hero_slider_title',
            [
                'label'       => esc_html__( 'Title', 'rr-core' ),
                'type'        => \Elementor\Controls_Manager::TEXT,
                'default'     => esc_html__( 'Your Title', 'rr-core' ),
                'placeholder' => esc_html__( 'Your Title Text', 'rr-core' ),
                'description' => 'Type Your Title In This Field',
                'label_block' => true,
            ]
        );


        $this->add_control(
            'rr-core_hero_slider_list',
            [
                'label' => esc_html__( 'Hero Slider List', 'rr-core' ),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'rr_banner_video',
                [
                  'label' => esc_html__( 'Hero Video', 'rr-core' ),
                  'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
                  'condition' => [
                    'rr_design_style' => 'layout-1'
                ]
                ]
            
           );
   
           $this->add_control(
            'rr_core_video_title',
            [
                'label'       => esc_html__( 'Title', 'rr-core' ),
                'type'        => \Elementor\Controls_Manager::TEXT,
                'default'     => esc_html__( 'Watch Video', 'rr-core' ),
                'description' => 'Type Your Video Title',
                'label_block' => true,
            ]
        );
           $this->add_control(
            'rr_core_video_url',
            [
                'label'       => esc_html__( 'Url', 'rr-core' ),
                'type'        => \Elementor\Controls_Manager::TEXT,
                'default'     => esc_html__( '#', 'rr-core' ),
                'description' => 'Type Your Video Url',
                'label_block' => true,
            ]
        );
           $this->end_controls_section();
        $this->start_controls_section(
            'rr_country',
                [
                  'label' => esc_html__( 'Hero Country', 'rr-core' ),
                  'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
                  'condition' => [
                    'rr_design_style' => 'layout-2'
                ]
                ]
           );

           $this->add_control(
            'rr_core_country_title',
            [
                'label'       => esc_html__( 'Germany Title', 'rr-core' ),
                'type'        => \Elementor\Controls_Manager::TEXT,
                'default'     => esc_html__( 'Germany', 'rr-core' ),
                'description' => 'Type Your Germany Title',
                'label_block' => true,
            ]
        );

        $this->add_control( 
            'rr_country_germany',
            [
                'label' => esc_html__( 'Germany Image', 'rr-core' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $this->add_control(
            'rr_core_south_korea_title',
            [
                'label'       => esc_html__( 'South Korea Title', 'rr-core' ),
                'type'        => \Elementor\Controls_Manager::TEXT,
                'default'     => esc_html__( 'South Korea', 'rr-core' ),
                'description' => 'Type Your South Korea Title',
                'label_block' => true,
            ]
        );
        $this->add_control( 
            'rr_country_south_korea',
            [
                'label' => esc_html__( 'South Korea Image', 'rr-core' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );
        $this->add_control(
            'rr_core_south_africa_title',
            [
                'label'       => esc_html__( 'South Africa Title', 'rr-core' ),
                'type'        => \Elementor\Controls_Manager::TEXT,
                'default'     => esc_html__( 'South Africa', 'rr-core' ),
                'description' => 'Type Your South Africa Title',
                'label_block' => true,
            ]
        );
        $this->add_control( 
            'rr_country_south_africa',
            [
                'label' => esc_html__( 'South Africa Image', 'rr-core' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );
        $this->add_control(
            'rr_core_turkey_title',
            [
                'label'       => esc_html__( 'Turkey Title', 'rr-core' ),
                'type'        => \Elementor\Controls_Manager::TEXT,
                'default'     => esc_html__( 'Turkey', 'rr-core' ),
                'description' => 'Type Your Turkey Title',
                'label_block' => true,
            ]
        );
        $this->add_control( 
            'rr_country_turkey',
            [
                'label' => esc_html__( 'Turkey Image', 'rr-core' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );
        $this->add_control(
            'rr_core_indonesia_title',
            [
                'label'       => esc_html__( 'Indonesia Title', 'rr-core' ),
                'type'        => \Elementor\Controls_Manager::TEXT,
                'default'     => esc_html__( 'Indonesia', 'rr-core' ),
                'description' => 'Type Your Indonesia Title',
                'label_block' => true,
            ]
        );
        $this->add_control( 
            'rr_country_indonesia',
            [
                'label' => esc_html__( 'Indonesia Image', 'rr-core' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Image_Size::get_type(),
            [
                'name' => 'rr_country_size',
                'default' => 'full',
                'exclude' => [
                    'custom'
                ]
            ]
        );
           $this->end_controls_section();

       
	}
    

    // style_tab_content
    protected function style_tab_content(){
        $this->rr_section_style_controls('banner_section', 'Section - Style', '.rr-el-section');
        $this->rr_basic_style_controls('section_sub_title', 'Section - Sub Title', '.rr-el-sub-title');
        $this->rr_basic_style_controls('section_title', 'Section - Title', '.rr-el-title');
        $this->rr_link_controls_style('repiter_btn', 'Banner - Button', '.rr-el-btn');
        $this->rr_basic_style_controls('banner_video_text', 'Banner Video Text', '.rr-el-video-text');
        $this->rr_link_controls_style('repiter_video', 'Banner - Video', '.rr-el-video');
    }

	/**
	 * Render the widget ouRRut on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		?>

<?php if ( $settings['rr_design_style']  == 'layout-2' ): 

    // thumbnail image
    if ( !empty($settings['rr_thumbnail_image']['url']) ) {
        $rr_thumbnail_image = !empty($settings['rr_thumbnail_image']['id']) ? wp_get_attachment_image_url( $settings['rr_thumbnail_image']['id'], $settings['rr_thumbnail_size_size']) : $settings['rr_thumbnail_image']['url'];
        $rr_thumbnail_image_alt = get_post_meta($settings["rr_thumbnail_image"]["id"], "_wp_attachment_image_alt", true);
    }
        
    // germany image
    if ( !empty($settings['rr_country_germany']['url']) ) {
        $rr_country_germany = !empty($settings['rr_country_germany']['id']) ? wp_get_attachment_image_url( $settings['rr_country_germany']['id'], $settings['rr_country_size_size']) : $settings['rr_country_germany']['url'];
        $rr_country_alt = get_post_meta($settings["rr_country_germany"]["id"], "_wp_attachment_image_alt", true);
    }
    // thumbnail image
    if ( !empty($settings['rr_country_south_korea']['url']) ) {
        $rr_country_south_korea = !empty($settings['rr_country_south_korea']['id']) ? wp_get_attachment_image_url( $settings['rr_country_south_korea']['id'], $settings['rr_country_size_size']) : $settings['rr_country_south_korea']['url'];
        $rr_country_alt = get_post_meta($settings["rr_country_south_korea"]["id"], "_wp_attachment_image_alt", true);
    }
    // thumbnail image
    if ( !empty($settings['rr_country_south_africa']['url']) ) {
        $rr_country_south_africa = !empty($settings['rr_country_south_africa']['id']) ? wp_get_attachment_image_url( $settings['rr_country_south_africa']['id'], $settings['rr_country_size_size']) : $settings['rr_country_south_africa']['url'];
        $rr_country_alt = get_post_meta($settings["rr_country_south_africa"]["id"], "_wp_attachment_image_alt", true);
    }
    // thumbnail image
    if ( !empty($settings['rr_country_turkey']['url']) ) {
        $rr_country_turkey = !empty($settings['rr_country_turkey']['id']) ? wp_get_attachment_image_url( $settings['rr_country_turkey']['id'], $settings['rr_country_size_size']) : $settings['rr_country_turkey']['url'];
        $rr_country_alt = get_post_meta($settings["rr_country_turkey"]["id"], "_wp_attachment_image_alt", true);
    }
    // thumbnail image
    if ( !empty($settings['rr_country_indonesia']['url']) ) {
        $rr_country_indonesia = !empty($settings['rr_country_indonesia']['id']) ? wp_get_attachment_image_url( $settings['rr_country_indonesia']['id'], $settings['rr_country_size_size']) : $settings['rr_country_indonesia']['url'];
        $rr_country_alt = get_post_meta($settings["rr_country_indonesia"]["id"], "_wp_attachment_image_alt", true);
    }
        
    $this->add_render_attribute('title_args', 'class', 'banner2__title wow fadeInLeft animated rr-el-title');
    
    // Link
    if ('2' == $settings['rr_banner_btn_link_type']) {
        $this->add_render_attribute('rr-button-arg', 'href', get_permalink($settings['rr_banner_btn_page_link']));
        $this->add_render_attribute('rr-button-arg', 'target', '_self');
        $this->add_render_attribute('rr-button-arg', 'rel', 'nofollow');
        $this->add_render_attribute('rr-button-arg', 'class', 'banner2__button mt-40 mt-xs-25 wow fadeInLeft animated rr-el-btn');
    } else {
        if ( ! empty( $settings['rr_banner_btn_link']['url'] ) ) {
            $this->add_link_attributes( 'rr-button-arg', $settings['rr_banner_btn_link'] );
            $this->add_render_attribute('rr-button-arg', 'class', 'banner2__button mt-40 mt-xs-25 wow fadeInLeft animated rr-el-btn');
        }
    }

?>
<section class="overflow-hidden p-relative gray-bg section-space-bottom-170 overflow-hidden rr-el-section">
    <div class="banner2__area p-relative">
        <?php if ( !empty($settings['rr_banner_shape_switcher']) ) : ?>
        <div class="banner2__shape"
            data-background="<?php echo get_template_directory_uri(  ); ?>/assets/imgs/banner-2/banner2-shape.svg">
        </div>
        <?php endif; ?>
        <div class="banner2__padding-space2">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-7 col-md-12">
                        <div class="banner2__content p-relative">
                        <?php if(!empty($settings['rr_banner_sub_title'])) : ?>
                            <h6 class="banner2__subtitle wow fadeInLeft animated rr-el-sub-title" data-wow-delay=".2s">
                                <?php echo rr_kses( $settings['rr_banner_sub_title'] ); ?>
                                <svg width="52" height="10" viewBox="0 0 52 10" fill="none"
                                    xmlns="http://www.w3.org/2000/svg">
                                    <g clip-path="url(#clip0_3920_930)">
                                        <path
                                            d="M47.2105 2.14437C46.4106 2.36766 45.5884 2.50135 44.759 2.54299L38.0755 3.26714C36.5634 3.43986 35.0723 3.76256 33.6242 4.23048C32.835 4.49614 32.0757 4.84349 31.3587 5.2669C30.5825 5.78994 29.7749 6.26475 28.9404 6.68864C28.4375 6.92402 27.8878 7.04215 27.3326 7.03411C26.7214 6.99856 26.1435 6.7438 25.7049 6.3166C24.8612 5.44628 24.6287 4.38993 24.0772 3.71228C23.8491 3.37951 23.506 3.14288 23.1139 3.04791C22.6936 2.95474 22.2553 2.98472 21.8516 3.13427C20.9452 3.46398 20.1849 4.10423 19.7057 4.94135C19.1277 5.79839 18.6759 6.775 18.0182 7.69183C17.3781 8.67698 16.4295 9.42226 15.3209 9.81116C14.739 9.97733 14.1223 9.97733 13.5404 9.81116C12.9891 9.64765 12.4808 9.36403 12.0522 8.9807C11.2858 8.27735 10.6885 7.40973 10.3049 6.44282C9.91959 5.55257 9.64054 4.68889 9.25521 3.93151C8.81334 2.89622 8.01098 2.05634 6.99695 1.56765C5.98293 1.07897 4.82607 0.974642 3.74097 1.27404C3.16462 1.41933 2.62589 1.6859 2.16075 2.05594C1.69561 2.42599 1.31477 2.89102 1.04364 3.41996C0.610002 4.23627 0.403487 5.15404 0.445698 6.07742C0.462342 6.66905 0.588506 7.25247 0.817762 7.79813C0.970566 8.18346 1.07686 8.37613 1.04364 8.40271C1.01043 8.42928 0.850974 8.26318 0.62509 7.89778C0.298973 7.3528 0.0970721 6.74258 0.0337932 6.11063C-0.0934455 5.09968 0.0725961 4.07346 0.512138 3.1542C0.79995 2.52884 1.21882 1.97266 1.74037 1.52332C2.26192 1.07399 2.87396 0.742013 3.53502 0.549886C4.34237 0.314234 5.19223 0.262331 6.02226 0.397987C6.85229 0.533642 7.64143 0.85342 8.33175 1.33384C9.08289 1.89515 9.68508 2.63192 10.0857 3.47975C10.5175 4.31021 10.8231 5.18716 11.2018 6.01762C11.536 6.84506 12.054 7.58567 12.7166 8.18347C13.0189 8.47409 13.3917 8.68086 13.7983 8.78339C14.2049 8.88592 14.6313 8.88064 15.0352 8.7681C15.9067 8.44143 16.6499 7.84273 17.1545 7.06068C17.7325 6.2568 18.1843 5.28018 18.8155 4.33678C19.1365 3.84764 19.5182 3.40117 19.9515 3.00804C20.4081 2.61118 20.9387 2.30862 21.5128 2.11779C22.1052 1.91517 22.7422 1.88068 23.3531 2.01814C23.9729 2.17131 24.5187 2.53834 24.8944 3.05455C25.5986 3.99795 25.8378 5.04765 26.4092 5.5725C26.6685 5.83263 27.0128 5.99065 27.3791 6.01762C27.7827 6.02071 28.1821 5.9345 28.5484 5.76517C29.3507 5.36762 30.1293 4.92396 30.8804 4.43644C31.658 3.99071 32.4823 3.632 33.3385 3.36681C34.8537 2.91365 36.4126 2.62192 37.9891 2.49649C40.8459 2.25731 43.1379 2.18423 44.7324 2.1045C45.5574 2.02614 46.3885 2.03952 47.2105 2.14437Z"
                                            fill="#034833" />
                                        <path
                                            d="M45.4762 6.2697C45.4231 6.13018 46.1406 5.7382 47.2235 5.08712C47.7683 4.76158 48.4127 4.36296 49.1036 3.89126C49.4491 3.65873 49.768 3.39963 50.1666 3.13388C50.3373 3.0178 50.4954 2.88421 50.6383 2.73527C50.7579 2.61795 50.8527 2.47789 50.9173 2.32336C50.9506 2.19713 50.9173 2.20377 50.9173 2.15726C50.821 2.06916 50.7009 2.01139 50.5719 1.99117L49.283 1.64571C48.4592 1.41982 47.7218 1.20058 47.1039 0.981341C45.8682 0.582721 45.1108 0.263819 45.1573 0.124302C45.2038 -0.0152149 46.001 0.0379361 47.2833 0.250534C47.9476 0.356832 48.6784 0.502993 49.5155 0.675728L50.8443 0.968051C51.184 1.02987 51.4955 1.19726 51.7345 1.4464C51.8826 1.61431 51.9774 1.82242 52.0069 2.04432C52.0341 2.24825 52.0113 2.45574 51.9405 2.6489C51.8291 2.94985 51.6521 3.2222 51.4223 3.44614C51.235 3.63879 51.0254 3.80831 50.7978 3.95105C50.4124 4.23009 50.0205 4.47591 49.6484 4.70179C48.9845 5.09883 48.2916 5.44528 47.5756 5.7382C46.3399 6.25641 45.5294 6.40257 45.4762 6.2697Z"
                                            fill="#034833" />
                                    </g>
                                    <defs>
                                        <clipPath id="clip0_3920_930">
                                            <rect width="52" height="9.86585" fill="white"
                                                transform="translate(0 0.0664062)" />
                                        </clipPath>
                                    </defs>
                                </svg>
                            </h6>
                        <?php endif; ?>
                            <?php if ( !empty($settings['rr_banner_title' ]) ) :
                            printf( '<%1$s %2$s>%3$s</%1$s>',
                                tag_escape( $settings['rr_banner_title_tag'] ),
                                $this->get_render_attribute_string( 'title_args' ),
                                rr_kses( $settings['rr_banner_title' ] )
                                );
                        endif; ?>
                            <?php if(!empty($settings['rr_banner_btn_text'])) : ?>
                            <a <?php echo $this->get_render_attribute_string( 'rr-button-arg' ); ?>
                                data-wow-delay=".6s"><?php echo rr_kses($settings['rr_banner_btn_text']); ?> <i
                                    class="fa-solid fa-arrow-right"></i></a>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col-lg-5 col-md-12">
                        <div class="banner2__right-thumb d-flex position-relative wow fadeInLeft animated"
                            data-wow-delay=".8s">

                            <div class="banner2__right-img position-relative">
                                <div class="banner2__item">
                                    <?php if(!empty($settings['rr_core_country_title'])) : ?>
                                    <div class="banner2__item-germany upDown">
                                        <?php if(!empty($rr_country_germany)) : ?>
                                        <div class="banner2__item-indonesia-small-img">
                                            <img src="<?php echo esc_url($rr_country_germany); ?>"
                                                alt="<?php echo esc_url($rr_country_alt); ?>">
                                        </div>
                                        <?php endif; ?>
                                        <?php if(!empty($settings['rr_core_country_title'])) : ?>
                                        <div class="banner2__item-germany-text">
                                            <span><?php echo rr_kses($settings['rr_core_country_title']);?></span>
                                        </div>
                                        <?php endif; ?>
                                    </div>
                                    <?php endif; ?>
                                    <?php if(!empty($settings['rr_core_south_korea_title'])) : ?>
                                    <div class="banner2__item-south-korea upDown-top">
                                        <?php if(!empty($rr_country_south_korea)) : ?>
                                        <div class="banner2__item-indonesia-small-img">
                                            <img src="<?php echo esc_url($rr_country_south_korea); ?>"
                                                alt="<?php echo esc_url($rr_country_alt); ?>">
                                        </div>
                                        <?php endif; ?>
                                        <?php if(!empty($settings['rr_core_south_korea_title'])) : ?>
                                        <div class="banner2__item-south-korea-text">
                                            <span><?php echo rr_kses($settings['rr_core_south_korea_title']);?></span>
                                        </div>
                                        <?php endif; ?>
                                    </div>
                                    <?php endif; ?>
                                    <?php if(!empty($settings['rr_core_south_africa_title'])) : ?>
                                    <div class="banner2__item-south-africa upDown-bottom">
                                        <?php if(!empty($rr_country_south_africa)) : ?>
                                        <div class="banner2__item-south-africa-small-img">
                                            <img src="<?php echo esc_url($rr_country_south_africa); ?>"
                                                alt="<?php echo esc_url($rr_country_alt); ?>">
                                        </div>
                                        <?php endif; ?>
                                        <?php if(!empty($settings['rr_core_south_africa_title'])) : ?>
                                        <div class="banner2__item-south-africa-text">
                                            <span><?php echo rr_kses($settings['rr_core_south_africa_title']);?></span>
                                        </div>
                                        <?php endif; ?>
                                    </div>
                                    <?php endif; ?>
                                    <?php if(!empty($settings['rr_core_turkey_title'])) : ?>
                                    <div class="banner2__item-turkey leftRight">
                                        <?php if(!empty($rr_country_turkey)) : ?>
                                        <div class="banner2__item-turkey-small-img">
                                            <img src="<?php echo esc_url($rr_country_turkey); ?>"
                                                alt="<?php echo esc_url($rr_country_alt); ?>">
                                        </div>
                                        <?php endif; ?>
                                        <?php if(!empty($settings['rr_core_turkey_title'])) : ?>
                                        <div class="banner2__item-turkey-text">
                                            <span><?php echo rr_kses($settings['rr_core_turkey_title']);?></span>
                                        </div>
                                        <?php endif; ?>
                                    </div>
                                    <?php endif; ?>
                                    <?php if(!empty($settings['rr_core_indonesia_title'])) : ?>
                                    <div class="banner2__item-indonesia rightLeft">
                                        <?php if(!empty($rr_country_indonesia)) : ?>
                                        <div class="banner2__item-indonesia-small-img">
                                            <img src="<?php echo esc_url($rr_country_indonesia); ?>"
                                                alt="<?php echo esc_url($rr_country_alt); ?>">
                                        </div>
                                        <?php endif; ?>
                                        <?php if(!empty($settings['rr_core_indonesia_title'])) : ?>
                                        <div class="banner2__item-indonesia-text">
                                            <span><?php echo rr_kses($settings['rr_core_indonesia_title']);?></span>
                                        </div>
                                        <?php endif; ?>
                                    </div>
                                    <?php endif; ?>
                                </div>
                                <?php if(!empty($rr_thumbnail_image)) : ?>
                                <img src="<?php echo esc_url($rr_thumbnail_image); ?>"
                                    alt="<?php echo esc_url($rr_thumbnail_image_alt); ?>" data-tilt>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php else:

    // thumbnail image
    if ( !empty($settings['rr_thumbnail_image']['url']) ) {
        $rr_thumbnail_image = !empty($settings['rr_thumbnail_image']['id']) ? wp_get_attachment_image_url( $settings['rr_thumbnail_image']['id'], $settings['rr_thumbnail_size_size']) : $settings['rr_thumbnail_image']['url'];
        $rr_thumbnail_image_alt = get_post_meta($settings["rr_thumbnail_image"]["id"], "_wp_attachment_image_alt", true);
    }    // thumbnail image
    if ( !empty($settings['rr_thumbnail_image2']['url']) ) {
        $rr_thumbnail_image2 = !empty($settings['rr_thumbnail_image2']['id']) ? wp_get_attachment_image_url( $settings['rr_thumbnail_image2']['id'], $settings['rr_thumbnail_size_size']) : $settings['rr_thumbnail_image']['url'];
        $rr_thumbnail_image2_alt = get_post_meta($settings["rr_thumbnail_image2"]["id"], "_wp_attachment_image_alt", true);
    }
        
    // thumbnail image
    if ( !empty($settings['rr_shape_image_left']['url']) ) {
        $rr_shape_image_left = !empty($settings['rr_shape_image_left']['id']) ? wp_get_attachment_image_url( $settings['rr_shape_image_left']['id'], $settings['rr_shape_size_size']) : $settings['rr_shape_image_left']['url'];
        $rr_shape_image_alt = get_post_meta($settings["rr_shape_image_left"]["id"], "_wp_attachment_image_alt", true);
    }
        
    // thumbnail image
    if ( !empty($settings['rr_shape_image_right']['url']) ) {
        $rr_shape_image_right = !empty($settings['rr_shape_image_right']['id']) ? wp_get_attachment_image_url( $settings['rr_shape_image_right']['id'], $settings['rr_shape_size_size']) : $settings['rr_shape_image_right']['url'];
        $rr_shape_image_alt = get_post_meta($settings["rr_shape_image_right"]["id"], "_wp_attachment_image_alt", true);
    }
        
    $this->add_render_attribute('title_args', 'class', 'title mb-xs-10 wow fadeInLeft animated rr-el-title');
    // Link
    if ('2' == $settings['rr_banner_btn_link_type']) {
        $this->add_render_attribute('rr-button-arg', 'href', get_permalink($settings['rr_banner_btn_page_link']));
        $this->add_render_attribute('rr-button-arg', 'target', '_self');
        $this->add_render_attribute('rr-button-arg', 'rel', 'nofollow');
        $this->add_render_attribute('rr-button-arg', 'class', 'rr-btn btn-transparent wow fadeInLeft animated rr-el-btn');
    } else {
        if ( ! empty( $settings['rr_banner_btn_link']['url'] ) ) {
            $this->add_link_attributes( 'rr-button-arg', $settings['rr_banner_btn_link'] );
            $this->add_render_attribute('rr-button-arg', 'class', 'rr-btn btn-transparent wow fadeInLeft animated rr-el-btn');
        }
    }
?>
<section class="overflow-hidden p-relative gray-bg rr-el-section">
    <div class="banner-home">
        <div class="banner-wrap padding-space dark-green">
            <div class="container">
                <div class="banner-home__all-shape">
                    <?php if ( !empty($settings['rr_banner_shape_switcher']) ) : ?>
                    <div class="left-tower upDown-top">
                        <?php if(!empty($rr_shape_image_left)) : ?>
                        <img src="<?php echo esc_url($rr_shape_image_left); ?>"
                            alt="<?php echo esc_url($rr_shape_image_alt); ?>">
                        <?php endif; ?>
                    </div>
                    <?php endif; ?>
                </div>
                <div class="row align-items-center">
                    <div class="col-md-6 ">
                        <div class="banner-home__content p-relative">
                            <?php if ( !empty($settings['rr_banner_title' ]) ) :
                            printf( '<%1$s %2$s>%3$s</%1$s>',
                                tag_escape( $settings['rr_banner_title_tag'] ),
                                $this->get_render_attribute_string( 'title_args' ),
                                rr_kses( $settings['rr_banner_title' ] )
                                );
                        endif; ?>

                            <div class="banner-home__btn__wrapper d-flex flex-wrap mt-40 mt-md-35 mt-sm-30 mt-xs-25 ">
                            <?php if(!empty($settings['rr_banner_btn_text'])) : ?>
                                <a <?php echo $this->get_render_attribute_string( 'rr-button-arg' ); ?>
                                    data-wow-delay=".6s"><?php echo rr_kses($settings['rr_banner_btn_text']); ?> <i
                                        class="fa-solid fa-arrow-right"></i></a>
                            <?php endif; ?>
                            <?php if(!empty($settings['rr_core_video_url'])) : ?>
                                <a href="<?php echo esc_url($settings['rr_core_video_url']);?>"
                                    class="popup-video zooming banner-video-button rr-el-video"
                                    data-effect="mfp-move-from-top vertical-middle">
                                    <svg width="26" height="28" viewBox="0 0 26 28" fill="none"
                                        xmlns="http://www.w3.org/2000/svg">
                                        <g filter="url(#filter0_d_836_9)">
                                            <path
                                                d="M19.5 10.134C20.1667 10.5189 20.1667 11.4811 19.5 11.866L7.5 18.7942C6.83333 19.1791 6 18.698 6 17.9282L6 4.0718C6 3.302 6.83333 2.82087 7.5 3.20577L19.5 10.134Z"
                                                fill="#fff" />
                                        </g>
                                        <defs>
                                            <filter id="filter0_d_836_9" x="0" y="0.0703125" width="26" height="27.8594"
                                                filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
                                                <feFlood flood-opacity="0" result="BackgroundImageFix" />
                                                <feColorMatrix in="SourceAlpha" type="matrix"
                                                    values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
                                                    result="hardAlpha" />
                                                <feOffset dy="3" />
                                                <feGaussianBlur stdDeviation="3" />
                                                <feComposite in2="hardAlpha" operator="out" />
                                                <feColorMatrix type="matrix"
                                                    values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.1 0" />
                                                <feBlend mode="normal" in2="BackgroundImageFix"
                                                    result="effect1_dropShadow_836_9" />
                                                <feBlend mode="normal" in="SourceGraphic" in2="effect1_dropShadow_836_9"
                                                    result="shape" />
                                            </filter>
                                        </defs>
                                    </svg>
                                </a>
                                <a class="popup-video video-text wow fadeInLeft animated rr-el-video-text"
                                    data-wow-delay=".8s"
                                    href="<?php echo esc_url($settings['rr_core_video_url']);?>"><?php echo rr_kses($settings['rr_core_video_title']);?></a>
                            <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 ">
                        <div class="banner-home__shape position-relative wow fadeInLeft animated" data-wow-delay=".9s">
                            <?php if ( !empty($settings['rr_banner_shape_switcher']) ) : ?>
                            <div class="ball-shape upDown">
                            <?php if(!empty($rr_thumbnail_image2)) : ?>
                                <img src="<?php echo esc_url($rr_thumbnail_image2); ?>"
                                    alt="<?php echo esc_url($rr_thumbnail_image2_alt); ?>">
                                <?php endif; ?>
                            </div>
                            <?php endif; ?>
                            <div class="man-img leftRight">
                                <?php if(!empty($rr_thumbnail_image)) : ?>
                                <img src="<?php echo esc_url($rr_thumbnail_image); ?>"
                                    alt="<?php echo esc_url($rr_thumbnail_image_alt); ?>">
                                <?php endif; ?>
                            </div>
                            <?php if ( !empty($settings['rr_banner_shape_switcher']) ) : ?>
                            <div class="right-tower upDown-bottom">
                                <?php if(!empty($rr_shape_image_right)) : ?>
                                <img src="<?php echo esc_url($rr_shape_image_right); ?>"
                                    alt="<?php echo esc_url($rr_shape_image_alt); ?>">
                                <?php endif; ?>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php endif; 
		
	}
}
$widgets_manager->register( new rr_Hero_Banner() );