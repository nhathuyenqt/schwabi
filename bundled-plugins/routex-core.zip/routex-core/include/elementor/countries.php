<?php
namespace RRCore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Repeater;
use \Elementor\Utils;
use \Elementor\Control_Media;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * RR Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class RR_Countries extends Widget_Base {

	use \RRCore\Widgets\RRCoreElementFunctions;

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'rr_countries';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Countries', 'rr-core' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'rr-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'rr-core' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'rr-core' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
    protected function register_controls(){
        $this->register_controls_section();
        $this->style_tab_content();
    }  

    protected function register_controls_section(){
        // layout Panel
        $this->start_controls_section(
            'rr_layout',
            [
                'label' => esc_html__('Design Layout', 'rr-core'),
            ]
        );
        $this->add_control(
            'rr_design_style',
            [
                'label' => esc_html__('Select Layout', 'rr-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Layout 1', 'rr-core'),
                    'layout-2' => esc_html__('Layout 2', 'rr-core'),
                ],
                'default' => 'layout-1',
            ]
        );

        $this->end_controls_section();

   
        $this->start_controls_section(
			'about_text_list_sec',
				[
				  'label' => esc_html__( 'Text Slider', 'rr-core' ),
				  'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
				  'condition' => [
					   'rr_design_style' => ['layout-1', 'layout-2']
				  ]
				]
		   );   
	
		   // repeater for about features list with text , testarea and icon
		   $repeater = new Repeater();

		   $repeater->add_control(
            'image',
            [
                'type' => Controls_Manager::MEDIA,
                'label' => __( 'Image', 'rr-core' ),
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );                      

		   $repeater->add_control(
			   'rr_about_features_list_title',
			   [
				   'label' => esc_html__('Title', 'rr-core'),
				   'type' => Controls_Manager::TEXT,
				   'default' => esc_html__('Custom shortcodes', 'rr-core'),
				   'title' => esc_html__('Enter title', 'rr-core'),
				   'label_block' => true
				   
			   ]
		   );
		   $repeater->add_control(
			   'rr_about_blod_title',
			   [
				   'label' => esc_html__('Title Blod', 'rr-core'),
				   'type' => Controls_Manager::TEXT,
				   'default' => esc_html__('Health Guard', 'rr-core'),
				   'title' => esc_html__('Enter title', 'rr-core'),
				   'label_block' => true
				   
			   ]
		   );
		   $this->add_group_control(
            Group_Control_Image_Size::get_type(),
            [
                'name' => 'thumbnail',
                'default' => 'medium_large',
                'separator' => 'before',
                'exclude' => [
                    'custom'
                ]
            ]
        );
		   $this->add_control(
			   'rr_about_features_list',
			   [
				   'label' => esc_html__('Text Slider', 'rr-core'),
				   'type' => Controls_Manager::REPEATER,
				   'fields' => $repeater->get_controls(),
				   'default' => [
					   [
						   'rr_about_features_list_title' => esc_html__('Custom shortcodes', 'rr-core'),
					   ],
					   [
						   'rr_about_blod_title' => esc_html__('Health Guard', 'rr-core'),
					   ],
					   [
						   'rr_about_features_list_title' => esc_html__('Custom shortcodes', 'rr-core'),
					   ],
					   [
						   'rr_about_blod_title' => esc_html__('Health Guard', 'rr-core'),
					   ]
				   ],
				   'title_field' => '{{{ rr_about_features_list_title }}}',
			   ]
		   );
   
		   $this->end_controls_section();
		   
   
    }

    protected function style_tab_content(){
		$this->rr_basic_style_controls('history_title', 'Title', '.rr-el-box-title');
    }

	/**
	 * Render the widget ouRRut on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		?>

<?php if ( $settings['rr_design_style']  == 'layout-2' ): ?>


<?php else: ?>
	<div class="slider-text">
    <div class="container">
        <div class="rr-scroller" data-speed="slow" data-animated="true">
            <ul class="text-anim rr-scroller__inner">
                <?php  
					if ( !empty($settings['rr_about_features_list']) ) :
						foreach ( $settings['rr_about_features_list'] as $item ) :
						if ( !empty($item['image']['url']) ) {
							$rr_text_image_url = !empty($item['image']['id']) ? wp_get_attachment_image_url( $item['image']['id'], $settings['thumbnail_size']) : $item['image']['url'];
							$rr_text_image_alt = get_post_meta($item["image"]["id"], "_wp_attachment_image_alt", true);
						} 
						$title = $item['rr_about_features_list_title'];
				?>
                <li aria-hidden="true"><img
                        src="<?php echo esc_url($rr_text_image_url); ?>"
                        alt="<?php echo esc_attr($rr_text_image_alt); ?>"></li>
                <li aria-hidden="true"><?php echo rr_kses( $item['rr_about_features_list_title'] ); ?></li>
                <li aria-hidden="true"><img
                        src="<?php echo esc_url($rr_text_image_url); ?>"
                        alt="<?php echo esc_attr($rr_text_image_alt); ?>"></li>
                <li><strong><?php echo rr_kses($item['rr_about_blod_title']);?></strong></li>
                <?php endforeach; endif; ?>
            </ul>
        </div>
    </div>
</div>
<?php endif; 
	}
}

$widgets_manager->register( new RR_Countries() );