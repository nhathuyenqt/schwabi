<?php
namespace RRCore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Repeater;
use \Elementor\Utils;
use \Elementor\Control_Media;
use RRCore\Elementor\Controls\Group_Control_RRBGGradient;
use RRCore\Elementor\Controls\Group_Control_RRGradient;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * RR Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class rr_About extends Widget_Base {

    use \RRCore\Widgets\RRCoreElementFunctions;

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'about';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'About', 'rr-core' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'rr-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'rr-core' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'rr-core' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */

    protected function register_controls(){
        $this->register_controls_section();
        $this->style_tab_content();
    }  

	protected function register_controls_section() {

        // layout Panel
        $this->start_controls_section(
            'rr_layout',
            [
                'label' => esc_html__('Design Layout', 'rr-core'),
            ]
        );
        $this->add_control(
            'rr_design_style',
            [
                'label' => esc_html__('Select Layout', 'rr-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Layout 1', 'rr-core'),
                    'layout-2' => esc_html__('Layout 2', 'rr-core'),
                    'layout-3' => esc_html__('Layout 3', 'rr-core'),
                    'layout-4' => esc_html__('Layout 4', 'rr-core'),
                    'layout-5' => esc_html__('Layout 5', 'rr-core'),
                ],
                'default' => 'layout-1',
            ]
        );

        $this->end_controls_section();

        $this->rr_section_title_render_controls('about', 'Section Title', 'Sub Title', 'your title here', $default_description = 'Hic nesciunt galisum aut dolorem aperiam eum soluta quod ea cupiditate.',['layout-1', 'layout-2','layout-3','layout-4','layout-5']);

        // button
        $this->rr_button_render('about', 'Button', ['layout-1', 'layout-2', 'layout-3', 'layout-4', 'layout-5']);
        
        // _rr_image
		$this->start_controls_section(
            '_rr_image',
            [
                'label' => esc_html__('Thumbnail', 'rr-core'),
            ]
        );
        $this->add_control(
            'rr_image',
            [
                'label' => esc_html__( 'Choose Image', 'rr-core' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );
        $this->add_control(
            'rr_image_2',
            [
                'label' => esc_html__( 'Choose Image 2', 'rr-core' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
                'condition' => [
                    'rr_design_style' => ['layout-1', 'layout-3', 'layout-4', 'layout-5']
                ]

            ]
        );
        $this->add_control(
            'rr_image_3',
            [
                'label' => esc_html__( 'Choose Image 3', 'rr-core' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
                'condition' => [
                    'rr_design_style' => ['layout-1', 'layout-3']
                ]

            ]
        );


        $this->add_group_control(
            Group_Control_Image_Size::get_type(),
            [
                'name' => 'rr_image_size',
                'default' => 'full',
                'exclude' => [
                    'custom'
                ]
            ]
        );

        $this->end_controls_section();
        $this->start_controls_section(
            'rr_about_list',
            [
                'label' => esc_html__('About List', 'rr-core'),
                'condition' => [
                    'rr_design_style' => ['layout-2', 'layout-3', 'layout-4']
                ]
            ]
        );
        $this->add_control(
            'rr_about_list_switch',
            [
            'label'        => esc_html__( 'About List On/Off', 'rr-core' ),
            'type'         => \Elementor\Controls_Manager::SWITCHER,
            'label_on'     => esc_html__( 'Show', 'rr-core' ),
            'label_off'    => esc_html__( 'Hide', 'rr-core' ),
            'return_value' => 'yes',
            'default'      => '1',
            ]
        ); 

        $repeater = new \Elementor\Repeater();
        
        $repeater->add_control(
        'rr_box_icon_type_list',
        [
            'label' => esc_html__('Select Icon Type', 'rr-core'),
            'type' => \Elementor\Controls_Manager::SELECT,
            'default' => 'icon',
            'options' => [
                'image' => esc_html__('Image', 'rr-core'),
                'icon' => esc_html__('Icon', 'rr-core'),
                'svg' => esc_html__('SVG', 'rr-core'),
            ],

        ]
    );
    $repeater->add_control(
        'rr_box_icon_svg_list',
        [
            'show_label' => false,
            'type' => Controls_Manager::TEXTAREA,
            'label_block' => true,
            'placeholder' => esc_html__('SVG Code Here', 'rr-core'),
            'condition' => [
                'rr_box_icon_type_list' => 'svg'
            ]
        ]
    );

    $repeater->add_control(
        'rr_box_icon_image_list',
        [
            'label' => esc_html__('Upload Icon Image', 'rr-core'),
            'type' => Controls_Manager::MEDIA,
            'default' => [
                'url' => Utils::get_placeholder_image_src(),
            ],
            'condition' => [
                'rr_box_icon_type_list' => 'image',
            ]
        ]
    );

    if (rr_is_elementor_version('<', '2.6.0')) {
        $repeater->add_control(
            'rr_box_icon_list',
            [
                'show_label' => false,
                'type' => Controls_Manager::ICON,
                'label_block' => true,
                'default' => 'fa fa-star',
                'condition' => [
                    'rr_box_icon_type_list' => 'icon'
                ]
            ]
        );
    } else {
        $repeater->add_control(
            'rr_box_selected_icon_list',
            [
                'show_label' => false,
                'type' => Controls_Manager::ICONS,
                'fa4compatibility' => 'icon',
                'label_block' => true,
                'default' => [
                    'value' => 'fas fa-star',
                    'library' => 'solid',
                ],
                'condition' => [
                    'rr_box_icon_type_list' => 'icon'
                ]
            ]
        );
    }
        $repeater->add_control(
            'rr_about_title_list',
            [
                'label' => esc_html__('About Title', 'rr-core'),
                'type' => Controls_Manager::TEXTAREA,
                'title' => esc_html__('About Title', 'rr-core'),
                'label_block' => true,
                'default'   => 'Nemo enim ipsam',
            ]
        );
        $repeater->add_control(
            'rr_about_discription_list',
            [
                'label' => esc_html__('About Discription', 'rr-core'),
                'type' => Controls_Manager::TEXTAREA,
                'title' => esc_html__('About Discription', 'rr-core'),
                'label_block' => true,
                'default'   => 'Nemo enim ipsam voluptatem quia voluptas sit aspernatur odit aut fugit',
            ]
        );
        $this->add_control(
            'rr_about_list_main_list',
            [
            'label'       => esc_html__( 'About List', 'rr-core' ),
            'type'        => \Elementor\Controls_Manager::REPEATER,
            'fields'      => $repeater->get_controls(),
            'default'     => [
                [
                'rr_extra_about_title_list'   => esc_html__( ' Mistakes To Avoid to dum Auam. ', 'rr-core' ),
                ],
                [
                'rr_extra_about_title_list'   => esc_html__( 'Avoid to the dumy mistakes', 'rr-core' ),
                ],
                [
                'rr_extra_about_title_list'   => esc_html__( ' Your Startup industry stan', 'rr-core' ),
                ],
            ],
            'title_field' => '{{{ rr_extra_about_title_list }}}',
            ]
        );

        $this->end_controls_section();
        
        $this->start_controls_section(
            'rr_extra_about',
            [
                'label' => esc_html__('About Extra Info', 'rr-core'),
                'condition' => [
                    'rr_design_style' => ['layout-1']
                ]
            ]
        );
        $this->add_control(
            'rr_about_extra_switch',
            [
            'label'        => esc_html__( 'About Extra On/Off', 'rr-core' ),
            'type'         => \Elementor\Controls_Manager::SWITCHER,
            'label_on'     => esc_html__( 'Show', 'rr-core' ),
            'label_off'    => esc_html__( 'Hide', 'rr-core' ),
            'return_value' => 'yes',
            'default'      => '1',
            ]
        ); 
           
        $this->add_control(
            'rr_box_icon_type',
            [
                'label' => esc_html__('Select Icon Type', 'rr-core'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'icon',
                'options' => [
                    'image' => esc_html__('Image', 'rr-core'),
                    'icon' => esc_html__('Icon', 'rr-core'),
                    'svg' => esc_html__('SVG', 'rr-core'),
                ],
    
            ]
        );
        $this->add_control(
            'rr_box_icon_svg',
            [
                'show_label' => false,
                'type' => Controls_Manager::TEXTAREA,
                'label_block' => true,
                'placeholder' => esc_html__('SVG Code Here', 'rr-core'),
                'condition' => [
                    'rr_box_icon_type' => 'svg'
                ]
            ]
        );
    
        $this->add_control(
            'rr_box_icon_image',
            [
                'label' => esc_html__('Upload Icon Image', 'rr-core'),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
                'condition' => [
                    'rr_box_icon_type' => 'image',
                ]
            ]
        );
    
        if (rr_is_elementor_version('<', '2.6.0')) {
            $this->add_control(
                'rr_box_icon',
                [
                    'show_label' => false,
                    'type' => Controls_Manager::ICON,
                    'label_block' => true,
                    'default' => 'fa fa-star',
                    'condition' => [
                        'rr_box_icon_type' => 'icon'
                    ]
                ]
            );
        } else {
            $this->add_control(
                'rr_box_selected_icon',
                [
                    'show_label' => false,
                    'type' => Controls_Manager::ICONS,
                    'fa4compatibility' => 'icon',
                    'label_block' => true,
                    'default' => [
                        'value' => 'fas fa-star',
                        'library' => 'solid',
                    ],
                    'condition' => [
                        'rr_box_icon_type' => 'icon'
                    ]
                ]
            );
        }
        $this->add_control(
            'rr_about_title_main',
            [
                'label' => esc_html__('About Title', 'rr-core'),
                'type' => Controls_Manager::TEXTAREA,
                'title' => esc_html__('About Title', 'rr-core'),
                'label_block' => true,
                'default'   => 'Nemo enim ipsam',
            ]
        );
        $repeater = new \Elementor\Repeater();
        
        $repeater->add_control(
        'rr_box_icon_type',
        [
            'label' => esc_html__('Select Icon Type', 'rr-core'),
            'type' => \Elementor\Controls_Manager::SELECT,
            'default' => 'icon',
            'options' => [
                'image' => esc_html__('Image', 'rr-core'),
                'icon' => esc_html__('Icon', 'rr-core'),
                'svg' => esc_html__('SVG', 'rr-core'),
            ],

        ]
    );
    $repeater->add_control(
        'rr_box_icon_svg',
        [
            'show_label' => false,
            'type' => Controls_Manager::TEXTAREA,
            'label_block' => true,
            'placeholder' => esc_html__('SVG Code Here', 'rr-core'),
            'condition' => [
                'rr_box_icon_type' => 'svg'
            ]
        ]
    );

    $repeater->add_control(
        'rr_box_icon_image',
        [
            'label' => esc_html__('Upload Icon Image', 'rr-core'),
            'type' => Controls_Manager::MEDIA,
            'default' => [
                'url' => Utils::get_placeholder_image_src(),
            ],
            'condition' => [
                'rr_box_icon_type' => 'image',
            ]
        ]
    );

    if (rr_is_elementor_version('<', '2.6.0')) {
        $repeater->add_control(
            'rr_box_icon',
            [
                'show_label' => false,
                'type' => Controls_Manager::ICON,
                'label_block' => true,
                'default' => 'fa fa-star',
                'condition' => [
                    'rr_box_icon_type' => 'icon'
                ]
            ]
        );
    } else {
        $repeater->add_control(
            'rr_box_selected_icon',
            [
                'show_label' => false,
                'type' => Controls_Manager::ICONS,
                'fa4compatibility' => 'icon',
                'label_block' => true,
                'default' => [
                    'value' => 'fas fa-star',
                    'library' => 'solid',
                ],
                'condition' => [
                    'rr_box_icon_type' => 'icon'
                ]
            ]
        );
    }
        $repeater->add_control(
            'rr_about_discription',
            [
                'label' => esc_html__('Extra About Discription', 'rr-core'),
                'type' => Controls_Manager::TEXTAREA,
                'title' => esc_html__('Enter About Discription', 'rr-core'),
                'label_block' => true,
                'default'   => 'Nemo enim ipsam voluptatem quia voluptas sit aspernatur odit aut fugit',
            ]
        );
        $this->add_control(
            'rr_about_list_main',
            [
            'label'       => esc_html__( 'About List', 'rr-core' ),
            'type'        => \Elementor\Controls_Manager::REPEATER,
            'fields'      => $repeater->get_controls(),
            'default'     => [
                [
                'rr_extra_about_title'   => esc_html__( ' Mistakes To Avoid to dum Auam. ', 'rr-core' ),
                ],
                [
                'rr_extra_about_title'   => esc_html__( 'Avoid to the dumy mistakes', 'rr-core' ),
                ],
                [
                'rr_extra_about_title'   => esc_html__( ' Your Startup industry stan', 'rr-core' ),
                ],
            ],
            'title_field' => '{{{ rr_extra_about_title }}}',
            ]
        );

        $this->end_controls_section();
        
         // Extra About Section
         $this->start_controls_section(
            'rr_extra_about_2',
            [
                'label' => esc_html__('About Extra Info 2', 'rr-core'),
                'condition' => [
                    'rr_design_style' => ['layout-1']
                ]
            ]
        );
        $this->add_control(
            'rr_about_extra2_switch',
            [
            'label'        => esc_html__( 'About List On/Off', 'rr-core' ),
            'type'         => \Elementor\Controls_Manager::SWITCHER,
            'label_on'     => esc_html__( 'Show', 'rr-core' ),
            'label_off'    => esc_html__( 'Hide', 'rr-core' ),
            'return_value' => 'yes',
            'default'      => '1',
            ]
        ); 

        $this->add_control(
            'rr_box_icon_type_2',
            [
                'label' => esc_html__('Select Icon Type', 'rr-core'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'icon',
                'options' => [
                    'image' => esc_html__('Image', 'rr-core'),
                    'icon' => esc_html__('Icon', 'rr-core'),
                    'svg' => esc_html__('SVG', 'rr-core'),
                ],
    
            ]
        );
        $this->add_control(
            'rr_box_icon_svg_2',
            [
                'show_label' => false,
                'type' => Controls_Manager::TEXTAREA,
                'label_block' => true,
                'placeholder' => esc_html__('SVG Code Here', 'rr-core'),
                'condition' => [
                    'rr_box_icon_type_2' => 'svg'
                ]
            ]
        );
    
        $this->add_control(
            'rr_box_icon_image_2',
            [
                'label' => esc_html__('Upload Icon Image', 'rr-core'),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
                'condition' => [
                    'rr_box_icon_type_2' => 'image',
                ]
            ]
        );
    
        if (rr_is_elementor_version('<', '2.6.0')) {
            $this->add_control(
                'rr_box_icon_2',
                [
                    'show_label' => false,
                    'type' => Controls_Manager::ICON,
                    'label_block' => true,
                    'default' => 'fa fa-star',
                    'condition' => [
                        'rr_box_icon_type_2' => 'icon'
                    ]
                ]
            );
        } else {
            $this->add_control(
                'rr_box_selected_icon_2',
                [
                    'show_label' => false,
                    'type' => Controls_Manager::ICONS,
                    'fa4compatibility' => 'icon',
                    'label_block' => true,
                    'default' => [
                        'value' => 'fas fa-star',
                        'library' => 'solid',
                    ],
                    'condition' => [
                        'rr_box_icon_type_2' => 'icon'
                    ]
                ]
            );
        }
        $this->add_control(
            'rr_about_title_main_2',
            [
                'label' => esc_html__('About Title', 'rr-core'),
                'type' => Controls_Manager::TEXTAREA,
                'title' => esc_html__('About Title', 'rr-core'),
                'label_block' => true,
                'default'   => 'Nemo enim ipsam',
            ]
        );
        $repeater = new \Elementor\Repeater();
        
        $repeater->add_control(
        'rr_box_icon_type_2',
        [
            'label' => esc_html__('Select Icon Type', 'rr-core'),
            'type' => \Elementor\Controls_Manager::SELECT,
            'default' => 'icon',
            'options' => [
                'image' => esc_html__('Image', 'rr-core'),
                'icon' => esc_html__('Icon', 'rr-core'),
                'svg' => esc_html__('SVG', 'rr-core'),
            ],

        ]
    );
    $repeater->add_control(
        'rr_box_icon_svg_2',
        [
            'show_label' => false,
            'type' => Controls_Manager::TEXTAREA,
            'label_block' => true,
            'placeholder' => esc_html__('SVG Code Here', 'rr-core'),
            'condition' => [
                'rr_box_icon_type_2' => 'svg'
            ]
        ]
    );

    $repeater->add_control(
        'rr_box_icon_image_2',
        [
            'label' => esc_html__('Upload Icon Image', 'rr-core'),
            'type' => Controls_Manager::MEDIA,
            'default' => [
                'url' => Utils::get_placeholder_image_src(),
            ],
            'condition' => [
                'rr_box_icon_type_2' => 'image',
            ]
        ]
    );

    if (rr_is_elementor_version('<', '2.6.0')) {
        $repeater->add_control(
            'rr_box_icon_2',
            [
                'show_label' => false,
                'type' => Controls_Manager::ICON,
                'label_block' => true,
                'default' => 'fa fa-star',
                'condition' => [
                    'rr_box_icon_type_2' => 'icon'
                ]
            ]
        );
    } else {
        $repeater->add_control(
            'rr_box_selected_icon_2',
            [
                'show_label' => false,
                'type' => Controls_Manager::ICONS,
                'fa4compatibility' => 'icon',
                'label_block' => true,
                'default' => [
                    'value' => 'fas fa-star',
                    'library' => 'solid',
                ],
                'condition' => [
                    'rr_box_icon_type_2' => 'icon'
                ]
            ]
        );
    }
        $repeater->add_control(
            'rr_about_discription_2',
            [
                'label' => esc_html__('Extra About Discription', 'rr-core'),
                'type' => Controls_Manager::TEXTAREA,
                'title' => esc_html__('Enter About Discription', 'rr-core'),
                'label_block' => true,
                'default'   => 'Nemo enim ipsam voluptatem quia voluptas sit aspernatur odit aut fugit',
            ]
        );
        $this->add_control(
            'rr_about_list_main_2',
            [
            'label'       => esc_html__( 'About List', 'rr-core' ),
            'type'        => \Elementor\Controls_Manager::REPEATER,
            'fields'      => $repeater->get_controls(),
            'default'     => [
                [
                'rr_extra_about_title_2'   => esc_html__( ' Mistakes To Avoid to dum Auam. ', 'rr-core' ),
                ],
                [
                'rr_extra_about_title_2'   => esc_html__( 'Avoid to the dumy mistakes', 'rr-core' ),
                ],
                [
                'rr_extra_about_title_2'   => esc_html__( ' Your Startup industry stan', 'rr-core' ),
                ],
            ],
            'title_field' => '{{{ rr_extra_about_title_2 }}}',
            ]
        );

        $this->end_controls_section();
        
            $this->start_controls_section(
                'rr_about_experience',
                    [
                    'label' => esc_html__( 'Experience', 'rr-core' ),
                    'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
                    'condition' => [
                        'rr_design_style' => ['layout-1', 'layout-2', 'layout-3', 'layout-4']
                    ]
                ]
            );
          
            $this->add_control(
                'rr_about_experience_switch',
                [
                'label'        => esc_html__( 'Experience On/Off', 'rr-core' ),
                'type'         => \Elementor\Controls_Manager::SWITCHER,
                'label_on'     => esc_html__( 'Show', 'rr-core' ),
                'label_off'    => esc_html__( 'Hide', 'rr-core' ),
                'return_value' => 'yes',
                'default'      => '1',
                ]
            );
            $this->add_control(
                'rr_extra_about_experience',
                [
                    'label' => esc_html__('Extra About Experience Number', 'rr-core'),
                    'type' => Controls_Manager::TEXT,
                    'title' => esc_html__('Enter Extra About Experience Number', 'rr-core'),
                    'label_block' => true,
                ]
            );
            $this->add_control(
                'rr_abouot_experience',
                [
                    'label' => esc_html__('About Experience Paragrap', 'rr-core'),
                    'type' => Controls_Manager::TEXT,
                    'title' => esc_html__('Enter About Experience Paragrap', 'rr-core'),
                    'label_block' => true,
                ]
            );
            $this->end_controls_section();
          
            $this->start_controls_section(
                'rr_about_call',
                    [
                    'label' => esc_html__( 'About Call', 'rr-core' ),
                    'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
                    'condition' => [
                        'rr_design_style' => ['layout-1', 'layout-2']
                    ]
                ]
            );
            $this->add_control(
                'rr_about_call_switch',
                [
                'label'        => esc_html__( 'Call Swittcher', 'rr-core' ),
                'type'         => \Elementor\Controls_Manager::SWITCHER,
                'label_on'     => esc_html__( 'Show', 'rr-core' ),
                'label_off'    => esc_html__( 'Hide', 'rr-core' ),
                'return_value' => 'yes',
                'default'      => '1',
                ]
            );
            $this->add_control(
                'rr_about_call_number',
                [ 
                    'label' => esc_html__('About Call', 'rr-core'),
                    'type' => Controls_Manager::TEXT,
                    'title' => esc_html__('Enter About Call', 'rr-core'),
                    'label_block' => true,
                    'default'   => '+98928327364'
                ]
            );

            $this->add_control(
                'rr_about_call_number_url',
                [
                    'label' => esc_html__( 'About Call', 'text-domain' ),
                    'type' => Controls_Manager::URL,
                    'options' => [ 'url', 'is_external', 'nofollow' ],
                    'default' => [
                        'url' => '',
                        'is_external' => true,
                        'nofollow' => true,
                    ],
                    'label_block' => true,
                ]
            );
            $this->end_controls_section();
              // Skill
        $this->start_controls_section(
            'rr_progress_bar',
            [
                'label' => esc_html__('Skill Bar', 'rr-core', ['layout-1', 'layout-2']),
            ]
        );
        $this->add_control(
            'rr_about_skill_switch',
            [
            'label'        => esc_html__( 'Skill Swittcher', 'rr-core' ),
            'type'         => \Elementor\Controls_Manager::SWITCHER,
            'label_on'     => esc_html__( 'Show', 'rr-core' ),
            'label_off'    => esc_html__( 'Hide', 'rr-core' ),
            'return_value' => 'yes',
            'default'      => '1',
            ]
        );
        $repeater = new Repeater();

        $repeater->add_control(
            'rr_skill_box_title',
            [
                'type' => Controls_Manager::TEXT,
                'label' => esc_html__( 'Skill Title', 'rr-core' ),
                'default' => esc_html__( 'Design', 'rr-core' ),
                'placeholder' => esc_html__( 'Type a skill name', 'rr-core' ),
                'label_block' => true
            ]
        );

        $repeater->add_control(
            'rr_skill_num',
            [
                'label'       => esc_html__( 'Skill Number', 'rr-core' ),
                'type'        => \Elementor\Controls_Manager::TEXT,
                'default'     => esc_html__( '85', 'rr-core' ),
                'placeholder' => esc_html__( 'Your Number', 'rr-core' ),
            ]
        );

        $this->add_control(
            'rr_skill_list',
            [
                'label' => esc_html__('Services - List', 'rr-core'),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'rr_skill_box_title' => esc_html__('Design', 'rr-core'),
                        'rr_skill_num' => '70',
                    ],
                    [
                        'rr_skill_box_title' => esc_html__('Development', 'rr-core'),
                        'rr_skill_num' => '80',
                    ],
                    [
                        'rr_skill_box_title' => esc_html__('Customization', 'rr-core'),
                        'rr_skill_num' => '95',
                    ],
                ],
                'title_field' => '{{{ rr_skill_box_title }}}',
            ]
        );

        $this->end_controls_section();
   // _rr_image
   $this->start_controls_section(
    '_rr_image_circle',
    [
        'label' => esc_html__('Circle', 'rr-core'),
        'condition' => [
            'rr_design_style' => ['layout-5']
        ]
    ]
    );
    $this->add_control(
        'rr_about_circle_switch',
        [
        'label'        => esc_html__( 'Circle Swittcher', 'rr-core' ),
        'type'         => \Elementor\Controls_Manager::SWITCHER,
        'label_on'     => esc_html__( 'Show', 'rr-core' ),
        'label_off'    => esc_html__( 'Hide', 'rr-core' ),
        'return_value' => 'yes',
        'default'      => '1',
        ]
    );
    $this->add_control(
        'rr_image_circle',
        [
            'label' => esc_html__( 'Choose Image', 'rr-core' ),
            'type' => \Elementor\Controls_Manager::MEDIA,
            'default' => [
                'url' => \Elementor\Utils::get_placeholder_image_src(),
            ],
        ]
    );

    $this->add_group_control(
        Group_Control_Image_Size::get_type(),
        [
            'name' => 'rr_circle_size',
            'default' => 'full',
            'exclude' => [
                'custom'
            ]
        ]
    );

    $this->end_controls_section();
    $this->start_controls_section(
        'rr_shap_section',
            [
                'label' => esc_html__( 'Shape', 'rr-core' ),
                'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'rr_shape_switcher',
            [
                'label' => esc_html__( 'About Shape', 'rr-core' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Yes', 'rr-core' ),
                'label_off' => esc_html__( 'No', 'rr-core' ),
                'return_value' => 'yes',
                'default' => 'yes',
                'separator' => 'before',
            ]
        );

        $this->end_controls_section();
	}

    // style_tab_content
    protected function style_tab_content(){
        $this->rr_section_style_controls('about_section', 'Section - Style', '.rr-el-section'); 
        $this->rr_basic_style_controls('section_sub_title', 'Section - Sub Title', '.rr-el-sub-title');
        $this->rr_basic_style_controls('section_title', 'Section - Title', '.rr-el-title');
        $this->rr_basic_style_controls('section_desc', 'Section - Description', '.rr-el-desc');
        $this->rr_basic_style_controls('about_title_experience', 'Experience - Title', '.rr-rp-title-experience');
        $this->rr_basic_style_controls('about_desc_experience', 'Experience - Number', '.rr-rp-experience');
        $this->rr_link_controls_style('about_desc_experience_box', 'Experience - Box', '.rr-el-experience-box');
        $this->rr_basic_style_controls('about_title', 'About - Title', '.rr-rp-title');
        $this->rr_basic_style_controls('about_desc', 'About - Description', '.rr-rp-desc');
        $this->rr_link_controls_style('about_btn', 'About - Button', '.rr-el-btn');
        $this->rr_basic_style_controls('section_exp_rp', 'About - Rep List', '.rr-rp-title-main');
        $this->rr_basic_style_controls('experience', 'Experience', '.rr-el-experience'); 
        $this->rr_link_controls_style('about_rp_icon', 'About - Rep Icon', '.rr-el-rep-icon');
        $this->rr_basic_style_controls('number_label', 'About - Number label', '.rr-el-number-label'); 
        $this->rr_basic_style_controls('number', 'About - Number', '.rr-el-number'); 
        $this->rr_link_controls_style('about_call_icon', 'About - Call Icon', '.rr-el-coll-icon');
    }

	/**
	 * Render the widget ouRRut on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		?>

<?php if ( $settings['rr_design_style']  == 'layout-2' ): 

    if ( !empty($settings['rr_image']['url']) ) {
        $rr_image = !empty($settings['rr_image']['id']) ? wp_get_attachment_image_url( $settings['rr_image']['id'], $settings['rr_image_size_size']) : $settings['rr_image']['url'];
        $rr_image_alt = get_post_meta($settings["rr_image"]["id"], "_wp_attachment_image_alt", true);
    }
    // Link
    if ('2' == $settings['rr_about_btn_link_type']) {
        $this->add_render_attribute('rr-button-arg', 'href', get_permalink($settings['rr_about_btn_page_link']));
        $this->add_render_attribute('rr-button-arg', 'target', '_self');
        $this->add_render_attribute('rr-button-arg', 'rel', 'nofollow');
        $this->add_render_attribute('rr-button-arg', 'class', 'choose-us__button-btn-2 rr-el-btn');
    } else {
        if ( ! empty( $settings['rr_about_btn_link']['url'] ) ) {
            $this->add_link_attributes( 'rr-button-arg', $settings['rr_about_btn_link'] );
            $this->add_render_attribute('rr-button-arg', 'class', 'choose-us__button-btn-2 rr-el-btn');
        }
    }
    $this->add_render_attribute('title_args', 'class', 'section__title-wrapper-title wow fadeInLeft animated rr-el-title');
?>
<section class="choose-us2__area choose-us bottom-160 p-relative gray-bg rr-el-section">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-xl-6 col-lg-6">
                <div class="choose-us2__thumb position-relative">
                    <?php if(!empty($rr_image)) : ?>
                    <div class="choose-us2__thumb-media">
                        <div class="choose-us2__thumb-media-border"></div>
                        <img src="<?php echo esc_url($rr_image); ?>" alt="<?php echo esc_attr($rr_image_alt); ?>"
                            data-tilt>
                    </div>
                    <?php endif; ?>
                    <?php if ( !empty($settings['rr_about_experience_switch']) ) : ?>
                    <div class="choose-us__text choose-us2__text" data-parallax='{"y": -160, "smoothness": 15}'>
                        <h3 class="counter__item-title"><span class="odometer"
                                data-count="<?php echo rr_kses( $settings['rr_extra_about_experience']);?>">0</span>
                        </h3>
                        <?php if ( !empty($settings['rr_abouot_experience']) ) : ?>
                        <p><?php echo rr_kses( $settings['rr_abouot_experience']);?></p>
                        <?php endif; ?>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-xl-6 col-lg-6">
                <?php if ( !empty($settings['rr_about_section_title_show']) ) : ?>
                <div class="choose-us2__content mt-lg-40 mt-md-40 mt-sm-40 mt-xs-40">
                    <div class="section__title-wrapper mb-20">
                        <?php if ( !empty($settings['rr_about_sub_title']) ) : ?>
                        <h6 class="section__title-wrapper-black-subtitle mb-10 wow fadeInLeft animated rr-el-sub-title"
                            data-wow-delay=".2s"><?php echo rr_kses( $settings['rr_about_sub_title'] ); ?>
                            <svg width="52" height="10" viewBox="0 0 52 10" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <g clip-path="url(#clip0_3795_96)">
                                    <path
                                        d="M47.2095 2.14437C46.4096 2.36766 45.5874 2.50135 44.758 2.54299L38.0745 3.26714C36.5625 3.43986 35.0713 3.76256 33.6232 4.23048C32.834 4.49614 32.0748 4.84349 31.3577 5.2669C30.5815 5.78994 29.7739 6.26475 28.9394 6.68864C28.4366 6.92402 27.8868 7.04215 27.3317 7.03411C26.7204 6.99856 26.1425 6.7438 25.704 6.3166C24.8602 5.44628 24.6277 4.38993 24.0763 3.71228C23.8482 3.37951 23.505 3.14288 23.1129 3.04791C22.6926 2.95474 22.2543 2.98472 21.8506 3.13427C20.9442 3.46398 20.1839 4.10423 19.7047 4.94135C19.1267 5.79839 18.675 6.775 18.0172 7.69183C17.3771 8.67698 16.4285 9.42226 15.3199 9.81116C14.738 9.97733 14.1213 9.97733 13.5394 9.81116C12.9881 9.64765 12.4799 9.36403 12.0512 8.9807C11.2848 8.27735 10.6875 7.40973 10.3039 6.44282C9.91861 5.55257 9.63957 4.68889 9.25423 3.93151C8.81236 2.89622 8.01001 2.05634 6.99598 1.56765C5.98195 1.07897 4.82509 0.974642 3.74 1.27404C3.16364 1.41933 2.62491 1.6859 2.15977 2.05594C1.69463 2.42599 1.3138 2.89102 1.04267 3.41996C0.609026 4.23627 0.40251 5.15404 0.444721 6.07742C0.461366 6.66905 0.587529 7.25247 0.816785 7.79813C0.969589 8.18346 1.07589 8.37613 1.04267 8.40271C1.00945 8.42928 0.849998 8.26318 0.624113 7.89778C0.297997 7.3528 0.0960956 6.74258 0.0328167 6.11063C-0.094422 5.09968 0.0716196 4.07346 0.511162 3.1542C0.798973 2.52884 1.21785 1.97266 1.73939 1.52332C2.26094 1.07399 2.87299 0.742013 3.53404 0.549886C4.3414 0.314234 5.19125 0.262331 6.02128 0.397987C6.85131 0.533642 7.64045 0.85342 8.33077 1.33384C9.08192 1.89515 9.6841 2.63192 10.0847 3.47975C10.5165 4.31021 10.8221 5.18716 11.2008 6.01762C11.535 6.84506 12.053 7.58567 12.7156 8.18347C13.0179 8.47409 13.3907 8.68086 13.7973 8.78339C14.204 8.88592 14.6303 8.88064 15.0342 8.7681C15.9058 8.44143 16.6489 7.84273 17.1536 7.06068C17.7316 6.2568 18.1833 5.28018 18.8145 4.33678C19.1355 3.84764 19.5172 3.40117 19.9505 3.00804C20.4071 2.61118 20.9377 2.30862 21.5118 2.11779C22.1043 1.91517 22.7412 1.88068 23.3521 2.01814C23.9719 2.17131 24.5177 2.53834 24.8934 3.05455C25.5977 3.99795 25.8368 5.04765 26.4082 5.5725C26.6675 5.83263 27.0118 5.99065 27.3782 6.01762C27.7818 6.02071 28.1811 5.9345 28.5475 5.76517C29.3497 5.36762 30.1284 4.92396 30.8794 4.43644C31.657 3.99071 32.4814 3.632 33.3375 3.36681C34.8527 2.91365 36.4116 2.62192 37.9881 2.49649C40.8449 2.25731 43.1369 2.18423 44.7314 2.1045C45.5564 2.02614 46.3875 2.03952 47.2095 2.14437Z"
                                        fill="#034833" />
                                    <path
                                        d="M45.4762 6.2697C45.4231 6.13018 46.1406 5.7382 47.2235 5.08712C47.7683 4.76158 48.4127 4.36296 49.1036 3.89126C49.4491 3.65873 49.768 3.39963 50.1666 3.13388C50.3373 3.0178 50.4954 2.88421 50.6383 2.73527C50.7579 2.61795 50.8527 2.47789 50.9173 2.32336C50.9506 2.19713 50.9173 2.20377 50.9173 2.15726C50.821 2.06916 50.7009 2.01139 50.5719 1.99117L49.283 1.64571C48.4592 1.41982 47.7218 1.20058 47.1039 0.981341C45.8682 0.582721 45.1108 0.263819 45.1573 0.124302C45.2038 -0.0152149 46.001 0.0379361 47.2833 0.250534C47.9476 0.356832 48.6784 0.502993 49.5155 0.675728L50.8443 0.968051C51.184 1.02987 51.4955 1.19726 51.7345 1.4464C51.8826 1.61431 51.9774 1.82242 52.0069 2.04432C52.0341 2.24825 52.0113 2.45574 51.9405 2.6489C51.8291 2.94985 51.6521 3.2222 51.4223 3.44614C51.235 3.63879 51.0254 3.80831 50.7978 3.95105C50.4124 4.23009 50.0205 4.47591 49.6484 4.70179C48.9845 5.09883 48.2916 5.44528 47.5756 5.7382C46.3399 6.25641 45.5294 6.40257 45.4762 6.2697Z"
                                        fill="#034833" />
                                </g>
                                <defs>
                                    <clipPath id="clip0_3795_96">
                                        <rect width="52" height="9.86585" fill="white"
                                            transform="translate(0 0.0664062)" />
                                    </clipPath>
                                </defs>
                            </svg>
                        </h6>
                        <?php endif; ?>
                        <?php if ( !empty($settings['rr_about_title' ]) ) :
                                printf( '<%1$s %2$s>%3$s</%1$s>',
                                tag_escape( $settings['rr_about_title_tag'] ),
                                $this->get_render_attribute_string( 'title_args' ),
                                rr_kses( $settings['rr_about_title' ] )
                                );  
                            endif; ?>
                    </div>
                </div>
                <?php endif; ?>
                <?php if ( !empty($settings['rr_about_list_switch']) ) : ?>
                <?php foreach($settings['rr_about_list_main_list'] as $key => $item) : ?>
                <div class="choose-us2__list wow fadeInLeft animated mb-15" data-wow-delay=".4s">
                    <div class="choose-us2__list-icon">
                        <?php if($item['rr_box_icon_type_list'] == 'icon') : ?>
                        <?php if (!empty($item['rr_box_icon_list']) || !empty($item['rr_box_selected_icon_list']['value'])) : ?>
                        <span class="rr-el-rep-icon">
                            <?php rr_render_icon($item, 'rr_box_icon_list', 'rr_box_selected_icon_list'); ?>
                        </span>
                        <?php endif; ?>
                        <?php elseif( $item['rr_box_icon_type_list'] == 'image' ) : ?>
                        <?php if (!empty($item['rr_box_icon_image_list']['url'])): ?>
                        <span>
                            <img src="<?php echo $item['rr_box_icon_image_list']['url']; ?>"
                                alt="<?php echo get_post_meta(attachment_url_to_postid($item['rr_box_icon_image_list']['url']), '_wp_attachment_image_alt', true); ?>">
                        </span>
                        <?php endif; ?>
                        <?php else : ?>
                        <?php if (!empty($item['rr_box_icon_svg_list'])): ?>
                        <div class="contact-inner-img">
                            <?php echo $item['rr_box_icon_svg_list']; ?>
                        </div>
                        <?php endif; ?>
                        <?php endif; ?>
                    </div>
                    <div class="choose-us2__list-text">
                        <?php if (!empty($item['rr_about_title_list'])): ?>
                        <h4><?php echo rr_kses($item['rr_about_title_list']);?></h4>
                        <?php endif; ?>
                        <?php if (!empty($item['rr_about_discription_list'])): ?>
                        <p><?php echo rr_kses($item['rr_about_discription_list']);?></p>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endforeach; ?>
                <?php endif; ?>
                <div class="choose-us__button choose-us__button-2 mt-35">
                    <?php if (!empty($settings['rr_about_btn_text'])): ?>
                    <div class="choose-us__button-btn wow fadeInLeft animated" data-wow-delay=".6s">
                        <a <?php echo $this->get_render_attribute_string( 'rr-button-arg' ); ?>><?php echo rr_kses($settings['rr_about_btn_text']); ?>
                            <i class="fa-solid fa-arrow-right"></i></a>
                    </div>
                    <?php endif; ?>
                    <?php if (!empty($settings['rr_about_call_switch'])): ?>
                    <div class="choose-us__button-text wow fadeInLeft animated" data-wow-delay=".7s">
                        <div class="choose-us__button-text-icon">
                            <i class="fa-solid fa-phone"></i>
                        </div>
                        <div class="choose-us__button-text-number">
                            <h6 class="rr-el-number-label rr-el-number">
                                <?php echo esc_attr__( 'Need help?', 'rr-core' )?></h6>
                            <a
                                href="tel:<?php echo rr_kses($settings['rr_about_call_number_url']['url']);?>"><?php echo rr_kses($settings['rr_about_call_number']);?></a>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</section>


<?php elseif ( $settings['rr_design_style']  == 'layout-3' ): 

if ( !empty($settings['rr_image']['url']) ) {
    $rr_image = !empty($settings['rr_image']['id']) ? wp_get_attachment_image_url( $settings['rr_image']['id'], $settings['rr_image_size_size']) : $settings['rr_image']['url'];
    $rr_image_alt = get_post_meta($settings["rr_image"]["id"], "_wp_attachment_image_alt", true);
}
if ( !empty($settings['rr_image_2']['url']) ) {
    $rr_image_2 = !empty($settings['rr_image_2']['id']) ? wp_get_attachment_image_url( $settings['rr_image_2']['id'], $settings['rr_image_size_size']) : $settings['rr_image_2']['url'];
    $rr_image_alt_2 = get_post_meta($settings["rr_image_2"]["id"], "_wp_attachment_image_alt", true);
}
if ( !empty($settings['rr_image_3']['url']) ) {
    $rr_image_3 = !empty($settings['rr_image_3']['id']) ? wp_get_attachment_image_url( $settings['rr_image_3']['id'], $settings['rr_image_size_size']) : $settings['rr_image_3']['url'];
    $rr_image_alt_3 = get_post_meta($settings["rr_image_3"]["id"], "_wp_attachment_image_alt", true);
}
// Link
if ('2' == $settings['rr_about_btn_link_type']) {
    $this->add_render_attribute('rr-button-arg', 'href', get_permalink($settings['rr_about_btn_page_link']));
    $this->add_render_attribute('rr-button-arg', 'target', '_self');
    $this->add_render_attribute('rr-button-arg', 'rel', 'nofollow');
    $this->add_render_attribute('rr-button-arg', 'class', 'rr-btn rr-el-btn');
} else {
    if ( ! empty( $settings['rr_about_btn_link']['url'] ) ) {
        $this->add_link_attributes( 'rr-button-arg', $settings['rr_about_btn_link'] );
        $this->add_render_attribute('rr-button-arg', 'class', 'rr-btn rr-el-btn');
    }
}
$this->add_render_attribute('title_args', 'class', 'section__title-wrapper-title wow fadeInLeft animated rr-el-title ');
?>
<section class="about-us-2 section-space rr-el-section">
    <div class="container">
        <div class="row align-items-center padding-b">
            <div class="col-xl-6">
                <div class="about-us-2__wrapper wow fadeInLeft animated" data-wow-delay=".3s">
                    <div class="about-us-2__wrapper-media overflow-hidden d-flex">
                        <div class="about-us-2__wrapper-media-image-1">
                            <?php if(!empty($rr_image)) : ?>
                            <img src="<?php echo esc_url($rr_image); ?>" alt="<?php echo esc_attr($rr_image_alt); ?>">
                            <?php endif; ?>
                        </div>
                        <div class="about-us-2__wrapper-media-image-2">
                            <?php if(!empty($rr_image_3)) : ?>
                            <img src="<?php echo esc_url($rr_image_3); ?>"
                                alt="<?php echo esc_attr($rr_image_alt_3); ?>">
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="about-us-2__wrapper-media d-flex">
                        <?php if ( !empty($settings['rr_about_experience_switch']) ) : ?>
                        <div class="about-us-2__wrapper-media__counter rr-el-experience-box">
                            <h3 class="about-us-2__wrapper-media__counter-title rr-rp-title-experience"><span
                                    class="odometer"
                                    data-count="<?php echo rr_kses( $settings['rr_extra_about_experience']);?>">0</span>+
                            </h3>
                            <?php if ( !empty($settings['rr_abouot_experience']) ) : ?>
                            <p class="rr-rp-experience"><?php echo rr_kses( $settings['rr_abouot_experience']);?></p>
                            <?php endif; ?>
                        </div>
                        <?php endif; ?>
                        <div class="about-us-2__wrapper-media-image-3">
                            <?php if(!empty($rr_image_2)) : ?>
                            <img src="<?php echo esc_url($rr_image_2); ?>"
                                alt="<?php echo esc_attr($rr_image_alt_2); ?>">
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php if ( !empty($settings['rr_shape_switcher']) ) : ?>
                    <div class="about-us-2__shap">
                        <img src="<?php echo get_template_directory_uri(  ); ?>/assets/imgs/about/dotted-img.svg"
                            alt="">
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-xl-6">
                <div class="about__content ml-30">

                    <?php if ( !empty($settings['rr_about_section_title_show']) ) : ?>
                    <div class="section__title-wrapper mb-20">
                        <?php if ( !empty($settings['rr_about_sub_title']) ) : ?>
                        <h6 class="section__title-wrapper-black-subtitle mb-10 wow fadeInLeft animated rr-el-sub-title"
                            data-wow-delay=".4s">
                            <?php echo rr_kses( $settings['rr_about_sub_title'] ); ?>
                            <svg width="14" height="12" viewBox="0 0 14 12" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <g clip-path="url(#clip0_3945_56)">
                                    <path d="M4.9248 10.3748L6.49525 9.68052L5.62485 9.07031L4.9248 10.3748Z"
                                        fill="#83CD20" />
                                    <path d="M4.9248 10.3743L4.99976 8L13.9078 0L5.66407 9.1113L4.9248 10.3743Z"
                                        fill="#83CD20" />
                                    <path d="M5 8L13.908 0L0 6.22704L5 8Z" fill="#83CD20" />
                                    <path d="M5.66406 9.1113L9.95686 12L13.9078 0L5.66406 9.1113Z" fill="#034833" />
                                </g>
                                <defs>
                                    <clipPath id="clip0_3945_56">
                                        <rect width="13.908" height="12" fill="white" />
                                    </clipPath>
                                </defs>
                            </svg>
                        </h6>
                        <?php endif; ?>
                        <?php if ( !empty($settings['rr_about_title' ]) ) :
                                printf( '<%1$s %2$s>%3$s</%1$s>',
                                tag_escape( $settings['rr_about_title_tag'] ),
                                $this->get_render_attribute_string( 'title_args' ),
                                rr_kses( $settings['rr_about_title' ] )
                                );  
                            endif; ?>
                    </div>
                    <?php if ( !empty($settings['rr_about_description']) ) : ?>
                    <p class=" wow fadeInLeft animated rr-el-desc" data-wow-delay=".8s">
                        <?php echo rr_kses( $settings['rr_about_description'] ); ?></p>
                    <?php endif; ?>
                    <?php endif; ?>
                    <?php if ( !empty($settings['rr_about_list_switch']) ) : ?>
                    <div class="about__box mt-20 d-flex">
                        <?php foreach($settings['rr_about_list_main_list'] as $key => $item) : ?>
                        <div class="about__box-item wow fadeInLeft animated" data-wow-delay=".7s">
                            <h4 class="about__box-item-title rr-rp-title">
                                <?php if($item['rr_box_icon_type_list'] == 'icon') : ?>
                                <?php if (!empty($item['rr_box_icon_list']) || !empty($item['rr_box_selected_icon_list']['value'])) : ?>
                                <span class="rr-el-rep-icon">
                                    <?php rr_render_icon($item, 'rr_box_icon_list', 'rr_box_selected_icon_list'); ?>
                                </span>
                                <?php endif; ?>
                                <?php elseif( $item['rr_box_icon_type_list'] == 'image' ) : ?>
                                <?php if (!empty($item['rr_box_icon_image_list']['url'])): ?>
                                <span>
                                    <img src="<?php echo $item['rr_box_icon_image_list']['url']; ?>"
                                        alt="<?php echo get_post_meta(attachment_url_to_postid($item['rr_box_icon_image_list']['url']), '_wp_attachment_image_alt', true); ?>">
                                </span>
                                <?php endif; ?>
                                <?php else : ?>
                                <?php if (!empty($item['rr_box_icon_svg_list'])): ?>
                                <span>
                                    <?php echo $item['rr_box_icon_svg_list']; ?>
                                </span>
                                <?php endif; ?>
                                <?php endif; ?>
                                <?php echo rr_kses($item['rr_about_title_list']);?>
                            </h4>
                            <?php if (!empty($item['rr_about_discription_list'])): ?>
                            <p class="rr-rp-desc"><?php echo rr_kses($item['rr_about_discription_list']);?></p>
                            <?php endif; ?>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    <?php endif; ?>
                    <?php if (!empty($settings['rr_about_btn_text'])): ?>
                    <div class="about__btn mt-40 wow fadeInLeft animated" data-wow-delay=".8s">
                        <a <?php echo $this->get_render_attribute_string( 'rr-button-arg' ); ?>
                            data-wow-delay=".6s"><?php echo rr_kses($settings['rr_about_btn_text']); ?> <i
                                class="fa-solid fa-arrow-right"></i></a>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</section>

<?php elseif ( $settings['rr_design_style']  == 'layout-4' ): 

if ( !empty($settings['rr_image']['url']) ) {
    $rr_image = !empty($settings['rr_image']['id']) ? wp_get_attachment_image_url( $settings['rr_image']['id'], $settings['rr_image_size_size']) : $settings['rr_image']['url'];
    $rr_image_alt = get_post_meta($settings["rr_image"]["id"], "_wp_attachment_image_alt", true);
}
if ( !empty($settings['rr_image_2']['url']) ) {
    $rr_image_2 = !empty($settings['rr_image_2']['id']) ? wp_get_attachment_image_url( $settings['rr_image_2']['id'], $settings['rr_image_size_size']) : $settings['rr_image_2']['url'];
    $rr_image_alt_2 = get_post_meta($settings["rr_image_2"]["id"], "_wp_attachment_image_alt", true);
}

// Link
if ('2' == $settings['rr_about_btn_link_type']) {
    $this->add_render_attribute('rr-button-arg', 'href', get_permalink($settings['rr_about_btn_page_link']));
    $this->add_render_attribute('rr-button-arg', 'target', '_self');
    $this->add_render_attribute('rr-button-arg', 'rel', 'nofollow');
    $this->add_render_attribute('rr-button-arg', 'class', 'rr-btn rr-el-btn');
} else {
    if ( ! empty( $settings['rr_about_btn_link']['url'] ) ) {
        $this->add_link_attributes( 'rr-button-arg', $settings['rr_about_btn_link'] );
        $this->add_render_attribute('rr-button-arg', 'class', 'rr-btn rr-el-btn');
    }
}
$this->add_render_attribute('title_args', 'class', 'section__title-wrapper-title wow fadeInLeft animated rr-el-title ');
?>
<section class="about-us-2 about-4 section-space">
    <div class="container">
        <div class="row">
            <div class="col-lg-6">
                <div class="about-us-2__wrapper about-4__wrapper wow fadeInLeft animated" data-wow-delay=".3s">
                    <div class="about-us-2__wrapper-media about-4__wrapper-media overflow-hidden d-flex">
                        <div class="img-wrap">
                            <div class="about-us-2__wrapper-media-image-1">
                                <?php if(!empty($rr_image_2)) : ?>
                                <img src="<?php echo esc_url($rr_image_2); ?>"
                                    alt="<?php echo esc_attr($rr_image_alt_2); ?>">
                                <?php endif; ?>
                            </div>
                        </div>
                        <?php if ( !empty($settings['rr_shape_switcher']) ) : ?>
                        <div class="about-us-2__wrapper-media-image-2">
                            <img class="leftRight"
                                src="<?php echo get_template_directory_uri(  )?>/assets/imgs/home-4/about-4-plane-img.png"
                                alt="image not found">
                        </div>
                        <?php endif; ?>
                    </div>
                    <div class="about-us-2__wrapper-media about-4__wrapper-media d-flex">
                        <?php if ( !empty($settings['rr_about_experience_switch']) ) : ?>
                        <div class="about-us-2__wrapper-media__counter rr-el-experience-box">
                            <h3 class="about-us-2__wrapper-media__counter-title rr-rp-title-experience"><span
                                    class="odometer"
                                    data-count="<?php echo rr_kses( $settings['rr_extra_about_experience']);?>">0</span>+
                            </h3>
                            <?php if ( !empty($settings['rr_abouot_experience']) ) : ?>
                            <p class="rr-rp-experience"><?php echo rr_kses( $settings['rr_abouot_experience']);?></p>
                            <?php endif; ?>
                        </div>
                        <?php endif; ?>
                        <div class="about-us-2__wrapper-media-image-3 img-wrap">
                            <?php if(!empty($rr_image)) : ?>
                            <img src="<?php echo esc_url($rr_image); ?>" alt="<?php echo esc_attr($rr_image_alt); ?>">
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="about__content about-4__content">
                    <?php if ( !empty($settings['rr_about_section_title_show']) ) : ?>
                    <div class="section__title-wrapper mb-20">
                        <?php if ( !empty($settings['rr_about_sub_title']) ) : ?>
                        <h6 class="section__title-wrapper-black-subtitle mb-10 wow fadeInLeft animated rr-el-sub-title "
                            data-wow-delay=".4s"> <?php echo rr_kses( $settings['rr_about_sub_title'] ); ?> </h6>
                        <?php endif; ?>
                        <?php if ( !empty($settings['rr_about_title' ]) ) :
                        printf( '<%1$s %2$s>%3$s</%1$s>',
                        tag_escape( $settings['rr_about_title_tag'] ),
                        $this->get_render_attribute_string( 'title_args' ),
                        rr_kses( $settings['rr_about_title' ] )
                        );  
                    endif; ?>
                    </div>
                    <?php if ( !empty($settings['rr_about_description']) ) : ?>
                    <p class=" wow fadeInLeft animated rr-el-desc" data-wow-delay=".8s">
                        <?php echo rr_kses( $settings['rr_about_description'] ); ?></p>
                    <?php endif; ?>
                    <?php endif; ?>
                    <?php if ( !empty($settings['rr_about_list_switch']) ) : ?>
                    <div class="about__box about-4__box mt-20">
                        <?php foreach($settings['rr_about_list_main_list'] as $key => $item) : ?>
                        <div class="about__box-item about-4__box-item mb-15 wow fadeInLeft animated"
                            data-wow-delay=".6s">
                            <div class="icon">
                                <?php if($item['rr_box_icon_type_list'] == 'icon') : ?>
                                <?php if (!empty($item['rr_box_icon_list']) || !empty($item['rr_box_selected_icon_list']['value'])) : ?>
                                <span class="rr-el-rep-icon">
                                    <?php rr_render_icon($item, 'rr_box_icon_list', 'rr_box_selected_icon_list'); ?>
                                </span>
                                <?php endif; ?>
                                <?php elseif( $item['rr_box_icon_type_list'] == 'image' ) : ?>
                                <?php if (!empty($item['rr_box_icon_image_list']['url'])): ?>
                                <span>
                                    <img src="<?php echo $item['rr_box_icon_image_list']['url']; ?>"
                                        alt="<?php echo get_post_meta(attachment_url_to_postid($item['rr_box_icon_image_list']['url']), '_wp_attachment_image_alt', true); ?>">
                                </span>
                                <?php endif; ?>
                                <?php else : ?>
                                <?php if (!empty($item['rr_box_icon_svg_list'])): ?>
                                <div class="contact-inner-img">
                                    <?php echo $item['rr_box_icon_svg_list']; ?>
                                </div>
                                <?php endif; ?>
                                <?php endif; ?>
                            </div>
                            <div class="text">
                                <h4 class="about__box-item-title rr-rp-title">
                                    <?php echo rr_kses($item['rr_about_title_list']);?>
                                </h4>
                                <?php if (!empty($item['rr_about_discription_list'])): ?>
                                <p class="rr-rp-desc"><?php echo rr_kses($item['rr_about_discription_list']);?></p>
                                <?php endif; ?>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    <?php endif; ?>
                    <?php if (!empty($settings['rr_about_btn_text'])): ?>
                    <div class="about__btn about-4__btn wow fadeInLeft animated" data-wow-delay=".8s">
                        <a <?php echo $this->get_render_attribute_string( 'rr-button-arg' ); ?>><?php echo rr_kses($settings['rr_about_btn_text']); ?><i
                                class="fa-solid fa-arrow-right"></i></a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php elseif ( $settings['rr_design_style']  == 'layout-5' ): 

if ( !empty($settings['rr_image']['url']) ) {
    $rr_image = !empty($settings['rr_image']['id']) ? wp_get_attachment_image_url( $settings['rr_image']['id'], $settings['rr_image_size_size']) : $settings['rr_image']['url'];
    $rr_image_alt = get_post_meta($settings["rr_image"]["id"], "_wp_attachment_image_alt", true);
}
if ( !empty($settings['rr_image_2']['url']) ) {
    $rr_image_2 = !empty($settings['rr_image_2']['id']) ? wp_get_attachment_image_url( $settings['rr_image_2']['id'], $settings['rr_image_size_size']) : $settings['rr_image_2']['url'];
    $rr_image_alt_2 = get_post_meta($settings["rr_image_2"]["id"], "_wp_attachment_image_alt", true);
}
if ( !empty($settings['rr_image_circle']['url']) ) {
    $rr_image_circle = !empty($settings['rr_image_circle']['id']) ? wp_get_attachment_image_url( $settings['rr_image_circle']['id'], $settings['rr_image_size_size']) : $settings['rr_image_circle']['url'];
    $rr_image_alt_2 = get_post_meta($settings["rr_image_circle"]["id"], "_wp_attachment_image_alt", true);
}

// Link
if ('2' == $settings['rr_about_btn_link_type']) {
    $this->add_render_attribute('rr-button-arg', 'href', get_permalink($settings['rr_about_btn_page_link']));
    $this->add_render_attribute('rr-button-arg', 'target', '_self');
    $this->add_render_attribute('rr-button-arg', 'rel', 'nofollow');
    $this->add_render_attribute('rr-button-arg', 'class', 'rr-btn mt-50 rr-el-btn');
} else {
    if ( ! empty( $settings['rr_about_btn_link']['url'] ) ) {
        $this->add_link_attributes( 'rr-button-arg', $settings['rr_about_btn_link'] );
        $this->add_render_attribute('rr-button-arg', 'class', 'rr-btn mt-50 rr-el-btn');
    }
}
$this->add_render_attribute('title_args', 'class', 'service-5__title wow fadeInLeft animated rr-el-title ');
?>
<section class="about-5__area teamdetail service-5 p-relative section-space rr-el-section">
    <?php if ( !empty($settings['rr_shape_switcher']) ) : ?>
    <div class="about-5__shape">
        <img src="<?php echo get_template_directory_uri(  ); ?>/assets/imgs/home-5/about-bg-shape.png"
            alt="img not found">
    </div>
    <?php endif; ?>
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-6">
                <div class="row align-items-center about-5__wrap">
                    <div class="col-sm-6">
                        <div class="about-5__thumb">
                            <?php if(!empty($rr_image)) : ?>
                            <img src="<?php echo esc_url($rr_image); ?>" alt="<?php echo esc_attr($rr_image_alt); ?>">
                            <?php endif; ?>
                            <div class="about-5__thumb-border"></div>
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="about-5__media">
                            <?php if ( !empty($settings['rr_about_circle_switch']) ) : ?>
                            <div class="about-5__media-circle spin">
                                <?php if(!empty($rr_image_circle)) : ?>
                                <img src="<?php echo esc_url($rr_image_circle); ?>"
                                    alt="<?php echo esc_attr($rr_image_alt_2); ?>">
                                <?php endif; ?>
                            </div>
                            <?php endif; ?>
                            <div class="about-5__media-bottom-img">
                                <?php if(!empty($rr_image_2)) : ?>
                                <img src="<?php echo esc_url($rr_image_2); ?>"
                                    alt="<?php echo esc_attr($rr_image_alt_2); ?>">
                                <?php endif; ?>
                                <div class="about-5__media-bottom-img-border"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-6">
                <?php if ( !empty($settings['rr_about_section_title_show']) ) : ?>
                <div class="service-5__title-wrapper about-5__title-wrapper">
                    <?php if ( !empty($settings['rr_about_sub_title']) ) : ?>
                    <h6 class="service-5__subtitle wow fadeInLeft animated rr-el-sub-title" data-wow-delay=".2s">
                        <?php echo rr_kses( $settings['rr_about_sub_title'] ); ?>
                    </h6>
                    <?php endif; ?>
                    <?php if ( !empty($settings['rr_about_title' ]) ) :
                            printf( '<%1$s %2$s>%3$s</%1$s>',
                            tag_escape( $settings['rr_about_title_tag'] ),
                            $this->get_render_attribute_string( 'title_args' ),
                            rr_kses( $settings['rr_about_title' ] )
                            );  
                        endif; ?>
                    <?php if ( !empty($settings['rr_about_description']) ) : ?>
                    <p class="service-5__dec rr-el-desc" data-wow-delay=".8s">
                        <?php echo rr_kses( $settings['rr_about_description'] ); ?></p>
                    <?php endif; ?>

                </div>
                <?php endif; ?>
                <?php if ( !empty($settings['rr_about_skill_switch']) ) : ?>
                <div class="teamdetail__progress about-5__wrap pt-30">
                    <?php foreach ( $settings['rr_skill_list'] as $key => $item ) : ?>
                    <div class="skills-item">
                        <h4 class="title rr-rp-title"><?php echo rr_kses($item['rr_skill_box_title']); ?></h4>
                        <div class="progress">
                            <div class="progress-bar wow slideInLeft" data-wow-delay="0ms" data-wow-duration="2000ms"
                                role="progressbar" style="width: <?php echo rr_kses($item['rr_skill_num']); ?>%;">
                                <span><?php echo rr_kses($item['rr_skill_num']); ?>%</span>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                    <?php if (!empty($settings['rr_about_btn_text'])): ?>
                    <a <?php echo $this->get_render_attribute_string( 'rr-button-arg' ); ?>><?php echo rr_kses($settings['rr_about_btn_text']); ?>
                        <i class="fa-solid fa-arrow-right"></i></a>
                    <?php endif; ?>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>
<?php else:

    if ( !empty($settings['rr_image']['url']) ) {
        $rr_image = !empty($settings['rr_image']['id']) ? wp_get_attachment_image_url( $settings['rr_image']['id'], $settings['rr_image_size_size']) : $settings['rr_image']['url'];
        $rr_image_alt = get_post_meta($settings["rr_image"]["id"], "_wp_attachment_image_alt", true);
    }
    if ( !empty($settings['rr_image_2']['url']) ) {
        $rr_image_2 = !empty($settings['rr_image_2']['id']) ? wp_get_attachment_image_url( $settings['rr_image_2']['id'], $settings['rr_image_size_size']) : $settings['rr_image_2']['url'];
        $rr_image_alt_2 = get_post_meta($settings["rr_image_2"]["id"], "_wp_attachment_image_alt", true);
    }
    if ( !empty($settings['rr_image_3']['url']) ) {
        $rr_image_3 = !empty($settings['rr_image_3']['id']) ? wp_get_attachment_image_url( $settings['rr_image_3']['id'], $settings['rr_image_size_size']) : $settings['rr_image_3']['url'];
        $rr_image_alt_3 = get_post_meta($settings["rr_image_3"]["id"], "_wp_attachment_image_alt", true);
    }

    // Link
    if ('2' == $settings['rr_about_btn_link_type']) {
        $this->add_render_attribute('rr-button-arg', 'href', get_permalink($settings['rr_about_btn_page_link']));
        $this->add_render_attribute('rr-button-arg', 'target', '_self');
        $this->add_render_attribute('rr-button-arg', 'rel', 'nofollow');
        $this->add_render_attribute('rr-button-arg', 'class', 'rr-el-btn');
    } else {
        if ( ! empty( $settings['rr_about_btn_link']['url'] ) ) {
            $this->add_link_attributes( 'rr-button-arg', $settings['rr_about_btn_link'] );
            $this->add_render_attribute('rr-button-arg', 'class', 'rr-el-btn');
        }
    }
    $this->add_render_attribute('title_args', 'class', 'section__title-wrapper-title wow fadeInLeft animated rr-el-title');
?>
<section class="section-space-top section-space-bottom-2 overflow-hidden gray-bg rr-el-section rr-el-section">
    <div class="choose-us__area">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-xl-6">
                    <div class="choose-us__media">
                        <div class="choose-us__media-thumb">
                            <?php if(!empty($rr_image_2)) : ?>
                            <div class="choose-us__media-thumb-img">
                                <div class="choose-us__media-thumb-img-green-border wow fadeInLeft animated"
                                    data-wow-delay=".3s"></div>
                                <div class="choose-us__media-thumb-img-img wow fadeInLeft animated"
                                    data-wow-delay=".4s">
                                    <img src="<?php echo esc_url($rr_image_2); ?>"
                                        alt="<?php echo esc_attr($rr_image_alt_2); ?>">
                                </div>
                            </div>
                            <?php endif; ?>
                            <?php if(!empty($rr_image_3)) : ?>
                            <div class="choose-us__media-thumb-circle spin">
                                <img src="<?php echo esc_url($rr_image_3); ?>"
                                    alt="<?php echo esc_attr($rr_image_alt_3); ?>">
                            </div>
                            <?php endif; ?>
                        </div>
                        <div class="choose-us__media-img">
                            <?php if ( !empty($settings['rr_about_experience_switch']) ) : ?>
                            <div class="choose-us__text rr-el-experience-box">
                                <h3 class="counter__item-title rr-rp-title-experience"><span class="odometer"
                                        data-count="<?php echo rr_kses( $settings['rr_extra_about_experience']);?>">0</span>
                                </h3>
                                <?php if ( !empty($settings['rr_abouot_experience']) ) : ?>
                                <p class="rr-rp-experience"><?php echo rr_kses( $settings['rr_abouot_experience']);?>
                                </p>
                                <?php endif; ?>
                            </div>
                            <?php endif; ?>
                            <div class="choose-us__media-img-pictute wow fadeInLeft animated" data-wow-delay=".6s">
                                <?php if(!empty($rr_image)) : ?>
                                <img src="<?php echo esc_url($rr_image); ?>"
                                    alt="<?php echo esc_attr($rr_image_alt); ?>">
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-6">
                    <div class="choose-us__content">
                        <?php if ( !empty($settings['rr_about_section_title_show']) ) : ?>
                        <div class="section__title-wrapper mb-20">
                            <?php if ( !empty($settings['rr_about_sub_title']) ) : ?>
                            <h6 class="section__title-wrapper-black-subtitle mb-10 wow fadeInLeft animated rr-el-sub-title"
                                data-wow-delay=".2s">
                                <svg width="20" height="21" viewBox="0 0 20 21" fill="none"
                                    xmlns="http://www.w3.org/2000/svg">
                                    <g clip-path="url(#clip0_3754_90)">
                                        <path
                                            d="M19.299 2.66986C19.2609 2.59008 19.1926 2.52868 19.1093 2.49911L12.195 0.0581985C12.0215 -0.00317634 11.831 0.0879901 11.7697 0.26149L10.199 4.70581H9.51204V3.57248C9.51202 3.41941 9.47686 3.26838 9.40926 3.13104C9.34166 2.9937 9.24343 2.87372 9.12214 2.78033C9.00085 2.68695 8.85974 2.62266 8.70968 2.59242C8.55962 2.56217 8.40462 2.56679 8.25663 2.6059L0.24744 4.7169V4.7229C0.176847 4.74064 0.114146 4.78133 0.0691834 4.83857C0.0242205 4.89581 -0.000457842 4.96636 -0.000976562 5.03915L-0.000976562 19.0391C-0.000976562 19.5914 0.446773 20.0391 0.999021 20.0391H10.3323C10.8846 20.0391 11.3323 19.5914 11.3323 19.0391V16.0145L14.0057 16.9582C14.1793 17.0194 14.3697 16.9285 14.431 16.7548L19.3133 2.92457C19.3278 2.88326 19.334 2.83949 19.3315 2.79578C19.329 2.75208 19.318 2.70928 19.2989 2.66986H19.299ZM8.42671 3.24873C8.47605 3.23573 8.52772 3.23421 8.57773 3.24429C8.62775 3.25436 8.6748 3.27577 8.71525 3.30686C8.75572 3.33802 8.78849 3.37806 8.81104 3.42389C8.83359 3.46972 8.84531 3.52012 8.8453 3.57119V4.70581H2.90268L8.42671 3.24873ZM10.6657 19.0391C10.6657 19.1275 10.6305 19.2123 10.568 19.2748C10.5055 19.3373 10.4207 19.3724 10.3323 19.3724H0.999021C0.910616 19.3724 0.825832 19.3373 0.76332 19.2748C0.700808 19.2123 0.665689 19.1275 0.665689 19.0391V5.37248H10.3323C10.4207 5.37248 10.5055 5.4076 10.568 5.47011C10.6305 5.53262 10.6657 5.61741 10.6657 5.70581V19.0391ZM13.4057 6.64152L13.8323 6.43923L14.0356 6.86452L12.416 11.4481C12.3867 11.5315 12.3916 11.6231 12.4297 11.7029L12.7767 12.4288L12.6694 12.7331L12.0083 12.0485C11.9725 12.0112 11.9284 11.9827 11.8796 11.9653C11.8309 11.9479 11.7787 11.9422 11.7273 11.9485L11.3323 11.9985V11.5518L11.6167 11.4158C11.6964 11.3776 11.7578 11.3095 11.7874 11.2262L12.4541 9.34089L13.4057 6.64152ZM14.0343 8.86643L14.7111 9.95384L14.5953 10.2815L13.7856 9.57251L14.0343 8.86643ZM11.3323 10.5121V9.5961L11.6603 9.58243L11.3323 10.5121ZM11.8991 8.90551L11.3323 8.9288V8.4851L12.1484 8.20043L11.8991 8.90551ZM13.9131 16.2185L11.3323 15.3075V12.6704L11.6447 12.6314L12.5657 13.5842C12.597 13.616 12.6343 13.6413 12.6755 13.6585C12.7168 13.6756 12.761 13.6843 12.8056 13.6841C12.8294 13.6842 12.8531 13.6817 12.8763 13.6765C12.9318 13.6644 12.9833 13.6383 13.0259 13.6008C13.0685 13.5632 13.1007 13.5154 13.1196 13.4618L13.453 12.5188C13.4824 12.4354 13.4775 12.3438 13.4392 12.2642L13.0907 11.5391L13.5467 10.2475L14.526 11.1059C14.5868 11.1592 14.6649 11.1885 14.7458 11.1885C14.7742 11.1885 14.8026 11.1848 14.8301 11.1775C14.8827 11.1637 14.9312 11.1372 14.9713 11.1004C15.0114 11.0636 15.0419 11.0175 15.0601 10.9662L15.3934 10.0232C15.41 9.97606 15.4159 9.92579 15.4104 9.87612C15.405 9.82644 15.3884 9.77863 15.362 9.73622L14.3187 8.06014L14.7093 6.95389C14.7239 6.91256 14.7302 6.86876 14.7279 6.82499C14.7255 6.78122 14.7146 6.73834 14.6957 6.69881L14.2891 5.84856C14.2702 5.80904 14.2437 5.77363 14.2112 5.74435C14.1786 5.71507 14.1406 5.69249 14.0993 5.67791C14.058 5.66332 14.0142 5.65701 13.9705 5.65934C13.9268 5.66167 13.8839 5.67259 13.8444 5.69148L12.9937 6.09823C12.9542 6.11709 12.9189 6.14354 12.8897 6.17607C12.8605 6.2086 12.8379 6.24657 12.8234 6.28781L12.4323 7.39543L11.3323 7.77914V5.70581C11.3319 5.53523 11.2878 5.36759 11.2041 5.21895C11.1204 5.07031 11 4.94564 10.8543 4.85685L11.3991 3.31211L11.5213 2.96557L12.2881 0.798905L18.5743 3.01782L13.9131 16.2185Z"
                                            fill="#034833" />
                                        <path
                                            d="M16.5429 5.12938L16.7648 4.50063L17.3364 4.7023L17.1145 5.33105L16.5429 5.12938ZM11.971 3.51526L12.193 2.88672L12.7644 3.08851L12.5424 3.71709L11.971 3.51526ZM15.3998 4.72588L15.6219 4.09713L16.1933 4.29897L15.9713 4.92755L15.3998 4.72588ZM13.1141 3.91892L13.3361 3.29034L13.9073 3.49218L13.6854 4.12076L13.1141 3.91892ZM14.2569 4.32209L14.479 3.69351L15.0504 3.89534L14.8284 4.52388L14.2569 4.32209ZM5.51204 6.707C3.67104 6.707 2.17871 8.19933 2.17871 10.0403C2.17871 11.8813 3.67104 13.3737 5.51204 13.3737C7.35303 13.3737 8.84536 11.8813 8.84536 10.0403C8.84341 8.20033 7.3522 6.70909 5.51204 6.707ZM7.91907 8.90066L7.46432 8.80075C7.26433 8.75662 7.06424 8.72166 6.86224 8.69137C6.832 8.48959 6.79548 8.2888 6.75274 8.08929L6.65262 7.63471C7.20754 7.89885 7.65471 8.34585 7.91907 8.90066ZM2.84533 10.0403C2.846 9.90408 2.85708 9.76804 2.87871 9.63341L3.70296 9.45C3.82942 9.422 3.95671 9.39875 4.08429 9.37675C4.05206 9.8186 4.05206 10.2622 4.08429 10.7041C3.95667 10.6821 3.82942 10.6587 3.70296 10.6307L2.87871 10.4474C2.85711 10.3128 2.84597 10.1767 2.84538 10.0403H2.84533ZM4.76075 9.28937C5.26039 9.24478 5.76302 9.24478 6.26266 9.28937C6.30742 9.78901 6.30742 10.2916 6.26266 10.7913C5.76301 10.836 5.26036 10.836 4.76071 10.7913C4.71595 10.2916 4.71599 9.78901 4.76075 9.28937ZM6.93828 9.37675C7.06603 9.39875 7.19333 9.422 7.31962 9.45L8.14399 9.63341C8.19022 9.90278 8.19022 10.178 8.14399 10.4474L7.31962 10.6307C7.19337 10.6587 7.06603 10.6821 6.93828 10.7044C6.97067 10.2624 6.97067 9.81871 6.93828 9.37675ZM5.91874 7.40704L6.10204 8.23175C6.13004 8.35804 6.15362 8.48533 6.17579 8.61308C5.73377 8.58069 5.28997 8.58069 4.84796 8.61308C4.87008 8.48533 4.89337 8.35804 4.92171 8.23175L5.10495 7.40704C5.37429 7.36131 5.64941 7.36131 5.91874 7.40704ZM4.37208 7.63229L4.27196 8.08704C4.228 8.28704 4.193 8.48712 4.16275 8.68912C3.96097 8.71926 3.76018 8.75566 3.56067 8.79829L3.10592 8.89841C3.37048 8.34408 3.81748 7.89749 4.37204 7.63342L4.37208 7.63229ZM3.10525 11.179L3.56 11.2791C3.76 11.323 3.95987 11.358 4.16208 11.3883C4.19222 11.5901 4.22862 11.7909 4.27125 11.9904L4.37137 12.4449C3.81652 12.1811 3.36926 11.7344 3.10458 11.18L3.10525 11.179ZM5.10525 12.6717L4.92196 11.8469C4.89362 11.721 4.87037 11.5934 4.84821 11.466C5.06895 11.4821 5.29062 11.493 5.51229 11.493C5.73395 11.493 5.95499 11.4821 6.17604 11.466C6.15391 11.5934 6.13029 11.721 6.10229 11.8469L5.91904 12.6717C5.6497 12.7174 5.37458 12.7174 5.10525 12.6717ZM6.65191 12.4464L6.75203 11.9917C6.79633 11.7917 6.83099 11.5917 6.86162 11.3896C7.06336 11.3594 7.26413 11.323 7.46362 11.2804L7.9182 11.1803C7.65407 11.7356 7.20681 12.183 6.65162 12.4474L6.65191 12.4464ZM2.84538 16.0403H8.1787V16.707H2.84538V16.0403ZM3.51204 17.3736H7.51203V18.0403H3.51204V17.3736ZM5.1787 14.707H5.84537V15.3737H5.1787V14.707ZM3.84537 14.707H4.51204V15.3737H3.84537V14.707ZM6.51203 14.707H7.1787V15.3737H6.51203V14.707Z"
                                            fill="#034833" />
                                    </g>
                                    <defs>
                                        <clipPath id="clip0_3754_90">
                                            <rect width="20" height="20" fill="white"
                                                transform="translate(-0.000976562 0.0390625)" />
                                        </clipPath>
                                    </defs>
                                </svg>
                                <?php echo rr_kses( $settings['rr_about_sub_title'] ); ?>
                            </h6>
                            <?php endif; ?>
                            <?php if ( !empty($settings['rr_about_title' ]) ) :
                                printf( '<%1$s %2$s>%3$s</%1$s>',
                                tag_escape( $settings['rr_about_title_tag'] ),
                                $this->get_render_attribute_string( 'title_args' ),
                                rr_kses( $settings['rr_about_title' ] )
                                );  
                            endif; ?>
                        </div>
                        <?php if ( !empty($settings['rr_about_description']) ) : ?>
                        <p class="choose-us__content-description wow fadeInLeft animated rr-el-desc"
                            data-wow-delay=".4s">
                            <?php echo rr_kses( $settings['rr_about_description'] ); ?></p>
                        <?php endif; ?>
                        <?php endif; ?>

                        <div class="choose-us__content-wrapper mt-35">
                            <?php if (!empty($settings['rr_about_extra_switch'])): ?>
                            <div class="choose-us__content-wrapper-box wow fadeInLeft animated" data-wow-delay=".5s">
                                <div class="choose-us__content-wrapper-box-title">
                                    <div class="choose-us__content-wrapper-box-title-icon rr-el-rep-icon">
                                        <?php if($settings['rr_box_icon_type'] == 'icon') : ?>
                                        <?php if (!empty($settings['rr_box_icon']) || !empty($settings['rr_box_selected_icon']['value'])) : ?>
                                        <span>
                                            <?php rr_render_icon($settings, 'rr_box_icon', 'rr_box_selected_icon'); ?>
                                        </span>
                                        <?php endif; ?>
                                        <?php elseif( $settings['rr_box_icon_type'] == 'image' ) : ?>
                                        <?php if (!empty($settings['rr_box_icon_image']['url'])): ?>
                                        <span>
                                            <img src="<?php echo $settings['rr_box_icon_image']['url']; ?>"
                                                alt="<?php echo get_post_meta(attachment_url_to_postid($settings['rr_box_icon_image']['url']), '_wp_attachment_image_alt', true); ?>">
                                        </span>
                                        <?php endif; ?>
                                        <?php else : ?>
                                        <?php if (!empty($settings['rr_box_icon_svg'])): ?>
                                        <div class="contact-inner-img">
                                            <?php echo $settings['rr_box_icon_svg']; ?>
                                        </div>
                                        <?php endif; ?>
                                        <?php endif; ?>
                                    </div>
                                    <h3 class="rr-rp-title"><?php echo rr_kses($settings['rr_about_title_main']); ?>
                                    </h3>
                                </div>
                                <div class="choose-us__content-wrapper-box-list">
                                    <ul>
                                        <?php foreach($settings['rr_about_list_main'] as $key => $item) : ?>
                                        <li>
                                            <?php if($item['rr_box_icon_type'] == 'icon') : ?>
                                            <?php if (!empty($item['rr_box_icon']) || !empty($item['rr_box_selected_icon']['value'])) : ?>
                                            <span class="rr-el-rep-icon">
                                                <?php rr_render_icon($item, 'rr_box_icon_list', 'rr_box_selected_icon_list'); ?>
                                            </span>
                                            <?php endif; ?>
                                            <?php elseif( $item['rr_box_icon_type'] == 'image' ) : ?>
                                            <?php if (!empty($item['rr_box_icon_image']['url'])): ?>
                                            <span>
                                                <img src="<?php echo $item['rr_box_icon_image']['url']; ?>"
                                                    alt="<?php echo get_post_meta(attachment_url_to_postid($item['rr_box_icon_image']['url']), '_wp_attachment_image_alt', true); ?>">
                                            </span>
                                            <?php endif; ?>
                                            <?php else : ?>
                                            <?php if (!empty($item['rr_box_icon_svg'])): ?>
                                            <div class="contact-inner-img contact-inner-icon-check">
                                                <?php echo $item['rr_box_icon_svg']; ?>
                                            </div>
                                            <?php endif; ?>
                                            <?php endif; ?>
                                            <span
                                                class="rr-rp-title-main"><?php echo rr_kses($item['rr_about_discription']);?></span>
                                        </li>
                                        <?php endforeach; ?>
                                    </ul>
                                </div>
                            </div>
                            <?php endif; ?>
                            <?php if (!empty($settings['rr_about_extra2_switch'])): ?>
                            <div class="choose-us__content-wrapper-box wow fadeInLeft animated" data-wow-delay=".6s">
                                <div class="choose-us__content-wrapper-box-title">
                                    <div class="choose-us__content-wrapper-box-title-icon rr-el-rep-icon">
                                        <?php if($settings['rr_box_icon_type_2'] == 'icon') : ?>
                                        <?php if (!empty($settings['rr_box_icon_2']) || !empty($settings['rr_box_selected_icon_2']['value'])) : ?>
                                        <span class="rr-el-rep-icon">
                                            <?php rr_render_icon($settings, 'rr_box_icon_2', 'rr_box_selected_icon_2'); ?>
                                        </span>
                                        <?php endif; ?>
                                        <?php elseif( $settings['rr_box_icon_type_2'] == 'image' ) : ?>
                                        <?php if (!empty($settings['rr_box_icon_image_2']['url'])): ?>
                                        <span>
                                            <img src="<?php echo $settings['rr_box_icon_image_2']['url']; ?>"
                                                alt="<?php echo get_post_meta(attachment_url_to_postid($settings['rr_box_icon_image_2']['url']), '_wp_attachment_image_alt', true); ?>">
                                        </span>
                                        <?php endif; ?>
                                        <?php else : ?>
                                        <?php if (!empty($settings['rr_box_icon_svg_2'])): ?>
                                        <div class="contact-inner-img ">
                                            <?php echo $settings['rr_box_icon_svg_2']; ?>
                                        </div>
                                        <?php endif; ?>
                                        <?php endif; ?>
                                    </div>
                                    <?php if (!empty($settings['rr_about_title_main_2'])): ?>
                                    <h3 class="rr-rp-title"><?php echo rr_kses($settings['rr_about_title_main_2']); ?>
                                    </h3>
                                    <?php endif; ?>
                                </div>
                                <div class="choose-us__content-wrapper-box-list">
                                    <ul>
                                        <?php foreach($settings['rr_about_list_main_2'] as $key => $item) : ?>
                                        <li>
                                            <?php if($item['rr_box_icon_type_2'] == 'icon') : ?>
                                            <?php if (!empty($item['rr_box_icon_2']) || !empty($item['rr_box_selected_icon_2']['value'])) : ?>
                                            <span class="rr-el-rep-icon">
                                                <?php rr_render_icon($item, 'rr_box_icon_2', 'rr_box_selected_icon_2'); ?>
                                            </span>
                                            <?php endif; ?>
                                            <?php elseif( $item['rr_box_icon_type_2'] == 'image' ) : ?>
                                            <?php if (!empty($item['rr_box_icon_image_2']['url'])): ?>
                                            <span>
                                                <img src="<?php echo $item['rr_box_icon_image_2']['url']; ?>"
                                                    alt="<?php echo get_post_meta(attachment_url_to_postid($item['rr_box_icon_image_2']['url']), '_wp_attachment_image_alt', true); ?>">
                                            </span>
                                            <?php endif; ?>
                                            <?php else : ?>
                                            <?php if (!empty($item['rr_box_icon_svg_2'])): ?>
                                            <div class="contact-inner-img contact-inner-icon-check">
                                                <?php echo $item['rr_box_icon_svg_2']; ?>
                                            </div>
                                            <?php endif; ?>
                                            <?php endif; ?>
                                            <span
                                                class="rr-rp-title-main"><?php echo rr_kses($item['rr_about_discription_2']);?></span>
                                        </li>
                                        <?php endforeach; ?>
                                    </ul>
                                </div>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="choose-us__button mt-40">
                        <?php if (!empty($settings['rr_about_btn_text'])): ?>
                        <div class="choose-us__button-btn wow fadeInLeft animated" data-wow-delay=".7s">
                            <a <?php echo $this->get_render_attribute_string( 'rr-button-arg' ); ?>
                                data-wow-delay=".6s"><?php echo rr_kses($settings['rr_about_btn_text']); ?> <i
                                    class="fa-solid fa-arrow-right"></i></a>
                        </div>
                        <?php endif; ?>
                        <?php if (!empty($settings['rr_about_call_switch'])): ?>
                        <div class="choose-us__button-text wow fadeInLeft animated" data-wow-delay=".8s">
                            <div class="choose-us__button-text-icon rr-el-coll-icon">
                                <i class="fa-solid fa-phone"></i>
                            </div>

                            <div class="choose-us__button-text-number">
                                <h6 class="rr-el-number-label"><?php echo esc_attr__( 'Need help?', 'rr-core' )?></h6>
                                <a class="rr-el-number"
                                    href="tel:<?php echo rr_kses($settings['rr_about_call_number_url']['url']);?>"><?php echo rr_kses($settings['rr_about_call_number']);?></a>
                            </div>

                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php endif; 
	}
}
$widgets_manager->register( new rr_About() );