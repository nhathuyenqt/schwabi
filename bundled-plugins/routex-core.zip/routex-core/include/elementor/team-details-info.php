<?php
namespace RRCore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Repeater;
use \Elementor\Utils;
use \Elementor\Control_Media;
use Elementor\Core\Utils\ImportExport\Url;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * RR Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class rr_Team_Details extends Widget_Base {

    use \RRCore\Widgets\RRCoreElementFunctions;

    /**
     * Retrieve the widget name.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name() {
        return 'rr-team-details';
    }

    /**
     * Retrieve the widget title.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title() {
        return __( 'RR Team Details', 'rr-core' );
    }

    /**
     * Retrieve the widget icon.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'rr-icon';
    }

    /**
     * Retrieve the list of categories the widget belongs to.
     *
     * Used to determine where to display the widget in the editor.
     *
     * Note that currently Elementor supports only one category.
     * When multiple categories passed, Elementor uses the first one.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return array Widget categories.
     */
    public function get_categories() {
        return [ 'rr-core' ];
    }

    /**
     * Retrieve the list of scripts the widget depended on.
     *
     * Used to set scripts dependencies required to run the widget.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return array Widget scripts dependencies.
     */
    public function get_script_depends() {
        return [ 'rr-core' ];
    }

    /**
     * Register the widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     *
     * @access protected
     */

     protected static function get_profile_names()
     {
         return [
             '500px' => esc_html__('500px', 'rr-core'),
             'apple' => esc_html__('Apple', 'rr-core'),
             'behance' => esc_html__('Behance', 'rr-core'),
             'bitbucket' => esc_html__('BitBucket', 'rr-core'),
             'codepen' => esc_html__('CodePen', 'rr-core'),
             'delicious' => esc_html__('Delicious', 'rr-core'),
             'deviantart' => esc_html__('DeviantArt', 'rr-core'),
             'digg' => esc_html__('Digg', 'rr-core'),
             'dribbble' => esc_html__('Dribbble', 'rr-core'),
             'email' => esc_html__('Email', 'rr-core'),
             'facebook' => esc_html__('Facebook', 'rr-core'),
             'flickr' => esc_html__('Flicker', 'rr-core'),
             'foursquare' => esc_html__('FourSquare', 'rr-core'),
             'github' => esc_html__('Github', 'rr-core'),
             'houzz' => esc_html__('Houzz', 'rr-core'),
             'instagram' => esc_html__('Instagram', 'rr-core'),
             'jsfiddle' => esc_html__('JS Fiddle', 'rr-core'),
             'linkedin' => esc_html__('LinkedIn', 'rr-core'),
             'medium' => esc_html__('Medium', 'rr-core'),
             'pinterest' => esc_html__('Pinterest', 'rr-core'),
             'product-hunt' => esc_html__('Product Hunt', 'rr-core'),
             'reddit' => esc_html__('Reddit', 'rr-core'),
             'slideshare' => esc_html__('Slide Share', 'rr-core'),
             'snapchat' => esc_html__('Snapchat', 'rr-core'),
             'soundcloud' => esc_html__('SoundCloud', 'rr-core'),
             'spotify' => esc_html__('Spotify', 'rr-core'),
             'stack-overflow' => esc_html__('StackOverflow', 'rr-core'),
             'tripadvisor' => esc_html__('TripAdvisor', 'rr-core'),
             'tumblr' => esc_html__('Tumblr', 'rr-core'),
             'twitch' => esc_html__('Twitch', 'rr-core'),
             'twitter' => esc_html__('Twitter', 'rr-core'),
             'vimeo' => esc_html__('Vimeo', 'rr-core'),
             'vk' => esc_html__('VK', 'rr-core'),
             'website' => esc_html__('Website', 'rr-core'),
             'whatsapp' => esc_html__('WhatsApp', 'rr-core'),
             'wordpress' => esc_html__('WordPress', 'rr-core'),
             'xing' => esc_html__('Xing', 'rr-core'),
             'yelp' => esc_html__('Yelp', 'rr-core'),
             'youtube' => esc_html__('YouTube', 'rr-core'),
         ];
     }
     
    protected function register_controls(){
        $this->register_controls_section();
        $this->style_tab_content();
    }  

    protected function register_controls_section(){

        // layout Panel
        $this->start_controls_section(
            'rr_layout',
            [
                'label' => esc_html__('Design Layout', 'rr-core'),
            ]
        );
        $this->add_control(
            'rr_design_style',
            [
                'label' => esc_html__('Select Layout', 'rr-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Layout 1', 'rr-core'),
                ],
                'default' => 'layout-1',
            ]
        );

        $this->end_controls_section();

        $this->rr_section_title_render_controls('team', 'Section Title', 'Sub Title', 'your title here', $default_description = 'Hic nesciunt galisum aut dolorem aperiam eum soluta quod ea cupiditate.');


        $this->start_controls_section(
         'rr_image_sec',
             [
               'label' => esc_html__( 'Thumbnail', 'rr-core' ),
               'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
             ]
        );
        
        $this->add_control(
         'rr_image',
         [
           'label'   => esc_html__( 'Upload Image', 'rr-core' ),
           'type'    => \Elementor\Controls_Manager::MEDIA,
             'default' => [
               'url' => \Elementor\Utils::get_placeholder_image_src(),
           ],
         ]
        );
        $this->add_group_control(
            Group_Control_Image_Size::get_type(),
            [
                'name' => 'thumbnail', // // Usage: `{name}_size` and `{name}_custom_dimension`, in this case `thumbnail_size` and `thumbnail_custom_dimension`.
                'exclude' => ['custom'],
                // 'default' => 'rr-post-thumb',
            ]
        );
        
        $this->end_controls_section();
        $this->start_controls_section(
            '_TP_contact_info',
            [
                'label' => esc_html__('Contact  List', 'tpcore'),
                'description' => esc_html__( 'Control all the style settings from Style tab', 'tpcore' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'repeater_condition',
            [
                'label' => __( 'Field condition', 'tpcore' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'style_1' => __( 'Style 1', 'tpcore' ),
                ],
                'default' => 'style_1',
                'frontend_available' => true,
                'style_transfer' => true,
            ]
        );

        $repeater->add_control(
            'rr_contact_text_label',
            [
                'label' => esc_html__('Label', 'tpcore'),
                'description' => rr_get_allowed_html_desc( 'intermediate' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'Label Here',
                'label_block' => true,
            ]
        );  
        $repeater->add_control(
            'rr_contact_info_title',
            [
                'label' => esc_html__('Title', 'tpcore'),
                'description' => rr_get_allowed_html_desc( 'intermediate' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'Title Here',
                'label_block' => true,
            ]
        );  

        $repeater->add_control(
            'link_type',
            [
                'label' => __( 'Link Type', 'tpcore' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    '' => __( 'None', 'tpcore' ),
                    'url' => __( 'URL', 'tpcore' ),
                    'tell' => __( 'Phone Number', 'tpcore' ),
                    'email' => __( 'Email', 'tpcore' ),
                ],
                'default' => '',
                'frontend_available' => true,
                'style_transfer' => true,
            ]
        );

        // url
        $repeater->add_control(
            'rr_contact_url',
            [
                'label' => esc_html__('URL', 'tpcore'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => '#',
                'label_block' => true,
                'condition' => [
                    'link_type' => 'url'
                ]
            ]
        );  

        // tell
        $repeater->add_control(
            'rr_contact_tell',
            [
                'label' => esc_html__('Phone Number', 'tpcore'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => '012345',
                'label_block' => true,
                'condition' => [
                    'link_type' => 'tell'
                ]
            ]
        );  

        // email
        $repeater->add_control(
            'rr_contact_email',
            [
                'label' => esc_html__('Email Address', 'tpcore'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('technix@gmail.com', 'tpcore'),
                'label_block' => true,
                'condition' => [
                    'link_type' => 'email'
                ]
            ]
        );  

        $this->add_control(
            'rr_list',
            [
                'label' => esc_html__('Contact - List', 'tpcore'),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'rr_contact_info_title' => esc_html__('united states', 'tpcore'),
                    ],
                    [
                        'rr_contact_info_title' => esc_html__('south Africa', 'tpcore')
                    ],
                    [
                        'rr_contact_info_title' => esc_html__('United Kingdom', 'tpcore')
                    ]
                ],
                'title_field' => '{{{ rr_contact_info_title }}}',
            ]
        );
        $this->end_controls_section();
        
        // button
        $this->rr_button_render('team_details', 'Button', ['layout-1', 'layout-2']);
        $this->rr_button_render('team_details_2', 'Button Two', ['layout-1']);

    }

    protected function style_tab_content(){
        $this->rr_section_style_controls('team_details_me_section', 'Section Style', '.ele-section');
        $this->rr_basic_style_controls('section_title', 'Section - Title', '.rr-el-title');
        $this->rr_basic_style_controls('section_desc', 'Section - Description', '.rr-el-desc');
        $this->rr_basic_style_controls('contact_title', 'contact - Title', '.rr-el-text');
        $this->rr_link_controls_style('repiter_btn', 'Team - Button', '.rr-el-btn');
        $this->rr_link_controls_style('repiter_btn_2', 'Team - Button Two', '.rr-el-btn-2');
    }

    /**
     * Render the widget ouRRut on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     *
     * @access protected
     */
    protected function render() {
        $settings = $this->get_settings_for_display();

        ?>


<?php if ( $settings['rr_design_style']  == 'layout-2' ) : ?>

<?php else:
    if ( !empty($settings['rr_image']['url']) ) {
        $rr_image_url = !empty($settings['rr_image']['id']) ? wp_get_attachment_image_url( $settings['rr_image']['id'], $settings['thumbnail_size']) : $settings['rr_image']['url'];
        $rr_image_alt = get_post_meta($settings["rr_image"]["id"], "_wp_attachment_image_alt", true);
    }
    $this->add_render_attribute('title_args', 'class', 'story-details__content-title mb-30 wow fadeInLeft animated rr-el-title');
        // Link
        if ('2' == $settings['rr_team_details_btn_link_type']) {
            $this->add_render_attribute('rr-button-arg', 'href', get_permalink($settings['rr_team_details_btn_page_link']));
            $this->add_render_attribute('rr-button-arg', 'target', '_self');
            $this->add_render_attribute('rr-button-arg', 'rel', 'nofollow');
            $this->add_render_attribute('rr-button-arg', 'class', 'rr-el-btn');
        } else {
            if ( ! empty( $settings['rr_team_details_btn_link']['url'] ) ) {
                $this->add_link_attributes( 'rr-button-arg', $settings['rr_team_details_btn_link'] );
                $this->add_render_attribute('rr-button-arg', 'class', 'rr-el-btn');
            }
        }

        // Link
        if ('2' == $settings['rr_team_details_2_btn_link_type']) {
            $this->add_render_attribute('rr-button-2-arg', 'href', get_permalink($settings['rr_team_details_2_btn_page_link']));
            $this->add_render_attribute('rr-button-2-arg', 'target', '_self');
            $this->add_render_attribute('rr-button-2-arg', 'rel', 'nofollow');
            $this->add_render_attribute('rr-button-2-arg', 'class', 'rr-el-btn-2');
        } else {
            if ( ! empty( $settings['rr_team_details_2_btn_link']['url'] ) ) {
                $this->add_link_attributes( 'rr-button-2-arg', $settings['rr_team_details_2_btn_link'] );
                $this->add_render_attribute('rr-button-2-arg', 'class', 'rr-el-btn-2');
            }
        }
?>
<section class="story-details__area padding-t100 section-space-bottom overflow-hidden ele-section">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-7">
                <div class="story-details__content">
                    <?php
                        if ( !empty($settings['rr_team_title' ]) ) :
                            printf( '<%1$s %2$s>%3$s</%1$s>',
                                tag_escape( $settings['rr_team_title_tag'] ),
                                $this->get_render_attribute_string( 'title_args' ),
                                rr_kses( $settings['rr_team_title' ] )
                                );
                        endif;
                    ?>
                    <div class="story-details__content-icon mb-30 wow fadeInLeft animated" data-wow-delay=".3s">
                        <svg width="96" height="76" viewBox="0 0 96 76" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path opacity="0.3"
                                d="M7.20616 36.59V36.5909C7.20616 38.4926 8.72059 40.007 10.6223 40.007H35.9984V74.5124H1.493V36.5909C1.493 18.8888 15.0229 4.28355 32.2581 2.56528V8.29926C25.5974 9.11479 19.4206 12.2568 14.833 17.194C9.9347 22.4655 7.21032 29.394 7.20616 36.59ZM94.401 40.007V74.5124H59.8956V36.5909C59.8956 18.8886 73.4264 4.28176 90.6997 2.56495V8.29661C76.5653 9.99792 65.6087 22.019 65.6087 36.5909C65.6087 38.4926 67.1232 40.007 69.0249 40.007H94.401Z"
                                stroke="#83CD20" stroke-width="2.93619" />
                        </svg>
                    </div>
                    <?php if(!empty($settings['rr_team_description' ])) : ?>
                    <p class=" wow fadeInLeft animated rr-el-desc" data-wow-delay=".4s">
                        <?php echo rr_kses($settings['rr_team_description']); ?></p>
                    <?php endif; ?>
                    <div class="teamdetail__content-text mt-20 wow fadeInLeft animated" data-wow-delay=".5s">
                        <ul>
                            <?php foreach ($settings['rr_list'] as $key => $item) : 
                                $key = $key+1;
                                $link_type = $item['link_type'];
                                $url = $item['rr_contact_url'];
                                $tell = $item['rr_contact_tell'];
                                $email = $item['rr_contact_email'];
                                $contact_link;
    
                                if($link_type == 'url'){
                                    $contact_link = $url;
                                } elseif($link_type == 'tell'){
                                    $contact_link = 'tel:'.$tell;
                                } elseif($link_type == 'email'){
                                    $contact_link = 'mailto:'.$email;
                                }
                            ?>
                            <li>
                                <?php echo rr_kses($item['rr_contact_text_label']);?>
                                <?php if(!empty($item['rr_contact_info_title'])) : ?>
                                <?php if(!empty($item['link_type'])) : ?>
                                <a
                                    href="<?php echo esc_url($contact_link); ?>"><?php echo rr_kses($item['rr_contact_info_title']); ?></a>
                                <?php else : ?>
                                <span class="rr-el-text"><?php echo rr_kses($item['rr_contact_info_title']); ?></span>
                                <?php endif; ?>
                                <?php endif; ?>
                            </li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                </div>
                <div class="story-details__button mt-40 wow fadeInLeft animated" data-wow-delay=".6s">
                    <a <?php echo $this->get_render_attribute_string( 'rr-button-arg' ); ?>><?php echo rr_kses($settings['rr_team_details_btn_text']); ?>
                        <i class="fa-solid fa-arrow-right"></i></a>
                    <a
                        <?php echo $this->get_render_attribute_string( 'rr-button-2-arg' ); ?>><?php echo rr_kses($settings['rr_team_details_2_btn_text']); ?></a>
                </div>
            </div>
            <div class="col-lg-5">
                <div class="story-details__media wow fadeInLeft animated" data-wow-delay=".7s">
                    <div class="story-details__media-wrapper">
                        <div class="story-details__media-wrapper-left-shape">
                            <img src="<?php echo get_template_directory_uri(  ); ?>/assets/imgs/story-img/story-details/story-details-right-shape1.png"
                                alt="img not found">
                        </div>
                        <div class="story-details__media-wrapper-right-shape">
                            <img src="<?php echo get_template_directory_uri(  ); ?>/assets/imgs/story-img/story-details/story-details-right-shape2.png"
                                alt="img not found">
                        </div>
                    </div>
                    <?php if(!empty($rr_image_url)) : ?>
                    <div class="story-details__media-thumb position-relative">
                        <div class="story-details__media-thumb-box"></div>
                        <img src="<?php echo esc_url($rr_image_url); ?>" alt="<?php echo esc_attr($rr_image_alt); ?>">
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</section>

<?php endif;
    }
}

$widgets_manager->register( new rr_Team_Details() );