<?php
namespace RRCore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Utils;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * RR Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class rr_FAQ extends Widget_Base {

	use \RRCore\Widgets\RRCoreElementFunctions;

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'rr-faq';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'FAQ', 'rr-core' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'rr-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'rr-core' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'rr-core' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */


	protected function register_controls(){
        $this->register_controls_section();
        $this->style_tab_content();
    }   

	protected function register_controls_section() {

        // layout Panel
        $this->start_controls_section(
            'rr_layout',
            [
                'label' => esc_html__('Design Layout', 'rr-core'),
            ]
        );
        $this->add_control(
            'rr_design_style',
            [
                'label' => esc_html__('Select Layout', 'rr-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Layout 1', 'rr-core'),
                    'layout-2' => esc_html__('Layout 2', 'rr-core'),
                    'layout-3' => esc_html__('Layout 3', 'rr-core'),
                    'layout-4' => esc_html__('Layout 4', 'rr-core'),
                ],
                'default' => 'layout-1',
            ]
        );
        $this->end_controls_section();

        $this->start_controls_section(
            '_accordion_thumb',
            [
                'label' => esc_html__( 'Image', 'rr-core' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
                'condition' => [
                    'rr_design_style' => ['layout-4']
                ],
            ]
        );
        $this->add_control(
            'rr_thumb_img',
            [
                'label' => esc_html__( 'Choose Small Thumbnail', 'rr-core' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );
        
		$this->add_control(
            'rr_accordion_active_switch',
            [
                'label' => esc_html__( 'Shap Show', 'rr-core' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Show', 'rr-core' ),
                'label_off' => esc_html__( 'Hide', 'rr-core' ),
                'return_value' => 'yes',
                'default' => '0',
            ]
        );

        $this->add_group_control(
            Group_Control_Image_Size::get_type(),
            [
                'name' => 'rr_thumb_size', // // Usage: `{name}_size` and `{name}_custom_dimension`, in this case `thumbnail_size` and `thumbnail_custom_dimension`.
                'exclude' => ['custom'],
            ]
        );

        $this->end_controls_section();

		 // rr_section_title
		$this->rr_section_title_render_controls('section', 'Section Title', 'Sub Title', 'your title here', $default_description = 'Hic nesciunt galisum aut dolorem aperiam eum soluta quod ea cupiditate.',['layout-1', 'layout-4']);


		$this->start_controls_section(
            '_accordion',
            [
                'label' => esc_html__( 'Accordion', 'rr-core' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT
            ]
        );

        $repeater = new \Elementor\Repeater();

		$repeater->add_control(
            'rr_accordion_active_switch',
            [
                'label' => esc_html__( 'Show', 'rr-core' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Show', 'rr-core' ),
                'label_off' => esc_html__( 'Hide', 'rr-core' ),
                'return_value' => 'yes',
                'default' => '0',
            ]
        );

        $repeater->add_control(
            'accordion_title', [
                'label' => esc_html__( 'Accordion Item', 'rr-core' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__( 'This is accordion item title' , 'rr-core' ),
                'label_block' => true,
            ]
        );

        $repeater->add_control(
            'accordion_description',
            [
                'label' => esc_html__('Description', 'rr-core'),
                'description' => rr_get_allowed_html_desc( 'intermediate' ),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'default' => 'Facilis fugiat hic ipsam iusto laudantium libero maiores minima molestiae mollitia repellat rerum sunt ullam voluptates? Perferendis, suscipit.',
                'label_block' => true,
            ]
        );
        $this->add_control(
            'accordions',
            [ 
                'label' => esc_html__( 'Repeater Accordion', 'rr-core' ),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'accordion_title' => esc_html__( 'This is accordion item title #1', 'rr-core' ),
                    ],
                    [
                        'accordion_title' => esc_html__( 'This is accordion item title #2', 'rr-core' ),
                    ],
                    [
                        'accordion_title' => esc_html__( 'This is accordion item title #3', 'rr-core' ),
                    ],
                    [
                        'accordion_title' => esc_html__( 'This is accordion item title #4', 'rr-core' ),
                    ],
                ],
                'title_field' => '{{{ accordion_title }}}',
            ]
        );

        $this->end_controls_section();
 
        // _rr_image
		$this->start_controls_section(
            '_rr_image',
            [
                'label' => esc_html__('Thumbnail', 'rr-core'),
                'condition' => [
                    'rr_design_style' => ['layout-1', 'layout-3']
                ]
            ]
        );
        $this->add_control(
            'rr_image',
            [
                'label' => esc_html__( 'Choose Image', 'rr-core' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],

            ]
        );
        $this->add_control(
            'rr_image_2',
            [
                'label' => esc_html__( 'Choose Image 2', 'rr-core' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
                'condition' => [
                    'rr_design_style' => ['layout-1', 'layout-3']
                ]

            ]
        );
        $this->add_control(
            'rr_image_3',
            [
                'label' => esc_html__( 'Choose Image 3', 'rr-core' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
                'condition' => [
                    'rr_design_style' => ['layout-1', 'layout-3']
                ]

            ]
        );


        $this->add_group_control(
            Group_Control_Image_Size::get_type(),
            [
                'name' => 'rr_image_size',
                'default' => 'full',
                'exclude' => [
                    'custom'
                ]
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'rr_extra_about',
            [
                'label' => esc_html__('Faq Extra Info', 'rr-core'),
                'condition' => [
                    'rr_design_style' => ['layout-1']
                ]
            ]
        );
           
        $this->add_control(
            'rr_box_icon_type',
            [
                'label' => esc_html__('Select Icon Type', 'rr-core'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'icon',
                'options' => [
                    'image' => esc_html__('Image', 'rr-core'),
                    'icon' => esc_html__('Icon', 'rr-core'),
                    'svg' => esc_html__('SVG', 'rr-core'),
                ],
    
            ]
        );
        $this->add_control(
            'rr_box_icon_svg',
            [
                'show_label' => false,
                'type' => Controls_Manager::TEXTAREA,
                'label_block' => true,
                'placeholder' => esc_html__('SVG Code Here', 'rr-core'),
                'condition' => [
                    'rr_box_icon_type' => 'svg'
                ]
            ]
        );
    
        $this->add_control(
            'rr_box_icon_image',
            [
                'label' => esc_html__('Upload Icon Image', 'rr-core'),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
                'condition' => [
                    'rr_box_icon_type' => 'image',
                ]
            ]
        );
    
        if (rr_is_elementor_version('<', '2.6.0')) {
            $this->add_control(
                'rr_box_icon',
                [
                    'show_label' => false,
                    'type' => Controls_Manager::ICON,
                    'label_block' => true,
                    'default' => 'fa fa-star',
                    'condition' => [
                        'rr_box_icon_type' => 'icon'
                    ]
                ]
            );
        } else {
            $this->add_control(
                'rr_box_selected_icon',
                [
                    'show_label' => false,
                    'type' => Controls_Manager::ICONS,
                    'fa4compatibility' => 'icon',
                    'label_block' => true,
                    'default' => [
                        'value' => 'fas fa-star',
                        'library' => 'solid',
                    ],
                    'condition' => [
                        'rr_box_icon_type' => 'icon'
                    ]
                ]
            );
        }
        $this->add_control(
            'rr_about_title',
            [
                'label' => esc_html__('Faq Title', 'rr-core'),
                'type' => Controls_Manager::TEXTAREA,
                'title' => esc_html__('Faq Title', 'rr-core'),
                'label_block' => true,
                'default'   => 'Nemo enim ipsam',
            ]
        );
        $this->add_control(
            'rr_about_desc',
            [
                'label' => esc_html__('Faq Desc', 'rr-core'),
                'type' => Controls_Manager::TEXTAREA,
                'title' => esc_html__('Faq Desc', 'rr-core'),
                'label_block' => true,
                'default'   => 'Nemo enim ipsam',
            ]
        );

        $this->end_controls_section();

	}

	protected function style_tab_content(){
		$this->rr_section_style_controls('faq_section', 'Section - Style', '.rr-el-section');
        $this->rr_basic_style_controls('section_sub_title', 'Section - Sub Title', '.rr-el-sub-title');
        $this->rr_basic_style_controls('section_title', 'Section - Title', '.rr-el-title');
        $this->rr_basic_style_controls('faq_title', 'faq Title', '.rr-el-re-Title');
        $this->rr_basic_style_controls('faq_desc', 'faq Description', '.rr-el-re-dec');
    }

	/**
	 * Render the widget ouRRut on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * 
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		?>

<?php if ( $settings['rr_design_style']  == 'layout-2' ): 
    $this->add_render_attribute('title_args', 'class', 'rr-section-title');  

?>
<section class="faq__area  section-space rr-el-section">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="rs__faq">
                    <div class="accordion" id="accordionExample">
                        <?php foreach ($settings['accordions'] as $id => $item) :
                            // active class
                            $collapsed_tab = ($id == 0) ? '' : 'collapsed';
                            $area_expanded = ($id == 0) ? 'true' : 'false';
                            $active_show_tab = ($id == 0) ? 'show' : 'collapse';
                        ?>
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="headingOne-<?php echo esc_attr($id); ?>">
                                <button
                                    class="accordion-button rr-el-re-Title <?php echo esc_attr( $active_show_tab ); ?>"
                                    type="button" data-bs-toggle="collapse"
                                    data-bs-target="#collapseOne-<?php echo esc_attr($id); ?>" aria-expanded="true"
                                    aria-controls="collapseOne-<?php echo esc_attr($id); ?>">
                                    <?php echo esc_html($item['accordion_title']); ?>
                                </button>
                            </h2>
                            <div id="collapseOne-<?php echo esc_attr($id); ?>"
                                class="accordion-collapse collapse <?php echo esc_attr( $active_show_tab ); ?>"
                                aria-labelledby="headingOne-<?php echo esc_attr($id); ?>"
                                data-bs-parent="#accordionExample">
                                <div class="accordion-body">
                                    <p class="rr-el-re-dec"><?php echo rr_kses($item['accordion_description']); ?></p>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php elseif ( $settings['rr_design_style']  == 'layout-3' ): 
    $this->add_render_attribute('title_args', 'class', 'rr-section-title');  
?>
<div class="visa-details__content-faq rr-el-section">
    <div class="accordion" id="accordionExample1">
        <?php foreach ($settings['accordions'] as $id => $item) :
            // active class
            $collapsed_tab = ($id == 0) ? '' : 'collapsed';
            $area_expanded = ($id == 0) ? 'true' : 'false';
            $active_show_tab = ($id == 0) ? 'collapse show' : 'collapse';
        ?>
        <div class="accordion-item  wow fadeInLeft animated" data-wow-delay=".3s">
            <h5 class="accordion-header" id="headingOne-<?php echo esc_attr($id); ?>">
                <button class="accordion-button collapsed rr-el-re-Title" type="button" data-bs-toggle="collapse"
                    data-bs-target="#collapseOne-<?php echo esc_attr($id); ?>" aria-expanded="true"
                    aria-controls="collapseOne-<?php echo esc_attr($id); ?>">
                    <?php echo esc_html($item['accordion_title']); ?>
                </button>
            </h5>
            <div id="collapseOne-<?php echo esc_attr($id); ?>" class="accordion-collapse collapse"
                aria-labelledby="headingOne-<?php echo esc_attr($id); ?>" data-bs-parent="#accordionExample1">
                <div class="accordion-body">
                    <p class="rr-el-re-dec"><?php echo rr_kses($item['accordion_description']); ?></p>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
</div>
<?php elseif ( $settings['rr_design_style']  == 'layout-4' ): 
    $this->add_render_attribute('title_args', 'class', 'section__title-wrapper-title wow fadeInLeft animated rr-el-title');  
    if ( !empty($settings['rr_thumb_img']['url']) ) {
        $rr_image = !empty($settings['rr_thumb_img']['id']) ? wp_get_attachment_image_url( $settings['rr_thumb_img']['id'], $settings['rr_thumb_size_size']) : $settings['rr_thumb_img']['url'];
        $rr_image_alt = get_post_meta($settings["rr_thumb_img"]["id"], "_wp_attachment_image_alt", true);
    }

?>
<section class="faq-5__area ask-question p-relative overflow-hidden section-space rr-el-section">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-6">
                <div class="faq-5__thumb">
                    <?php if ( !empty($settings['rr_accordion_active_switch']) ) : ?>
                    <div class="faq-5__thumb-shape upDown-bottom">
                        <img src="<?php echo get_template_directory_uri(  ); ?>/assets/imgs/home-5/faq-circle-plane-shape.png"
                            alt="img not found">
                    </div>
                    <?php endif; ?>
                    <div class="faq-5__thumb-media">
                        <?php if(!empty($rr_image)) : ?>
                        <img src="<?php echo esc_url($rr_image); ?>" alt="<?php echo esc_attr($rr_image_alt); ?>">
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="col-lg-6">
            <?php if ( !empty($settings['rr_section_section_title_show']) ) : ?>
                <div class="section__title-wrapper mb-40">
                    <h6 class="section__title-wrapper-black-subtitle mb-10 wow fadeInLeft animated rr-el-sub-title"
                        data-wow-delay=".2s"><?php echo rr_kses( $settings['rr_section_sub_title'] ); ?></h6>

                    <?php
                            if ( !empty($settings['rr_section_title' ]) ) :
                                printf( '<%1$s %2$s>%3$s</%1$s>',
                                tag_escape( $settings['rr_section_title_tag'] ),
                                $this->get_render_attribute_string( 'title_args' ),
                                rr_kses( $settings['rr_section_title' ] )
                                );
                            endif;
                        ?>
                        
                </div>
                <?php endif; ?>
                <div class="ask-question__faq">
                    <div class="accordion" id="accordionExample">
                    <?php foreach ($settings['accordions'] as $id => $item) :
                            // active class
                            $collapsed_tab = ($id == 0) ? '' : 'collapsed';
                            $area_expanded = ($id == 0) ? 'true' : 'false';
                            $active_show_tab = ($id == 0) ? 'collapse show' : 'collapse';
                        ?>
                        <div class="accordion-item ask-question__faq-item faq-5__item wow fadeInLeft animated"
                            data-wow-delay=".5s">
                            <h5 class="accordion-header" id="headingTow-<?php echo esc_attr($id); ?>">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                    data-bs-target="#collapseTow-<?php echo esc_attr($id); ?>" aria-expanded="true"
                                    aria-controls="collapseTow-<?php echo esc_attr($id); ?>">
                                    <?php echo esc_html($item['accordion_title']); ?>
                                </button>
                            </h5>
                            <div id="collapseTow-<?php echo esc_attr($id); ?>"
                                class="accordion-collapse collapse <?php echo esc_attr($active_show_tab); ?>"
                                aria-labelledby="headingTow-<?php echo esc_attr($id); ?>"
                                data-bs-parent="#accordionExample">
                                <div class="accordion-body">
                                    <p><?php echo rr_kses($item['accordion_description']); ?></p>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php else : 
	$this->add_render_attribute('title_args', 'class', 'section__title-wrapper-title wow fadeInLeft animated rr-el-title');  
    if ( !empty($settings['rr_image']['url']) ) {
        $rr_image = !empty($settings['rr_image']['id']) ? wp_get_attachment_image_url( $settings['rr_image']['id'], $settings['rr_image_size_size']) : $settings['rr_image']['url'];
        $rr_image_alt = get_post_meta($settings["rr_image"]["id"], "_wp_attachment_image_alt", true);
    }
    if ( !empty($settings['rr_image_2']['url']) ) {
        $rr_image_2 = !empty($settings['rr_image_2']['id']) ? wp_get_attachment_image_url( $settings['rr_image_2']['id'], $settings['rr_image_size_size']) : $settings['rr_image_2']['url'];
        $rr_image_alt_2 = get_post_meta($settings["rr_image_2"]["id"], "_wp_attachment_image_alt", true);
    }
    if ( !empty($settings['rr_image_3']['url']) ) {
        $rr_image_3 = !empty($settings['rr_image_3']['id']) ? wp_get_attachment_image_url( $settings['rr_image_3']['id'], $settings['rr_image_size_size']) : $settings['rr_image_3']['url'];
        $rr_image_alt_3 = get_post_meta($settings["rr_image_3"]["id"], "_wp_attachment_image_alt", true);
    }
?>

<section class="ask-question__area section-space gray-bg rr-el-section">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-6">
                <div class="ask-question__media d-flex">
                    <div class="ask-question__media-thumb">
                        <div class="ask-question__media-thumb-img wow fadeInLeft animated" data-wow-delay=".2s">
                            <?php if(!empty($rr_image)) : ?>
                            <img src="<?php echo esc_url($rr_image); ?>" alt="<?php echo esc_attr($rr_image_alt); ?>">
                            <?php endif; ?>
                        </div>
                        <div class="ask-question__text mt-30 wow fadeInLeft animated" data-wow-delay=".3s">
                            <div class="ask-question__text-icon">
                                <?php if($settings['rr_box_icon_type'] == 'icon') : ?>
                                <?php if (!empty($settings['rr_box_icon']) || !empty($settings['rr_box_selected_icon']['value'])) : ?>
                                <span>
                                    <?php rr_render_icon($settings, 'rr_box_icon', 'rr_box_selected_icon'); ?>
                                </span>
                                <?php endif; ?>
                                <?php elseif( $settings['rr_box_icon_type'] == 'image' ) : ?>
                                <?php if (!empty($settings['rr_box_icon_image']['url'])): ?>
                                <span>
                                    <img src="<?php echo $settings['rr_box_icon_image']['url']; ?>"
                                        alt="<?php echo get_post_meta(attachment_url_to_postid($settings['rr_box_icon_image']['url']), '_wp_attachment_image_alt', true); ?>">
                                </span>
                                <?php endif; ?>
                                <?php else : ?>
                                <?php if (!empty($settings['rr_box_icon_svg'])): ?>
                                <div class="contact-inner-img">
                                    <?php echo $settings['rr_box_icon_svg']; ?>
                                </div>
                                <?php endif; ?>
                                <?php endif; ?>
                            </div>
                            <div class="ask-question__text-title">
                                <?php if (!empty($settings['rr_about_title'])): ?>
                                <h5><?php echo rr_kses($settings['rr_about_title']); ?></h5>
                                <?php endif; ?>
                                <?php if (!empty($settings['rr_about_desc'])): ?>
                                <p><?php echo rr_kses($settings['rr_about_desc']); ?></p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="ask-question__media-img">
                        <div class="ask-question__media-img-img1 wow fadeInLeft animated" data-wow-delay=".4s">
                            <?php if(!empty($rr_image_2)) : ?>
                            <img src="<?php echo esc_url($rr_image_2); ?>"
                                alt="<?php echo esc_attr($rr_image_alt_2); ?>">
                            <?php endif; ?>
                        </div>
                        <div class="ask-question__media-img-img2 wow fadeInLeft animated" data-wow-delay=".5s">
                            <?php if(!empty($rr_image_3)) : ?>
                            <img src="<?php echo esc_url($rr_image_3); ?>"
                                alt="<?php echo esc_attr($rr_image_alt_3); ?>">
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-6">
            <?php if ( !empty($settings['rr_section_section_title_show']) ) : ?>
                <div class="section__title-wrapper mb-40">
                    <?php if ( !empty($settings['rr_section_sub_title']) ) : ?>
                    <h6 class="section__title-wrapper-black-subtitle mb-10 wow fadeInLeft animated rr-el-sub-title"
                        data-wow-delay=".2s"> <?php echo rr_kses( $settings['rr_section_sub_title'] ); ?><svg width="52"
                            height="10" viewBox="0 0 52 10" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <g clip-path="url(#clip0_3795_113)">
                                <path
                                    d="M47.2095 2.14437C46.4096 2.36766 45.5874 2.50135 44.758 2.54299L38.0745 3.26714C36.5625 3.43986 35.0713 3.76256 33.6232 4.23048C32.834 4.49614 32.0748 4.84349 31.3577 5.2669C30.5815 5.78994 29.7739 6.26475 28.9394 6.68864C28.4366 6.92402 27.8868 7.04215 27.3317 7.03411C26.7204 6.99856 26.1425 6.7438 25.704 6.3166C24.8602 5.44628 24.6277 4.38993 24.0763 3.71228C23.8482 3.37951 23.505 3.14288 23.1129 3.04791C22.6926 2.95474 22.2543 2.98472 21.8506 3.13427C20.9442 3.46398 20.1839 4.10423 19.7047 4.94135C19.1267 5.79839 18.675 6.775 18.0172 7.69183C17.3771 8.67698 16.4285 9.42226 15.3199 9.81116C14.738 9.97733 14.1213 9.97733 13.5394 9.81116C12.9881 9.64765 12.4799 9.36403 12.0512 8.9807C11.2848 8.27735 10.6875 7.40973 10.3039 6.44282C9.91861 5.55257 9.63957 4.68889 9.25423 3.93151C8.81236 2.89622 8.01001 2.05634 6.99598 1.56765C5.98195 1.07897 4.82509 0.974642 3.74 1.27404C3.16364 1.41933 2.62491 1.6859 2.15977 2.05594C1.69463 2.42599 1.3138 2.89102 1.04267 3.41996C0.609026 4.23627 0.40251 5.15404 0.444721 6.07742C0.461366 6.66905 0.587529 7.25247 0.816785 7.79813C0.969589 8.18346 1.07589 8.37613 1.04267 8.40271C1.00945 8.42928 0.849998 8.26318 0.624113 7.89778C0.297997 7.3528 0.0960956 6.74258 0.0328167 6.11063C-0.094422 5.09968 0.0716196 4.07346 0.511162 3.1542C0.798973 2.52884 1.21785 1.97266 1.73939 1.52332C2.26094 1.07399 2.87299 0.742013 3.53404 0.549886C4.3414 0.314234 5.19125 0.262331 6.02128 0.397987C6.85131 0.533642 7.64045 0.85342 8.33077 1.33384C9.08192 1.89515 9.6841 2.63192 10.0847 3.47975C10.5165 4.31021 10.8221 5.18716 11.2008 6.01762C11.535 6.84506 12.053 7.58567 12.7156 8.18347C13.0179 8.47409 13.3907 8.68086 13.7973 8.78339C14.204 8.88592 14.6303 8.88064 15.0342 8.7681C15.9058 8.44143 16.6489 7.84273 17.1536 7.06068C17.7316 6.2568 18.1833 5.28018 18.8145 4.33678C19.1355 3.84764 19.5172 3.40117 19.9505 3.00804C20.4071 2.61118 20.9377 2.30862 21.5118 2.11779C22.1043 1.91517 22.7412 1.88068 23.3521 2.01814C23.9719 2.17131 24.5177 2.53834 24.8934 3.05455C25.5977 3.99795 25.8368 5.04765 26.4082 5.5725C26.6675 5.83263 27.0118 5.99065 27.3782 6.01762C27.7818 6.02071 28.1811 5.9345 28.5475 5.76517C29.3497 5.36762 30.1284 4.92396 30.8794 4.43644C31.657 3.99071 32.4814 3.632 33.3375 3.36681C34.8527 2.91365 36.4116 2.62192 37.9881 2.49649C40.8449 2.25731 43.1369 2.18423 44.7314 2.1045C45.5564 2.02614 46.3875 2.03952 47.2095 2.14437Z"
                                    fill="#034833" />
                                <path
                                    d="M45.4762 6.2697C45.4231 6.13018 46.1406 5.7382 47.2235 5.08712C47.7683 4.76158 48.4127 4.36296 49.1036 3.89126C49.4491 3.65873 49.768 3.39963 50.1666 3.13388C50.3373 3.0178 50.4954 2.88421 50.6383 2.73527C50.7579 2.61795 50.8527 2.47789 50.9173 2.32336C50.9506 2.19713 50.9173 2.20377 50.9173 2.15726C50.821 2.06916 50.7009 2.01139 50.5719 1.99117L49.283 1.64571C48.4592 1.41982 47.7218 1.20058 47.1039 0.981341C45.8682 0.582721 45.1108 0.263819 45.1573 0.124302C45.2038 -0.0152149 46.001 0.0379361 47.2833 0.250534C47.9476 0.356832 48.6784 0.502993 49.5155 0.675728L50.8443 0.968051C51.184 1.02987 51.4955 1.19726 51.7345 1.4464C51.8826 1.61431 51.9774 1.82242 52.0069 2.04432C52.0341 2.24825 52.0113 2.45574 51.9405 2.6489C51.8291 2.94985 51.6521 3.2222 51.4223 3.44614C51.235 3.63879 51.0254 3.80831 50.7978 3.95105C50.4124 4.23009 50.0205 4.47591 49.6484 4.70179C48.9845 5.09883 48.2916 5.44528 47.5756 5.7382C46.3399 6.25641 45.5294 6.40257 45.4762 6.2697Z"
                                    fill="#034833" />
                            </g>
                            <defs>
                                <clipPath id="clip0_3795_113">
                                    <rect width="52" height="9.86585" fill="white" transform="translate(0 0.0664062)" />
                                </clipPath>
                            </defs>
                        </svg>
                    </h6>
                    <?php endif; ?>
                    <?php
                        if ( !empty($settings['rr_section_title' ]) ) :
                            printf( '<%1$s %2$s>%3$s</%1$s>',
                            tag_escape( $settings['rr_section_title_tag'] ),
                            $this->get_render_attribute_string( 'title_args' ),
                            rr_kses( $settings['rr_section_title' ] )
                            );
                        endif;
                    ?>
                </div>
            <?php endif; ?>
                <div class="ask-question__faq">
                    <div class="accordion" id="accordionExample">
                        <?php foreach ($settings['accordions'] as $id => $item) :
                            // active class
                            $collapsed_tab = ($id == 0) ? '' : 'collapsed';
                            $area_expanded = ($id == 0) ? 'true' : 'false';
                            $active_show_tab = ($id == 0) ? 'collapse show' : 'collapse';
                        ?>
                        <div class="accordion-item ask-question__faq-item wow fadeInLeft animated" data-wow-delay=".5s">
                            <h5 class="accordion-header rr-el-re-Title" id="headingOne-<?php echo esc_attr($id); ?>">
                                <button class="accordion-button collapsed rr-el-re-Title" type="button"
                                    data-bs-toggle="collapse" data-bs-target="#collapseOne-<?php echo esc_attr($id); ?>"
                                    aria-expanded="true" aria-controls="collapseOne-<?php echo esc_attr($id); ?>">
                                    <?php echo esc_html($item['accordion_title']); ?>
                                </button>
                            </h5>
                            <div id="collapseOne-<?php echo esc_attr($id); ?>"
                                class="accordion-collapse collapse  <?php echo esc_attr($active_show_tab); ?>"
                                aria-labelledby="headingOne-<?php echo esc_attr($id); ?>"
                                data-bs-parent="#accordionExample">
                                <div class="accordion-body">
                                    <p class="rr-el-re-dec"><?php echo rr_kses($item['accordion_description']); ?></p>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php endif;
	}

}

$widgets_manager->register( new rr_FAQ() );