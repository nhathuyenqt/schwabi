<?php
namespace RRcore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Repeater;
use \Elementor\Utils;

use \Elementor\Group_Control_Border;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Text_Shadow;
use \Elementor\Group_Control_Typography;
Use \Elementor\Core\Schemes\Typography;
use \Elementor\Group_Control_Background;
use RRcore\Elementor\Controls\Group_Control_RRBGGradient;


if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * RR Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class rr_Fact extends Widget_Base {

    use \RRcore\Widgets\RRcoreElementFunctions;

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'rr-fact';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Fact', 'RRcore' );
	}

	/** 
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'rr-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'RRcore' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'RRcore' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */

    protected function register_controls(){
        $this->register_controls_section();
        $this->style_tab_content();
    }   

	protected function register_controls_section() {

        // layout Panel
        $this->start_controls_section(
            'rr_layout',
            [
                'label' => esc_html__('Design Layout', 'RRcore'),
            ]
        );
        $this->add_control(
            'rr_design_style',
            [
                'label' => esc_html__('Select Layout', 'RRcore'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Layout 1', 'RRcore'),
                    'layout-2' => esc_html__('Layout 2', 'RRcore'),
                    'layout-3' => esc_html__('Layout 3', 'RRcore'),
                    'layout-4' => esc_html__('Layout 4', 'RRcore'),
                ],
                'default' => 'layout-1',
            ]
        );

        $this->end_controls_section();

        $this->rr_section_title_render_controls('fact', 'Section Title', 'Sub Title', 'your title here', $default_description = 'Hic nesciunt galisum aut dolorem aperiam eum soluta quod ea cupiditate.',['layout-2']);

        // fact group
        $this->start_controls_section(
            'rr_fact',
            [
                'label' => esc_html__('Fact List', 'RRcore'),
                'description' => esc_html__( 'Control all the style settings from Style tab', 'RRcore' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $repeater = new \Elementor\Repeater();
        $repeater->add_control(
            'repeater_condition',
            [
                'label' => __( 'Field condition', 'RRcore' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'style_1' => __( 'Style 1', 'RRcore' ),
                    'style_2' => __( 'Style 2', 'RRcore' ),
                ],
                'default' => 'style_1',
                'frontend_available' => true,
                'style_transfer' => true,
            ]
        );

        $repeater->add_control(
            'rr_box_icon_type',
            [
                'label' => esc_html__('Select Icon Type', 'RRcore'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'icon',
                'options' => [
                    'image' => esc_html__('Image', 'RRcore'),
                    'icon' => esc_html__('Icon', 'RRcore'),
                    'svg' => esc_html__('SVG', 'RRcore'),
                ],
                'condition' => [
                    'repeater_condition' => ['style_2']
                ]
            ]
        );

        $repeater->add_control(
            'rr_box_icon_svg',
            [
                'show_label' => false,
                'type' => Controls_Manager::TEXTAREA,
                'label_block' => true,
                'placeholder' => esc_html__('SVG Code Here', 'RRcore'),
                'condition' => [
                    'rr_box_icon_type' => 'svg',
                    'repeater_condition' => ['style_2']
                ]
            ]
        );

        $repeater->add_control(
            'rr_box_icon_image',
            [
                'label' => esc_html__('Upload Icon Image', 'RRcore'),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
                'condition' => [
                    'rr_box_icon_type' => 'image',
                    'repeater_condition' => ['style_2']
                ]
            ]
        );

        if (rr_is_elementor_version('<', '2.6.0')) {
            $repeater->add_control(
                'rr_box_icon',
                [
                    'show_label' => false,
                    'type' => Controls_Manager::ICON,
                    'label_block' => true,
                    'default' => 'fa fa-star',
                    'condition' => [
                        'rr_box_icon_type' => 'icon',
                        'repeater_condition' => ['style_2']
                    ]
                ]
            );
        } else {
            $repeater->add_control(
                'rr_box_selected_icon',
                [
                    'show_label' => false,
                    'type' => Controls_Manager::ICONS,
                    'fa4compatibility' => 'icon',
                    'label_block' => true,
                    'default' => [
                        'value' => 'fas fa-star',
                        'library' => 'solid',
                    ],
                    'condition' => [
                        'rr_box_icon_type' => 'icon',
                        'repeater_condition' => ['style_2']
                    ]
                ]
            );
        }

        $repeater->add_control(
            'rr_fact_number', [
                'label' => esc_html__('Number', 'RRcore'),
                'description' => rr_get_allowed_html_desc( 'basic' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('17', 'RRcore'),
                'label_block' => true,
            ]
        );

        $repeater->add_control(
            'rr_fact_number_unit', [
                'label' => esc_html__('Number Unit', 'RRcore'),
                'description' => rr_get_allowed_html_desc( 'basic' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('+', 'RRcore'),
                'label_block' => true,
            ]
        );
 
        $repeater->add_control(
            'rr_fact_title',
            [
                'label' => esc_html__('Title', 'RRcore'),
                'description' => rr_get_allowed_html_desc( 'intermediate' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('Food', 'RRcore'),
                'label_block' => true,
            ]
        ); 

        $this->add_control(
            'rr_fact_list',
            [
                'label' => esc_html__('Fact - List', 'RRcore'),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'rr_fact_number' => esc_html__('23', 'RRcore'),
                        'rr_fact_title' => esc_html__('Business', 'RRcore'),
                    ],
                    [
                        'rr_fact_number' => esc_html__('45', 'RRcore'),
                        'rr_fact_title' => esc_html__('Website', 'RRcore')
                    ],
                    [
                        'rr_fact_number' => esc_html__('129', 'RRcore'),
                        'rr_fact_title' => esc_html__('Marketing', 'RRcore')
                    ]
                ],
                'title_field' => '{{{ rr_fact_title }}}',
            ]
        );
        $this->end_controls_section();
       // _rr_image
		$this->start_controls_section(
            '_rr_image',
            [
                'label' => esc_html__('Thumbnail', 'rr-core'),
                'condition' => [
                    'rr_design_style' => ['layout-1', 'layout-2']
                ]
            ]
        );
        $this->add_control(
            'rr_image',
            [
                'label' => esc_html__( 'Choose Image', 'rr-core' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
                'condition' => [
                    'rr_design_style' => ['layout-1', 'layout-2']
                ]
            ]
        );

        $this->add_group_control(
            Group_Control_Image_Size::get_type(),
            [
                'name' => 'rr_image_size',
                'default' => 'full',
                'exclude' => [
                    'custom'
                ]
            ]
        );

        $this->end_controls_section();
          // _rr_image
		$this->start_controls_section(
            'rr_fact_info',
            [
                'label' => esc_html__('Fact Info', 'rr-core'),
                'condition' => [
                    'rr_design_style' => ['layout-1']
                ]
            ]
        );
          
        $this->add_control(
            'rr_box_icon_type_2',
            [
                'label' => esc_html__('Select Icon Type', 'rr-core'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'icon',
                'options' => [
                    'image' => esc_html__('Image', 'rr-core'),
                    'icon' => esc_html__('Icon', 'rr-core'),
                    'svg' => esc_html__('SVG', 'rr-core'),
                ],
    
            ]
        );
        $this->add_control(
            'rr_box_icon_svg_2',
            [
                'show_label' => false,
                'type' => Controls_Manager::TEXTAREA,
                'label_block' => true,
                'placeholder' => esc_html__('SVG Code Here', 'rr-core'),
                'condition' => [
                    'rr_box_icon_type_2' => 'svg'
                ]
            ]
        );
    
        $this->add_control(
            'rr_box_icon_image_2',
            [
                'label' => esc_html__('Upload Icon Image', 'rr-core'),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
                'condition' => [
                    'rr_box_icon_type_2' => 'image',
                ]
            ]
        );
    
        if (rr_is_elementor_version('<', '2.6.0')) {
            $this->add_control(
                'rr_box_icon_2',
                [
                    'show_label' => false,
                    'type' => Controls_Manager::ICON,
                    'label_block' => true,
                    'default' => 'fa fa-star',
                    'condition' => [
                        'rr_box_icon_type_2' => 'icon'
                    ]
                ]
            );
        } else {
            $this->add_control(
                'rr_box_selected_icon_2',
                [
                    'show_label' => false,
                    'type' => Controls_Manager::ICONS,
                    'fa4compatibility' => 'icon',
                    'label_block' => true,
                    'default' => [
                        'value' => 'fas fa-star',
                        'library' => 'solid',
                    ],
                    'condition' => [
                        'rr_box_icon_type_2' => 'icon'
                    ]
                ]
            );
        }
        $this->add_control(
            'rr_fact_info_image',
            [
                'label' => esc_html__( 'Choose Image', 'rr-core' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],

            ]
        );

        $this->add_group_control(
            Group_Control_Image_Size::get_type(),
            [
                'name' => 'rr_img_size',
                'default' => 'full',
                'exclude' => [
                    'custom'
                ]
            ]
        );
        $this->add_control(
            'rr_fact_info_title',
            [
                'label' => esc_html__('Title', 'RRcore'),
                'description' => rr_get_allowed_html_desc( 'intermediate' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('Lorem Ipsum is simply', 'RRcore'),
                'label_block' => true,
            ]
        ); 
        $this->add_control(
            'rr_fact_info_desc',
            [
                'label' => esc_html__('Description', 'RRcore'),
                'description' => rr_get_allowed_html_desc( 'intermediate' ),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'default' => esc_html__('Lorem Ipsum is simply Lorem Ipsum is simply', 'RRcore'),
                'label_block' => true,
            ]
        ); 

        $this->end_controls_section();

        // button
        $this->rr_button_render('fact', 'Button', ['layout-1']);
         // rr_video
         $this->start_controls_section(
            'rr_video',
            [
                'label' => esc_html__('Video', 'rr-core'),
                'condition' => [
                    'rr_design_style' => ['layout-3']
                ]
            ]
        );

        $this->add_control(
            'rr_video_url',
            [
                'label' => esc_html__( 'Video URL', 'rr-core' ),
                'type' => Controls_Manager::URL,
                'options' => [ 'url', 'is_external', 'nofollow' ],
                'default' => [
                    'url' => 'https://www.youtube.com/watch?v=_ZmB5RdUgPQ',
                    'is_external' => true,
                    'nofollow' => true,
                ],
                'label_block' => true,
            ]
        );
		$this->add_control(
            'rr_thumbnail_image',
            [
                'label' => esc_html__( 'Choose Member Image', 'rr-core' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Image_Size::get_type(),
            [
                'name' => 'rr_thumbnail_size',
                'default' => 'full', 
                'exclude' => [
                    'custom'
                ]
            ]
        );

        $this->end_controls_section();  
	}
 
    // style_tab_content
    protected function style_tab_content(){
        $this->rr_section_style_controls('fact_section', 'Section - Style', '.rr-el-section');
        $this->rr_basic_style_controls('section_sub_title', 'Section - Sub Title', '.rr-el-sub-title');
        $this->rr_basic_style_controls('section_title', 'Section - Title', '.rr-el-title');
        $this->rr_basic_style_controls('section_desc', 'Section - Description', '.rr-el-desc');
        $this->rr_link_controls_style('fact_rp_icon', 'Fact - Rep Icon', '.rr-el-rep-icon');
        $this->rr_basic_style_controls('fact_number', 'Fact Number', '.rr-el-re-number');
        $this->rr_basic_style_controls('fact_title', 'Fact Title', '.rr-el-re-Title');
        $this->rr_link_controls_style('fact_btn', 'Fact - Button', '.rr-el-btn');
    }

	/**
	 * Render the widget ouRRut on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		?>

<?php if ( $settings['rr_design_style']  == 'layout-2' ): 
    $this->add_render_attribute('title_args', 'class', 'section__title-wrapper-title coustom__title text-white wow fadeInLeft animated rr-el-title ');
    if ( !empty($settings['rr_image']['url']) ) {
        $rr_image = !empty($settings['rr_image']['id']) ? wp_get_attachment_image_url( $settings['rr_image']['id'], $settings['rr_image_size_size']) : $settings['rr_image']['url'];
        $rr_image_alt = get_post_meta($settings["rr_image"]["id"], "_wp_attachment_image_alt", true);
    }
?>

<section class="counter2__area gray-bg section-space-bottom position-relative rr-el-section">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-12">
                <div class="counter2__allcontent">
                    <div class="counter2__bg-color p-relative overflow-hidden">
                        <div class="counter2__bg-img" data-background="<?php echo esc_url($rr_image);?>"></div>
                        <div class="container">
                            <div class="row counter2__wrap align-items-center">
                                <div class="col-xl-5 ">
                                    <div class=" counter2__content">
                                        <div class="section__title-wrapper mb-15">
                                            <?php if ( !empty($settings['rr_fact_sub_title']) ) : ?>
                                            <h6 class="section__title-wrapper-black-subtitle text-white mb-10 wow fadeInLeft animated rr-el-sub-title"
                                                data-wow-delay=".2s">
                                                <?php echo rr_kses( $settings['rr_fact_sub_title'] ); ?>
                                                <svg width="52" height="10" viewBox="0 0 52 10" fill="none"
                                                    xmlns="http://www.w3.org/2000/svg">
                                                    <g clip-path="url(#clip0_3800_516)">
                                                        <path
                                                            d="M47.2105 2.14437C46.4106 2.36766 45.5884 2.50135 44.759 2.54299L38.0755 3.26714C36.5634 3.43986 35.0723 3.76256 33.6242 4.23048C32.835 4.49614 32.0757 4.84349 31.3587 5.2669C30.5825 5.78994 29.7749 6.26475 28.9404 6.68864C28.4375 6.92402 27.8878 7.04215 27.3326 7.03411C26.7214 6.99856 26.1435 6.7438 25.7049 6.3166C24.8612 5.44628 24.6287 4.38993 24.0772 3.71228C23.8491 3.37951 23.506 3.14288 23.1139 3.04791C22.6936 2.95474 22.2553 2.98472 21.8516 3.13427C20.9452 3.46398 20.1849 4.10423 19.7057 4.94135C19.1277 5.79839 18.6759 6.775 18.0182 7.69183C17.3781 8.67698 16.4295 9.42226 15.3209 9.81116C14.739 9.97733 14.1223 9.97733 13.5404 9.81116C12.9891 9.64765 12.4808 9.36403 12.0522 8.9807C11.2858 8.27735 10.6885 7.40973 10.3049 6.44282C9.91959 5.55257 9.64054 4.68889 9.25521 3.93151C8.81334 2.89622 8.01098 2.05634 6.99695 1.56765C5.98293 1.07897 4.82607 0.974642 3.74097 1.27404C3.16462 1.41933 2.62589 1.6859 2.16075 2.05594C1.69561 2.42599 1.31477 2.89102 1.04364 3.41996C0.610002 4.23627 0.403487 5.15404 0.445698 6.07742C0.462342 6.66905 0.588506 7.25247 0.817762 7.79813C0.970566 8.18346 1.07686 8.37613 1.04364 8.40271C1.01043 8.42928 0.850974 8.26318 0.62509 7.89778C0.298973 7.3528 0.0970721 6.74258 0.0337932 6.11063C-0.0934455 5.09968 0.0725961 4.07346 0.512138 3.1542C0.79995 2.52884 1.21882 1.97266 1.74037 1.52332C2.26192 1.07399 2.87396 0.742013 3.53502 0.549886C4.34237 0.314234 5.19223 0.262331 6.02226 0.397987C6.85229 0.533642 7.64143 0.85342 8.33175 1.33384C9.08289 1.89515 9.68508 2.63192 10.0857 3.47975C10.5175 4.31021 10.8231 5.18716 11.2018 6.01762C11.536 6.84506 12.054 7.58567 12.7166 8.18347C13.0189 8.47409 13.3917 8.68086 13.7983 8.78339C14.2049 8.88592 14.6313 8.88064 15.0352 8.7681C15.9067 8.44143 16.6499 7.84273 17.1545 7.06068C17.7325 6.2568 18.1843 5.28018 18.8155 4.33678C19.1365 3.84764 19.5182 3.40117 19.9515 3.00804C20.4081 2.61118 20.9387 2.30862 21.5128 2.11779C22.1052 1.91517 22.7422 1.88068 23.3531 2.01814C23.9729 2.17131 24.5187 2.53834 24.8944 3.05455C25.5986 3.99795 25.8378 5.04765 26.4092 5.5725C26.6685 5.83263 27.0128 5.99065 27.3791 6.01762C27.7827 6.02071 28.1821 5.9345 28.5484 5.76517C29.3507 5.36762 30.1293 4.92396 30.8804 4.43644C31.658 3.99071 32.4823 3.632 33.3385 3.36681C34.8537 2.91365 36.4126 2.62192 37.9891 2.49649C40.8459 2.25731 43.1379 2.18423 44.7324 2.1045C45.5574 2.02614 46.3885 2.03952 47.2105 2.14437Z"
                                                            fill="white" />
                                                        <path
                                                            d="M45.4762 6.2697C45.4231 6.13018 46.1406 5.7382 47.2235 5.08712C47.7683 4.76158 48.4127 4.36296 49.1036 3.89126C49.4491 3.65873 49.768 3.39963 50.1666 3.13388C50.3373 3.0178 50.4954 2.88421 50.6383 2.73527C50.7579 2.61795 50.8527 2.47789 50.9173 2.32336C50.9506 2.19713 50.9173 2.20377 50.9173 2.15726C50.821 2.06916 50.7009 2.01139 50.5719 1.99117L49.283 1.64571C48.4592 1.41982 47.7218 1.20058 47.1039 0.981341C45.8682 0.582721 45.1108 0.263819 45.1573 0.124302C45.2038 -0.0152149 46.001 0.0379361 47.2833 0.250534C47.9476 0.356832 48.6784 0.502993 49.5155 0.675728L50.8443 0.968051C51.184 1.02987 51.4955 1.19726 51.7345 1.4464C51.8826 1.61431 51.9774 1.82242 52.0069 2.04432C52.0341 2.24825 52.0113 2.45574 51.9405 2.6489C51.8291 2.94985 51.6521 3.2222 51.4223 3.44614C51.235 3.63879 51.0254 3.80831 50.7978 3.95105C50.4124 4.23009 50.0205 4.47591 49.6484 4.70179C48.9845 5.09883 48.2916 5.44528 47.5756 5.7382C46.3399 6.25641 45.5294 6.40257 45.4762 6.2697Z"
                                                            fill="white" />
                                                    </g>
                                                    <defs>
                                                        <clipPath id="clip0_3800_516">
                                                            <rect width="52" height="9.86585" fill="white"
                                                                transform="translate(0 0.0664062)" />
                                                        </clipPath>
                                                    </defs>
                                                </svg>
                                            </h6>
                                            <?php endif; ?>
                                            <?php if ( !empty($settings['rr_fact_title' ]) ) :
                                        printf( '<%1$s %2$s>%3$s</%1$s>',
                                        tag_escape( $settings['rr_fact_title_tag'] ),
                                        $this->get_render_attribute_string( 'title_args' ),
                                        rr_kses( $settings['rr_fact_title' ] )
                                        );  
                                        endif; ?>
                                            <?php if ( !empty($settings['rr_fact_description']) ) : ?>
                                            <p class="counter2__paragraph coustom__paragraph mt-15 wow fadeInLeft animated rr-el-desc"
                                                data-wow-delay=".4s">
                                                <?php echo rr_kses( $settings['rr_fact_description'] ); ?></p>
                                            <?php endif; ?>
                                        </div>

                                    </div>
                                </div>
                                <div class="col-xl-7">
                                    <div class="container counter2__count">
                                        <div class="row counter2__gap1">
                                            <?php foreach ($settings['rr_fact_list'] as $key => $item) :
                                                $arrCount = count($settings['rr_fact_list']) - 1 ;
                                                $border = $key == $arrCount ? '' : 'rr-counter-border';
                                            ?>
                                            <div class="col-xl-6 col-lg-6 col-md-6 col-12">
                                                <div class="counter2__item counter2__item-<?php echo $key+1; ?> ">
                                                    <div class="counter2__item-icon rr-el-rep-icon">
                                                        <?php if($item['rr_box_icon_type'] == 'icon') : ?>
                                                        <?php if (!empty($item['rr_box_icon']) || !empty($item['rr_box_selected_icon']['value'])) : ?>
                                                        <span>
                                                            <?php rr_render_icon($item, 'rr_box_icon', 'rr_box_selected_icon'); ?>
                                                        </span>
                                                        <?php endif; ?>
                                                        <?php elseif( $item['rr_box_icon_type'] == 'image' ) : ?>
                                                        <?php if (!empty($item['rr_box_icon_image']['url'])): ?>
                                                        <span>
                                                            <img src="<?php echo $item['rr_box_icon_image']['url']; ?>"
                                                                alt="<?php echo get_post_meta(attachment_url_to_postid($item['rr_box_icon_image']['url']), '_wp_attachment_image_alt', true); ?>">
                                                        </span>
                                                        <?php endif; ?>
                                                        <?php else : ?>
                                                        <?php if (!empty($item['rr_box_icon_svg'])): ?>
                                                        <div
                                                            class="contact-inner-img">
                                                            <?php echo $item['rr_box_icon_svg']; ?>
                                                        </div>
                                                        <?php endif; ?>
                                                        <?php endif; ?>
                                                    </div>
                                                    <div class="counter2__item-count">
                                                        <h3 class="counter2__item-count-title rr-el-re-number"><span
                                                                class="odometer"
                                                                data-count="<?php echo rr_kses($item['rr_fact_number' ]); ?>">0</span><?php echo rr_kses($item['rr_fact_number_unit']);?>
                                                        </h3>
                                                        <?php if(!empty($item['rr_fact_title'])) : ?>
                                                        <p class="rr-el-re-Title">
                                                            <?php echo rr_kses($item['rr_fact_title']); ?></p>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                            </div>
                                            <?php endforeach; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php elseif ( $settings['rr_design_style']  == 'layout-3' ): 
    $this->add_render_attribute('title_args', 'class', 'section__title-wrapper-title coustom__title text-white wow fadeInLeft animated rr-el-title ');
    if ( !empty($settings['rr_thumbnail_image']['url']) ) {
        $rr_thumbnail_image = !empty($settings['rr_thumbnail_image']['id']) ? wp_get_attachment_image_url( $settings['rr_thumbnail_image']['id'], $settings['rr_image_size_size']) : $settings['rr_thumbnail_image']['url'];
        $rr_image_alt = get_post_meta($settings["rr_thumbnail_image"]["id"], "_wp_attachment_image_alt", true);
    }
?>

<section class="cta__area section-space p-relative overflow-hidden rr-el-section">
    <div class="container">
        <div class="row">
            <div class="col-xl-6">
                <div class="cta__thumb p-relative wow fadeInLeft animated" data-wow-delay=".2s">
                    <a href="<?php echo esc_url($settings['rr_video_url']['url']); ?>"
                        class="popup-video cta__media-icon zooming">
                        <svg width="37" height="41" viewBox="0 0 37 41" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path
                                d="M1.80401 4.94356C1.80401 2.63415 4.30401 1.19078 6.30401 2.34548L33.8322 18.2389C35.8322 19.3936 35.8322 22.2803 33.8322 23.435L6.30401 39.3284C4.30401 40.4831 1.80401 39.0397 1.80401 36.7303L1.80401 4.94356Z"
                                stroke="white" stroke-width="2" />
                        </svg>
                    </a>
                    <?php if(!empty($rr_thumbnail_image)) : ?>
                    <img src="<?php echo esc_url($rr_thumbnail_image); ?>" alt="<?php echo esc_attr($rr_image_alt); ?>">
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-xl-6">
                <div class=" container cta__counter">
                    <div class="row cta__item">
                        <?php foreach ($settings['rr_fact_list'] as $key => $item) :
                            $arrCount = count($settings['rr_fact_list']) - 1 ;
                            $border = $key == $arrCount ? '' : 'rr-counter-border';
                        ?>
                        <div class="col-md-6 col-12">
                            <div class="cta__box counter2__item-<?php echo $key+1; ?>">
                                <div class="cta__box-icon rr-el-rep-icon">
                                    <?php if($item['rr_box_icon_type'] == 'icon') : ?>
                                    <?php if (!empty($item['rr_box_icon']) || !empty($item['rr_box_selected_icon']['value'])) : ?>
                                    <span>
                                        <?php rr_render_icon($item, 'rr_box_icon', 'rr_box_selected_icon'); ?>
                                    </span>
                                    <?php endif; ?>
                                    <?php elseif( $item['rr_box_icon_type'] == 'image' ) : ?>
                                    <?php if (!empty($item['rr_box_icon_image']['url'])): ?>
                                    <span>
                                        <img src="<?php echo $item['rr_box_icon_image']['url']; ?>"
                                            alt="<?php echo get_post_meta(attachment_url_to_postid($item['rr_box_icon_image']['url']), '_wp_attachment_image_alt', true); ?>">
                                    </span>
                                    <?php endif; ?>
                                    <?php else : ?>
                                    <?php if (!empty($item['rr_box_icon_svg'])): ?>
                                    <div class="contact-inner-img">
                                        <?php echo $item['rr_box_icon_svg']; ?>
                                    </div>
                                    <?php endif; ?>
                                    <?php endif; ?>
                                </div>
                                <div class="cta__box-text">
                                    <h3 class="cta__count-title rr-el-re-number"><span class="odometer"
                                            data-count="<?php echo rr_kses($item['rr_fact_number' ]); ?>">0</span><?php echo rr_kses($item['rr_fact_number_unit']);?>
                                    </h3>
                                    <?php if(!empty($item['rr_fact_title'])) : ?>
                                    <p class="rr-el-re-Title">
                                        <?php echo rr_kses($item['rr_fact_title']); ?></p>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php elseif ( $settings['rr_design_style']  == 'layout-4' ): 
    $this->add_render_attribute('title_args', 'class', 'section__title-wrapper-title coustom__title text-white wow fadeInLeft animated rr-el-title ');
    if ( !empty($settings['rr_thumbnail_image']['url']) ) {
        $rr_thumbnail_image = !empty($settings['rr_thumbnail_image']['id']) ? wp_get_attachment_image_url( $settings['rr_thumbnail_image']['id'], $settings['rr_image_size_size']) : $settings['rr_thumbnail_image']['url'];
        $rr_image_alt = get_post_meta($settings["rr_thumbnail_image"]["id"], "_wp_attachment_image_alt", true);
    }
?>
<section
    class="latest-counter__area overflow-hidden p-relative z-1 pt-100 pb-90 pt-xs-30 pb-xs-60 latest-counter-bg rr-el-section">
    <div class="latest-counter__shapes">
        <div class="shape-1 upDown">
            <img src="<?php echo get_template_directory_uri(  ); ?>/assets/imgs/home-5/counter-plane-img.png"
                alt="img not found">
        </div>
        <div class="shape-2">
            <img src="<?php echo get_template_directory_uri(  ); ?>/assets/imgs/home-5/counter-bg-shape.png"
                alt="img not found">
        </div>
    </div>
    <div class="container">
        <div class="row">
            <?php foreach ($settings['rr_fact_list'] as $key => $item) :
                    $arrCount = count($settings['rr_fact_list']) - 1 ;
                    $border = $key == $arrCount ? '' : 'rr-counter-border';
                ?>
            <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6">
                <div class="latest-counter__counter-box wow fadeInLeft animated" data-wow-delay="1s">
                    <div class="latest-counter__content text-center">
                        <div class="latest-counter__content__counter-img img-1 mt-40">
                            <?php if($item['rr_box_icon_type'] == 'icon') : ?>
                            <?php if (!empty($item['rr_box_icon']) || !empty($item['rr_box_selected_icon']['value'])) : ?>
                            <span class="rr-el-rep-icon">
                                <?php rr_render_icon($item, 'rr_box_icon', 'rr_box_selected_icon'); ?>
                            </span>
                            <?php endif; ?>
                            <?php elseif( $item['rr_box_icon_type'] == 'image' ) : ?>
                            <?php if (!empty($item['rr_box_icon_image']['url'])): ?>
                            <span class="rr-el-rep-icon">
                                <img src="<?php echo $item['rr_box_icon_image']['url']; ?>"
                                    alt="<?php echo get_post_meta(attachment_url_to_postid($item['rr_box_icon_image']['url']), '_wp_attachment_image_alt', true); ?>">
                            </span>
                            <?php endif; ?>
                            <?php else : ?>
                            <?php if (!empty($item['rr_box_icon_svg'])): ?>
                            <div class="contact-inner-img rr-el-rep-icon">
                                <?php echo $item['rr_box_icon_svg']; ?>
                            </div>
                            <?php endif; ?>
                            <?php endif; ?>
                        </div>
                        <h5><span class="odometer rr-el-re-number"
                                data-count="<?php echo rr_kses($item['rr_fact_number' ]); ?>">0</span><?php echo rr_kses($item['rr_fact_number_unit']);?>
                        </h5>
                        <?php if(!empty($item['rr_fact_title'])) : ?>
                        <span class="rr-el-re-Title rr-el-title"><?php echo rr_kses($item['rr_fact_title']); ?></span>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>
<?php else: 
    if ( !empty($settings['rr_image']['url']) ) {
        $rr_image = !empty($settings['rr_image']['id']) ? wp_get_attachment_image_url( $settings['rr_image']['id'], $settings['rr_image_size_size']) : $settings['rr_image']['url'];
        $rr_image_alt = get_post_meta($settings["rr_image"]["id"], "_wp_attachment_image_alt", true);
    }
    if ( !empty($settings['rr_fact_info_image']['url']) ) {
        $rr_image_2 = !empty($settings['rr_fact_info_image']['id']) ? wp_get_attachment_image_url( $settings['rr_fact_info_image']['id'], $settings['rr_img_size_size']) : $settings['rr_fact_info_image']['url'];
        $rr_image_alt = get_post_meta($settings["rr_fact_info_image"]["id"], "_wp_attachment_image_alt", true);
    }
        // Link
        if ('2' == $settings['rr_fact_btn_link_type']) {
            $this->add_render_attribute('rr-button-arg', 'href', get_permalink($settings['rr_fact_btn_page_link']));
            $this->add_render_attribute('rr-button-arg', 'target', '_self');
            $this->add_render_attribute('rr-button-arg', 'rel', 'nofollow');
            $this->add_render_attribute('rr-button-arg', 'class', 'rr-btn2 mt-25 wow fadeInLeft animated rr-el-btn');
        } else {
            if ( ! empty( $settings['rr_fact_btn_link']['url'] ) ) {
                $this->add_link_attributes( 'rr-button-arg', $settings['rr_fact_btn_link'] );
                $this->add_render_attribute('rr-button-arg', 'class', 'rr-btn2 mt-25 wow fadeInLeft animated rr-el-btn');
            }
        }
    $this->add_render_attribute('title_args', 'class', 'rr-section-title pb-15');

?>
<section class="section-space counter gray-bg position-relative overflow-hidden rr-el-section">
    <div class="faq__area">
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <div class="faq__media" data-tilt>
                        <?php if(!empty($rr_image)) : ?>
                        <img src="<?php echo esc_url($rr_image); ?>" alt="<?php echo esc_attr($rr_image_alt); ?>">
                        <?php endif; ?>
                    </div>
                </div>
                <div class="col-md-8">
                    <div class="faq__content white-bg d-flex faq-radius position-relative overflow-hidden">
                        <div class="faq__content-text faq-padding ">
                            <div class="faq__content-text-icon wow fadeInLeft animated rr-el-rep-icon"
                                data-wow-delay=".2s">
                                <?php if($settings['rr_box_icon_type_2'] == 'icon') : ?>
                                <?php if (!empty($settings['rr_box_icon_2']) || !empty($settings['rr_box_selected_icon_2']['value'])) : ?>
                                <span>
                                    <?php rr_render_icon($settings, 'rr_box_icon_2', 'rr_box_selected_icon_2'); ?>
                                </span>
                                <?php endif; ?>
                                <?php elseif( $settings['rr_box_icon_type_2'] == 'image' ) : ?>
                                <?php if (!empty($settings['rr_box_icon_image_2']['url'])): ?>
                                <span>
                                    <img src="<?php echo $settings['rr_box_icon_image_2']['url']; ?>"
                                        alt="<?php echo get_post_meta(attachment_url_to_postid($settings['rr_box_icon_image_2']['url']), '_wp_attachment_image_alt', true); ?>">
                                </span>
                                <?php endif; ?>
                                <?php else : ?>
                                <?php if (!empty($settings['rr_box_icon_svg_2'])): ?>
                                <div class="contact-inner-img">
                                    <?php echo $settings['rr_box_icon_svg_2']; ?>
                                </div>
                                <?php endif; ?>
                                <?php endif; ?>
                            </div>
                            <?php if(!empty($settings['rr_fact_info_title'])) : ?>
                            <h5 class=" wow fadeInLeft animated rr-el-title" data-wow-delay=".3s">
                                <?php echo rr_kses($settings['rr_fact_info_title']);?></h5>
                            <?php endif; ?>
                            <?php if(!empty($settings['rr_fact_info_desc'])) : ?>
                            <p class=" wow fadeInLeft animated rr-el-desc" data-wow-delay=".4s">
                                <?php echo rr_kses($settings['rr_fact_info_desc']);?></p>
                            <?php endif; ?>
                            <a <?php echo $this->get_render_attribute_string( 'rr-button-arg' ); ?>
                                data-wow-delay=".5s"><?php echo rr_kses($settings['rr_fact_btn_text']); ?> <i
                                    class="fa-solid fa-arrow-right"></i></a>
                        </div>
                        <div class="faq__content-right-img  wow fadeInLeft animated" data-wow-delay=".6s">
                            <?php if(!empty($rr_image_2)) : ?>
                            <img src="<?php echo esc_url($rr_image_2); ?>" alt="<?php echo esc_attr($rr_image_alt); ?>">
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="row counter__bg mt-30 mb-minus-20">
                        <?php foreach ($settings['rr_fact_list'] as $key => $item) :
                            $arrCount = count($settings['rr_fact_list']) - 1 ;
                            $border = $key == $arrCount ? '' : 'rr-counter-border';
                        ?>
                        <div class="col-xl-3 col-lg-6 col-md-6 col-sm-6">
                            <div class="counter__item">
                                <h3 class="counter__item-title rr-el-re-number"><span class="odometer"
                                        data-count="<?php echo rr_kses($item['rr_fact_number' ]); ?>">0</span><?php echo rr_kses($item['rr_fact_number_unit']);?>
                                </h3>
                                <?php if(!empty($item['rr_fact_title'])) : ?>
                                <p class="rr-el-re-Title"><?php echo rr_kses($item['rr_fact_title']); ?></p>
                                <?php endif; ?>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php endif; 
	}
}

$widgets_manager->register( new rr_Fact() );