<?php
namespace RRCore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Repeater;
use \Elementor\Utils;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * RR Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class rr_Contact_Info extends Widget_Base {

    use \RRCore\Widgets\RRCoreElementFunctions;

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'rr-contact-info';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Contact Info', 'rr-core' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'rr-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'rr-core' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'rr-core' ];
	}

    /**
         * contact form 7 setup.
         *
         * Adds different input fields to allow the user to change and customize the widget settings.
         *
         * @since 1.0.0
         *
         * @access protected
         */

         public function get_rr_contact_form(){
            if ( ! class_exists( 'WPCF7' ) ) {
                return;
            }
            $rr_cfa         = array();
            $rr_cf_args     = array( 'posts_per_page' => -1, 'post_type'=> 'wpcf7_contact_form' );
            $rr_forms       = get_posts( $rr_cf_args );
            $rr_cfa         = ['0' => esc_html__( 'Select Form', 'rr-core' ) ];
            if( $rr_forms ){
                foreach ( $rr_forms as $rr_form ){
                    $rr_cfa[$rr_form->ID] = $rr_form->post_title;
                }
            }else{
                $rr_cfa[ esc_html__( 'No contact form found', 'rr-core' ) ] = 0;
            }
            return $rr_cfa;
        }
    
  /**
     * Register the widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     *
     * @access protected
     */


    protected static function get_profile_names()
    {
        return [
            'apple' => esc_html__('Apple', 'rr-core'),
            'behance' => esc_html__('Behance', 'rr-core'),
            'bitbucket' => esc_html__('BitBucket', 'rr-core'),
            'codepen' => esc_html__('CodePen', 'rr-core'),
            'delicious' => esc_html__('Delicious', 'rr-core'),
            'deviantart' => esc_html__('DeviantArt', 'rr-core'),
            'digg' => esc_html__('Digg', 'rr-core'),
            'dribbble' => esc_html__('Dribbble', 'rr-core'),
            'email' => esc_html__('Email', 'rr-core'),
            'facebook-f' => esc_html__('Facebook', 'rr-core'),
            'flickr' => esc_html__('Flicker', 'rr-core'),
            'foursquare' => esc_html__('FourSquare', 'rr-core'),
            'github' => esc_html__('Github', 'rr-core'),
            'houzz' => esc_html__('Houzz', 'rr-core'),
            'instagram' => esc_html__('Instagram', 'rr-core'),
            'jsfiddle' => esc_html__('JS Fiddle', 'rr-core'),
            'linkedin-in' => esc_html__('LinkedIn', 'rr-core'),
            'medium' => esc_html__('Medium', 'rr-core'),
            'pinterest' => esc_html__('Pinterest', 'rr-core'),
            'product-hunt' => esc_html__('Product Hunt', 'rr-core'),
            'reddit' => esc_html__('Reddit', 'rr-core'),
            'slideshare' => esc_html__('Slide Share', 'rr-core'),
            'snapchat' => esc_html__('Snapchat', 'rr-core'),
            'soundcloud' => esc_html__('SoundCloud', 'rr-core'),
            'spotify' => esc_html__('Spotify', 'rr-core'),
            'stack-overflow' => esc_html__('StackOverflow', 'rr-core'),
            'tripadvisor' => esc_html__('TripAdvisor', 'rr-core'),
            'tumblr' => esc_html__('Tumblr', 'rr-core'),
            'twitch' => esc_html__('Twitch', 'rr-core'),
            'twitter' => esc_html__('Twitter', 'rr-core'),
            'vimeo' => esc_html__('Vimeo', 'rr-core'),
            'vk' => esc_html__('VK', 'rr-core'),
            'website' => esc_html__('Website', 'rr-core'),
            'whatsapp' => esc_html__('WhatsApp', 'rr-core'),
            'wordpress' => esc_html__('WordPress', 'rr-core'),
            'xing' => esc_html__('Xing', 'rr-core'),
            'yelp' => esc_html__('Yelp', 'rr-core'),
            'youtube' => esc_html__('YouTube', 'rr-core'),
        ];
    }
    
	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */

    protected function register_controls(){
        $this->register_controls_section();
        $this->style_tab_content();
    }  


	protected function register_controls_section() {

        // layout Panel
        $this->start_controls_section(
            'rr_layout',
            [
                'label' => esc_html__('Design Layout', 'rr-core'),
            ]
        );
        $this->add_control(
            'rr_design_style',
            [
                'label' => esc_html__('Select Layout', 'rr-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Layout 1', 'rr-core'),
                    'layout-2' => esc_html__('Layout 2', 'rr-core'),
                ],
                'default' => 'layout-1',
            ]
        );

        $this->end_controls_section();

        $this->rr_section_title_render_controls('contact', 'Section Title', 'Sub Title', 'your title here', $default_description = 'Hic nesciunt galisum aut dolorem aperiam eum soluta quod ea cupiditate.', ['layout-1']);

        // Service group
        $this->start_controls_section(
            '_TP_contact_info',
            [
                'label' => esc_html__('Contact  List', 'tpcore'),
                'description' => esc_html__( 'Control all the style settings from Style tab', 'tpcore' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'repeater_condition',
            [
                'label' => __( 'Field condition', 'tpcore' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'style_1' => __( 'Style 1', 'tpcore' ),
                ],
                'default' => 'style_1',
                'frontend_available' => true,
                'style_transfer' => true,
            ]
        );

        $repeater->add_control(
            'rr_box_icon_type',
            [
                'label' => esc_html__('Select Icon Type', 'tpcore'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'icon',
                'options' => [
                    'image' => esc_html__('Image', 'tpcore'),
                    'icon' => esc_html__('Icon', 'tpcore'),
                    'svg' => esc_html__('SVG', 'tpcore'),
                ],

            ]
        );
        $repeater->add_control(
            'rr_box_icon_svg',
            [
                'show_label' => false,
                'type' => Controls_Manager::TEXTAREA,
                'label_block' => true,
                'placeholder' => esc_html__('SVG Code Here', 'tpcore'),
                'condition' => [
                    'rr_box_icon_type' => 'svg'
                ]
            ]
        );

        $repeater->add_control(
            'rr_box_icon_image',
            [
                'label' => esc_html__('Upload Icon Image', 'tpcore'),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
                'condition' => [
                    'rr_box_icon_type' => 'image',
                ]
            ]
        );

        if (rr_is_elementor_version('<', '2.6.0')) {
            $repeater->add_control(
                'rr_box_icon',
                [
                    'show_label' => false,
                    'type' => Controls_Manager::ICON,
                    'label_block' => true,
                    'default' => 'fa fa-star',
                    'condition' => [
                        'rr_box_icon_type' => 'icon'
                    ]
                ]
            );
        } else {
            $repeater->add_control(
                'rr_box_selected_icon',
                [
                    'show_label' => false,
                    'type' => Controls_Manager::ICONS,
                    'fa4compatibility' => 'icon',
                    'label_block' => true,
                    'default' => [
                        'value' => 'fas fa-star',
                        'library' => 'solid',
                    ],
                    'condition' => [
                        'rr_box_icon_type' => 'icon'
                    ]
                ]
            );
        }

        $repeater->add_control(
            'rr_contact_text_label',
            [
                'label' => esc_html__('Label', 'tpcore'),
                'description' => rr_get_allowed_html_desc( 'intermediate' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'Label Here',
                'label_block' => true,
            ]
        );  
        $repeater->add_control(
            'rr_contact_info_title',
            [
                'label' => esc_html__('Title', 'tpcore'),
                'description' => rr_get_allowed_html_desc( 'intermediate' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'Title Here',
                'label_block' => true,
            ]
        );  

        $repeater->add_control(
            'link_type',
            [
                'label' => __( 'Link Type', 'tpcore' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    '' => __( 'None', 'tpcore' ),
                    'url' => __( 'URL', 'tpcore' ),
                    'tell' => __( 'Phone Number', 'tpcore' ),
                    'email' => __( 'Email', 'tpcore' ),
                ],
                'default' => '',
                'frontend_available' => true,
                'style_transfer' => true,
            ]
        );

        // url
        $repeater->add_control(
            'rr_contact_url',
            [
                'label' => esc_html__('URL', 'tpcore'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => '#',
                'label_block' => true,
                'condition' => [
                    'link_type' => 'url'
                ]
            ]
        );  

        // tell
        $repeater->add_control(
            'rr_contact_tell',
            [
                'label' => esc_html__('Phone Number', 'tpcore'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => '012345',
                'label_block' => true,
                'condition' => [
                    'link_type' => 'tell'
                ]
            ]
        );  

        // email
        $repeater->add_control(
            'rr_contact_email',
            [
                'label' => esc_html__('Email Address', 'tpcore'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('technix@gmail.com', 'tpcore'),
                'label_block' => true,
                'condition' => [
                    'link_type' => 'email'
                ]
            ]
        );  

        $this->add_control(
            'rr_list',
            [
                'label' => esc_html__('Contact - List', 'tpcore'),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'rr_contact_info_title' => esc_html__('united states', 'tpcore'),
                    ],
                    [
                        'rr_contact_info_title' => esc_html__('south Africa', 'tpcore')
                    ],
                    [
                        'rr_contact_info_title' => esc_html__('United Kingdom', 'tpcore')
                    ]
                ],
                'title_field' => '{{{ rr_contact_info_title }}}',
            ]
        );
        $this->end_controls_section();
        
        $this->start_controls_section(
            'rr-core_contact',
            [
                'label' => esc_html__('Contact Form', 'rr-core'),
                'condition' => [
                    'rr_design_style' => 'layout-1'
                ]
            ]
        );

        $this->add_control(
            'rr-core_select_contact_form',
            [
                'label'   => esc_html__( 'Select Form', 'rr-core' ),
                'type'    => Controls_Manager::SELECT,
                'default' => '0',
                'options' => $this->get_rr_contact_form(),
            ]
        );

        $this->
        end_controls_section(); 
        // _rr_image
        $this->start_controls_section(
            '_rr_image',
            [
                'label' => esc_html__('Thumbnail', 'rr-core'),
            ]
        );
        $this->add_control(
            'rr_image',
            [
                'label' => esc_html__( 'Choose Image', 'rr-core' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        ); 

        $this->add_group_control(
            Group_Control_Image_Size::get_type(),
            [
                'name' => 'rr_image_size',
                'default' => 'full',
                'exclude' => [
                    'custom'
                ]
            ]
        );

        $this->end_controls_section();
         // Service group
         $this->start_controls_section(
            '_TP_contact_info_2',
            [
                'label' => esc_html__('Contact  List 02', 'tpcore'),
                'description' => esc_html__( 'Control all the style settings from Style tab', 'tpcore' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
                'condition' => [
                    'rr_design_style' => 'layout-2'
                ]
            ]
        );

        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'repeater_condition_2',
            [
                'label' => __( 'Field condition', 'tpcore' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'style_1' => __( 'Style 1', 'tpcore' ),
                ],
                'default' => 'style_1',
                'frontend_available' => true,
                'style_transfer' => true,
            ]
        );

        $repeater->add_control(
            'rr_box_icon_type_2',
            [
                'label' => esc_html__('Select Icon Type', 'tpcore'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'icon',
                'options' => [
                    'image' => esc_html__('Image', 'tpcore'),
                    'icon' => esc_html__('Icon', 'tpcore'),
                    'svg' => esc_html__('SVG', 'tpcore'),
                ],

            ]
        );
        $repeater->add_control(
            'rr_box_icon_svg_2',
            [
                'show_label' => false,
                'type' => Controls_Manager::TEXTAREA,
                'label_block' => true,
                'placeholder' => esc_html__('SVG Code Here', 'tpcore'),
                'condition' => [
                    'rr_box_icon_type_2' => 'svg'
                ]
            ]
        );

        $repeater->add_control(
            'rr_box_icon_image_2',
            [
                'label' => esc_html__('Upload Icon Image', 'tpcore'),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
                'condition' => [
                    'rr_box_icon_type_2' => 'image',
                ]
            ]
        );

        if (rr_is_elementor_version('<', '2.6.0')) {
            $repeater->add_control(
                'rr_box_icon_2',
                [
                    'show_label' => false,
                    'type' => Controls_Manager::ICON,
                    'label_block' => true,
                    'default' => 'fa fa-star',
                    'condition' => [
                        'rr_box_icon_type_2' => 'icon'
                    ]
                ]
            );
        } else {
            $repeater->add_control(
                'rr_box_selected_icon_2',
                [
                    'show_label' => false,
                    'type' => Controls_Manager::ICONS,
                    'fa4compatibility' => 'icon',
                    'label_block' => true,
                    'default' => [
                        'value' => 'fas fa-star',
                        'library' => 'solid',
                    ],
                    'condition' => [
                        'rr_box_icon_type_2' => 'icon'
                    ]
                ]
            );
        }

        $repeater->add_control(
            'rr_contact_text_label_2',
            [
                'label' => esc_html__('Label', 'tpcore'),
                'description' => rr_get_allowed_html_desc( 'intermediate' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'Label Here',
                'label_block' => true,
            ]
        );  
        $repeater->add_control(
            'rr_contact_info_title_2',
            [
                'label' => esc_html__('Title', 'tpcore'),
                'description' => rr_get_allowed_html_desc( 'intermediate' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'Title Here',
                'label_block' => true,
            ]
        );  

        $this->add_control(
            'rr_list_2',
            [
                'label' => esc_html__('Contact - List', 'tpcore'),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'rr_contact_info_title_2' => esc_html__('united states', 'tpcore'),
                    ],
                    [
                        'rr_contact_info_title_2' => esc_html__('south Africa', 'tpcore')
                    ],
                    [
                        'rr_contact_info_title_2' => esc_html__('United Kingdom', 'tpcore')
                    ]
                ],
                'title_field' => '{{{ rr_contact_info_title_2 }}}',
            ]
        );
        $this->end_controls_section();
        
	}

    // TAB_STYLE
    protected function style_tab_content(){
        $this->rr_section_style_controls('section_info', 'Section - Style', '.rr-el-section');
        $this->rr_basic_style_controls('contact_subtitle', 'contact - Sub Title', '.rr-el-subtitle');
        $this->rr_basic_style_controls('section_title', 'Section - Title', '.rr-el-title');
        $this->rr_basic_style_controls('contact_desc', 'contact - Description', '.rr-el-desc');
        $this->rr_basic_style_controls('contact_lebel', 'contact - Lebel', '.rr-el-lebel');
        $this->rr_basic_style_controls('contact_title', 'contact - Title', '.rr-el-text');
        $this->rr_section_style_controls('comint_section_box', 'Contact - Box', '.rr-el-box');
    }

	/**
	 * Render the widget ouRRut on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0 
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
        $this->add_render_attribute('title_args', 'class', 'latest-contact-us-2__title-wrapper-title wow fadeIn  animated rr-el-title');
		?>

<?php if ( $settings['rr_design_style']  == 'layout-2' ) :
    if ( !empty($settings['rr_image']['url']) ) {
        $rr_image = !empty($settings['rr_image']['id']) ? wp_get_attachment_image_url( $settings['rr_image']['id'], $settings['rr_image_size_size']) : $settings['rr_image']['url'];
        $rr_image_alt = get_post_meta($settings["rr_image"]["id"], "_wp_attachment_image_alt", true);
    }    
?>
<div class="tab-pane active fade show rr-el-section" id="nav-0" role="tabpanel" aria-labelledby="nav-0-tab" tabindex="0">
    <div class="rr-fea-product d-flex justify-content-between">
        <div class="media-content has--line wow fadeInLeft animated" data-wow-delay=".2s">
            <?php foreach ($settings['rr_list'] as $key => $item) :

            $key = $key+1;
            $link_type = $item['link_type'];
            $url = $item['rr_contact_url'];
            $tell = $item['rr_contact_tell'];
            $email = $item['rr_contact_email'];
            $contact_link;

            if($link_type == 'url'){
                $contact_link = $url;
            } elseif($link_type == 'tell'){
                $contact_link = 'tel:'.$tell;
            } elseif($link_type == 'email'){
                $contact_link = 'mailto:'.$email;
            }
            ?>

            <div class="latest-contact-us-2-media-content-contact">
                <div class="latest-contact-us-2-media-content-contact-icon">
                    <?php if($item['rr_box_icon_type'] == 'icon') : ?>
                    <?php if (!empty($item['rr_box_icon']) || !empty($item['rr_box_selected_icon']['value'])) : ?>
                    <span>
                        <?php rr_render_icon($item, 'rr_box_icon', 'rr_box_selected_icon'); ?>
                    </span>
                    <?php endif; ?>
                    <?php elseif( $item['rr_box_icon_type'] == 'image' ) : ?>
                    <?php if (!empty($item['rr_box_icon_image']['url'])): ?>
                    <span>
                        <img src="<?php echo $item['rr_box_icon_image']['url']; ?>"
                            alt="<?php echo get_post_meta(attachment_url_to_postid($item['rr_box_icon_image']['url']), '_wp_attachment_image_alt', true); ?>">
                    </span>
                    <?php endif; ?>
                    <?php else : ?>
                    <?php if (!empty($item['rr_box_icon_svg'])): ?>
                    <div class="contact-inner-img  ">
                        <?php echo $item['rr_box_icon_svg']; ?>
                    </div>
                    <?php endif; ?>
                    <?php endif; ?>
                </div>
                <div class="latest-contact-us-2-media-content-contact">
                    <div class="latest-contact-us-2-media-content-contact-text">
                        <?php if ( !empty($item['rr_contact_text_label']) ) : ?>
                        <span class="rr-el-lebel"><?php echo rr_kses($item['rr_contact_text_label']);?></span><br>
                        <?php endif; ?>

                        <?php if(!empty($item['rr_contact_info_title'])) : ?>
                        <?php if(!empty($item['link_type'])) : ?>
                        <a class="rr-el-text"
                            href="<?php echo esc_url($contact_link); ?>"><?php echo rr_kses($item['rr_contact_info_title']); ?></a>
                        <?php else : ?>
                        <h6 class="rr-el-text"><?php echo rr_kses($item['rr_contact_info_title']); ?></h6>
                        <?php endif; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        <div class="media-content wow fadeInLeft animated" data-wow-delay=".3s">
            <?php foreach ($settings['rr_list_2'] as $key => $item) :

            ?>
            <div class="latest-contact-us-2-media-content-contact">
                <div class="latest-contact-us-2-media-content-contact-text">
                    <?php if ( !empty($item['rr_contact_text_label_2']) ) : ?>
                        <span class="rr-el-lebel"><?php echo rr_kses($item['rr_contact_text_label_2']);?></span><br>
                    <?php endif; ?>
                    <?php if ( !empty($item['rr_contact_info_title_2']) ) : ?>
                    <h5 class="rr-el-text">
                        <svg width="20" height="21" viewBox="0 0 20 21" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path
                                d="M10 20.5C4.45312 20.5 0 16.0469 0 10.5C0 4.99219 4.45312 0.5 10 0.5C15.5078 0.5 20 4.99219 20 10.5C20 16.0469 15.5078 20.5 10 20.5ZM9.0625 10.5C9.0625 10.8125 9.21875 11.125 9.45312 11.2812L13.2031 13.7812C13.6328 14.0938 14.2188 13.9766 14.4922 13.5469C14.8047 13.1172 14.6875 12.5312 14.2578 12.2188L10.9375 10.0312V5.1875C10.9375 4.67969 10.5078 4.25 9.96094 4.25C9.45312 4.25 9.02344 4.67969 9.02344 5.1875L9.0625 10.5Z"
                                fill="#83CD20" />
                        </svg>
                        <?php echo rr_kses($item['rr_contact_info_title_2']); ?>
                    </h5>
                    <?php endif; ?>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        <div class="tab-content" data-tilt>
            <?php if(!empty($rr_image)) : ?>
            <img src="<?php echo esc_url($rr_image); ?>" alt="<?php echo esc_attr($rr_image_alt); ?>">
            <?php endif; ?>
        </div>
    </div>
</div>

<?php else:
    $this->add_render_attribute('title_args', 'class', 'section__title-wrapper-title-2 wow fadeInLeft rr-el-title');
?>
<section class="contact-info__area gray-bg section-space-bottom contact-us__area contact-us rr-el-section">
    <div class="container">
        <div class="row align-items-center row-reverse">
            <div class="col-xl-6 col-lg-6">
                <div class="contact-info__content contact-info__content-2">
                    <div class="section__title-wrapper mb-20">
                        <?php if ( !empty($settings['rr_contact_sub_title']) ) : ?>
                        <h6 class="section__title-wrapper-black-subtitle mb-10 wow fadeInLeft animated rr-el-subtitle"
                            data-wow-delay=".2s"><?php echo rr_kses( $settings['rr_contact_sub_title'] ); ?>
                            <svg width="49" height="10" viewBox="0 0 49 10" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <path
                                    d="M48.1773 2.01547C47.3774 2.23875 46.5552 2.37244 45.7258 2.41408L39.0422 3.13824C37.5302 3.31095 36.0391 3.63366 34.591 4.10158C33.8018 4.36723 33.0425 4.71459 32.3255 5.13799C31.5493 5.66103 30.7417 6.13584 29.9072 6.55973C29.4043 6.79511 28.8546 6.91324 28.2994 6.90521C27.6882 6.86965 27.1103 6.6149 26.6717 6.18769C25.828 5.31737 25.5955 4.26103 25.044 3.58337C24.8159 3.25061 24.4728 3.01397 24.0807 2.91901C23.6604 2.82583 23.2221 2.85581 22.8184 3.00537C21.9119 3.33508 21.1517 3.97532 20.6725 4.81245C20.0945 5.66948 19.6427 6.6461 18.985 7.56292C18.3449 8.54807 17.3963 9.29335 16.2877 9.68226C15.7058 9.84842 15.0891 9.84842 14.5072 9.68226C13.9559 9.51874 13.4476 9.23513 13.019 8.8518C12.2526 8.14844 11.6553 7.28083 11.2717 6.31391C10.8864 5.42366 10.6073 4.55998 10.222 3.80261C9.78014 2.76732 8.97778 1.92744 7.96375 1.43875C6.94972 0.95006 5.79286 0.845735 4.70777 1.14514C4.13142 1.29042 3.59268 1.55699 3.12755 1.92704C2.66241 2.29709 2.28157 2.76211 2.01044 3.29105C1.5768 4.10736 1.37028 5.02514 1.41249 5.94852C1.42914 6.54015 1.5553 7.12357 1.78456 7.66923C1.93736 8.05456 2.04366 8.24723 2.01044 8.2738C1.97722 8.30038 1.81777 8.13428 1.59189 7.76888C1.26577 7.22389 1.06387 6.61368 1.00059 5.98173C0.873351 4.97077 1.03939 3.94455 1.47894 3.0253C1.76675 2.39994 2.18562 1.84375 2.70717 1.39442C3.22871 0.945084 3.84076 0.613107 4.50182 0.42098C5.30917 0.185328 6.15903 0.133425 6.98906 0.26908C7.81909 0.404736 8.60823 0.724514 9.29855 1.20494C10.0497 1.76624 10.6519 2.50302 11.0525 3.35084C11.4843 4.1813 11.7899 5.05826 12.1686 5.88872C12.5028 6.71615 13.0208 7.45677 13.6834 8.05456C13.9856 8.34518 14.3585 8.55196 14.7651 8.65448C15.1717 8.75701 15.5981 8.75174 16.002 8.6392C16.8735 8.31252 17.6167 7.71383 18.1213 6.93178C18.6993 6.12789 19.1511 5.15127 19.7823 4.20787C20.1033 3.71873 20.485 3.27226 20.9183 2.87914C21.3749 2.48228 21.9055 2.17971 22.4796 1.98889C23.072 1.78627 23.709 1.75178 24.3199 1.88924C24.9397 2.04241 25.4855 2.40944 25.8612 2.92565C26.5654 3.86905 26.8046 4.91874 27.376 5.44359C27.6353 5.70373 27.9796 5.86174 28.3459 5.88872C28.7495 5.8918 29.1488 5.8056 29.5152 5.63626C30.3175 5.23871 31.0961 4.79506 31.8472 4.30753C32.6248 3.8618 33.4491 3.5031 34.3053 3.2379C35.8205 2.78474 37.3794 2.49301 38.9559 2.36758C41.8127 2.12841 44.1047 2.05532 45.6992 1.9756C46.5242 1.89723 47.3553 1.91061 48.1773 2.01547Z"
                                    fill="#034833" />
                            </svg>
                        </h6>
                        <?php endif; ?>
                        <?php if ( !empty($settings['rr_contact_title' ]) ) :
                        printf( '<%1$s %2$s>%3$s</%1$s>',
                        tag_escape( $settings['rr_contact_title_tag'] ),
                        $this->get_render_attribute_string( 'title_args' ),
                        rr_kses( $settings['rr_contact_title' ] )
                        );
                        endif;?>
                    </div>
                    <div class="contact-info__content-text wow fadeInLeft animated" data-wow-delay=".4s">
                        <?php if ( !empty($settings['rr_contact_description']) ) : ?>
                        <p class="rr-el-desc"><?php echo rr_kses( $settings['rr_contact_description'] ); ?></p>
                        <?php endif; ?>
                        <div class="contact-info__link mt-20">
                            <?php foreach ($settings['rr_list'] as $key => $item) :

                            $key = $key+1;

                            $link_type = $item['link_type'];
                            $url = $item['rr_contact_url'];
                            $tell = $item['rr_contact_tell'];
                            $email = $item['rr_contact_email'];

                            $contact_link;

                            if($link_type == 'url'){
                                $contact_link = $url;
                            } elseif($link_type == 'tell'){
                                $contact_link = 'tel:'.$tell;
                            } elseif($link_type == 'email'){
                                $contact_link = 'mailto:'.$email;
                            }

                            ?>
                            <div class="contact-info__link-phone">
                                <div class="contact-info__link-phone-icon">
                                    <?php if($item['rr_box_icon_type'] == 'icon') : ?>
                                    <?php if (!empty($item['rr_box_icon']) || !empty($item['rr_box_selected_icon']['value'])) : ?>
                                    <span>
                                        <?php rr_render_icon($item, 'rr_box_icon', 'rr_box_selected_icon'); ?>
                                    </span>
                                    <?php endif; ?>
                                    <?php elseif( $item['rr_box_icon_type'] == 'image' ) : ?>
                                    <?php if (!empty($item['rr_box_icon_image']['url'])): ?>
                                    <span>
                                        <img src="<?php echo $item['rr_box_icon_image']['url']; ?>"
                                            alt="<?php echo get_post_meta(attachment_url_to_postid($item['rr_box_icon_image']['url']), '_wp_attachment_image_alt', true); ?>">
                                    </span>
                                    <?php endif; ?>
                                    <?php else : ?>
                                    <?php if (!empty($item['rr_box_icon_svg'])): ?>
                                    <div class="contact-inner-img  ">
                                        <?php echo $item['rr_box_icon_svg']; ?>
                                    </div>
                                    <?php endif; ?>
                                    <?php endif; ?>
                                </div>
                                <div class="contact-info__link-phone-text">
                                    <?php if ( !empty($item['rr_contact_text_label']) ) : ?>
                                    <p class="rr-el-lebel"><?php echo rr_kses($item['rr_contact_text_label']);?></p>
                                    <?php endif; ?>

                                    <?php if(!empty($item['rr_contact_info_title'])) : ?>
                                    <?php if(!empty($item['link_type'])) : ?>
                                    <a class="rr-el-text"
                                        href="<?php echo esc_url($contact_link); ?>"><?php echo rr_kses($item['rr_contact_info_title']); ?></a>
                                    <?php else : ?>
                                    <h4 class="rr-el-text"><?php echo rr_kses($item['rr_contact_info_title']); ?></h4>
                                    <?php endif; ?>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-6 col-lg-6">
                <div class="contact-us__title-wrapper ">
                    <div class="contact-us__form-wrapper rr-el-box">
                        <?php if( !empty($settings['rr-core_select_contact_form']) ) : ?>
                        <?php echo do_shortcode( '[contact-form-7  id="'.$settings['rr-core_select_contact_form'].'"]' ); ?>
                        <?php else : ?>
                        <?php echo '<div class="alert alert-info"><p class="m-0">' . __('Please Select contact form.', 'rr-core' ). '</p></div>'; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php endif;
	}
}

$widgets_manager->register( new rr_Contact_Info() );