<?php
namespace RRCore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Utils;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * RR Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class RR_Gallery extends Widget_Base {

	use \RRCore\Widgets\RRCoreElementFunctions;

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'rr_gallery';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'gallery', 'rr-core' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'rr-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'rr-core' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'rr-core' ];
	}

 /**
     * contact form 7 setup.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     *
     * @access protected
     */

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */


     protected function register_controls(){
		$this->register_controls_section();
		$this->style_tab_content();
	}		


	// controls file 
	protected function register_controls_section(){
        // layout Panel
        $this->start_controls_section(
            'rr_layout',
            [
                'label' => esc_html__('Design Layout', 'rr-core'),
            ]
        ); 

        $this->add_control( 
            'rr_design_style',
            [
                'label' => esc_html__('Select Layout', 'rr-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Layout 1', 'rr-core'),
                    'layout-2' => esc_html__('Layout 2', 'rr-core'),
                ],
                'default' => 'layout-1',
            ]
        );

        $this->end_controls_section();
        
        // Gallery group
        $this->start_controls_section(
            'rr_gallery',
            [
                'label' => esc_html__('Gallery List', 'rr-core'),
                'description' => esc_html__( 'Control all the style settings from Style tab', 'rr-core' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $repeater = new \Elementor\Repeater();
 
        $repeater->add_control(
            'rr_gallery_main_image',
            [
                'label' => esc_html__('Upload Image', 'rr-core'),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ]
            ]
        );

        $repeater->add_control(
            'rr_gallery_title', [
                'label' => esc_html__('Title', 'rr-core'),
                'description' => rr_get_allowed_html_desc( 'basic' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('Service Title', 'rr-core'),
                'label_block' => true,
            ]
        );
        $repeater->add_control(
            'rr_gallery_desc', [
                'label' => esc_html__('Description', 'rr-core'),
                'description' => rr_get_allowed_html_desc( 'basic' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('Service Title', 'rr-core'),
                'label_block' => true,
            ]
        );
        $repeater->add_control(
            'rr_gallery_link_switcher',
            [
                'label' => esc_html__( 'Add Services link', 'rr-core' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Yes', 'rr-core' ),
                'label_off' => esc_html__( 'No', 'rr-core' ),
                'return_value' => 'yes',
                'default' => 'yes',
                'separator' => 'before',
            ]
        );
        $repeater->add_control(
            'rr_gallery_link_type',
            [
                'label' => esc_html__( 'Service Link Type', 'rr-core' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    '1' => 'Custom Link',
                    '2' => 'Internal Page',
                ],
                'default' => '1',
                'condition' => [
                    'rr_gallery_link_switcher' => 'yes'
                ]
            ]
        );

        $repeater->add_control(
            'rr_gallery_link',
            [
                'label' => esc_html__( 'Service Link link', 'rr-core' ),
                'type' => \Elementor\Controls_Manager::URL,
                'dynamic' => [
                    'active' => true,
                ],
                'placeholder' => esc_html__( 'htRRs://your-link.com', 'rr-core' ),
                'show_external' => true,
                'default' => [
                    'url' => '#',
                    'is_external' => false,
                    'nofollow' => false,
                ],
                'condition' => [
                    'rr_gallery_link_type' => '1',
                    'rr_gallery_link_switcher' => 'yes',
                ]
            ]
        );

        $repeater->add_control(
            'rr_gallery_page_link',
            [
                'label' => esc_html__( 'Select Service Link Page', 'rr-core' ),
                'type' => \Elementor\Controls_Manager::SELECT2,
                'label_block' => true,
                'options' => rr_get_all_pages(),
                'condition' => [
                    'rr_gallery_link_type' => '2',
                    'rr_gallery_link_switcher' => 'yes',
                ]
            ]
        );

        $this->add_control(
            'rr_gallery_list',
            [
                'label' => esc_html__('Services - List', 'rr-core'),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'rr_gallery_title' => esc_html__('Discover', 'rr-core'),
                    ],
                    [
                        'rr_gallery_title' => esc_html__('Define', 'rr-core')
                    ],
                    [
                        'rr_gallery_title' => esc_html__('Develop', 'rr-core')
                    ]
                ],
                'title_field' => '{{{ rr_gallery_title }}}',
            ]
        );
        $this->end_controls_section();
    
	}

	// style_tab_content
	protected function style_tab_content(){
        $this->rr_section_style_controls('gallery_section', 'Section Style', '.ele-section'); 
        $this->rr_basic_style_controls('gallery_title', 'Gallery Title', '.rr-el-re-Title');
        $this->rr_basic_style_controls('gallery_content', 'Gallery Content', '.rr-el-content');
        $this->rr_section_style_controls('gallery_box', 'Gallery Box Style', '.ele-section-box');
	}

/**
 * Render the widget ouRRut on the frontend.
 *
 * Written in PHP and used to generate the final HTML.
 *
 * @since 1.0.0
 * 
 * @access protected
 */
protected function render() {
    $settings = $this->get_settings_for_display();

    ?>

<?php if ( $settings['rr_design_style']  == 'layout-2' ):

    $this->add_render_attribute('title_args', 'class', 'happy-customer__content-wrapper-title rr-el-re-Title');
?>

<?php else: 
    $this->add_render_attribute('title_args', 'class', 'title wow fadeInLeft animated rr-el-re-Title');   
?>
<section class="gallery__area position-relative  pt-100 section-space-bottom overflow-hidden ele-section">
    <div class="container">
        <div class="row mb-minus-30">
            <?php foreach ($settings['rr_gallery_list'] as $key => $item) :
                // Link
                if ('2' == $item['rr_gallery_link_type']) {
                    $link = get_permalink($item['rr_gallery_page_link']);
                    $target = '_self';
                    $rel = 'nofollow';
                } else {
                    $link = !empty($item['rr_gallery_link']['url']) ? $item['rr_gallery_link']['url'] : '';
                    $target = !empty($item['rr_gallery_link']['is_external']) ? '_blank' : '';
                    $rel = !empty($item['rr_gallery_link']['nofollow']) ? 'nofollow' : '';
                }

                // thumbnail image
                if ( !empty($item['rr_gallery_main_image']['url']) ) {
                    $rr_gallery_main_image = !empty($item['rr_gallery_main_image']['id']) ? wp_get_attachment_image_url( $item['rr_gallery_main_image']['id'], 'full' ) : $item['rr_gallery_main_image']['url'];
                    $rr_gallery_main_image_alt = get_post_meta($item["rr_gallery_main_image"]["id"], "_wp_attachment_image_alt", true);
                }
            ?>
            <div class="col-xl-4 col-lg-4 col-md-6">
                <div class="gallery__item position-relative overflow-hidden">
                    <div class="gallery__media mb-30">
                        <?php if(!empty($rr_gallery_main_image)) : ?>
                        <img src="<?php echo esc_url($rr_gallery_main_image); ?>"
                            alt="<?php echo esc_attr($rr_gallery_main_image_alt); ?>">
                        <?php endif; ?>
                    </div>
                    <div class="gallery__content ele-section-box">
                        <h3 class="gallery__title rr-el-re-Title">
                            <?php if ($item['rr_gallery_link_switcher'] == 'yes') : ?>
                            <a
                                href="<?php echo esc_url($link); ?>"><?php echo rr_kses($item['rr_gallery_title' ]); ?></a>
                            <?php else : ?>
                            <?php echo rr_kses($item['rr_gallery_title' ]); ?>
                            <?php endif; ?>
                        </h3>
                        <span class="rr-el-content"><?php echo rr_kses($item['rr_gallery_desc']);?></span>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>
<?php endif; 
	}
}
$widgets_manager->register( new RR_Gallery() );