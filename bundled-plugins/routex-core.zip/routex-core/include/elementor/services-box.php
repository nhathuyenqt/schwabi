<?php
namespace RRCore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Repeater;
use \Elementor\Utils;
use RRCore\Elementor\Controls\Group_Control_RRBGGradient;
use RRCore\Elementor\Controls\Group_Control_RRGradient;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * RR Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class RR_Service_Bow extends Widget_Base {

    use \RRCore\Widgets\RRCoreElementFunctions;

    /**
     * Retrieve the widget name.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name() {
        return 'rr_service_box';
    }

    /**
     * Retrieve the widget title.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title() {
        return __( 'RR Service Box', 'rr-core' );
    }

    /**
     * Retrieve the widget icon.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'rr-icon';
    }

    /**
     * Retrieve the list of categories the widget belongs to.
     *
     * Used to determine where to display the widget in the editor.
     *
     * Note that currently Elementor supports only one category.
     * When multiple categories passed, Elementor uses the first one.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return array Widget categories.
     */
    public function get_categories() {
        return [ 'rr-core' ];
    }

    /**
     * Retrieve the list of scripts the widget depended on.
     *
     * Used to set scripts dependencies required to run the widget.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return array Widget scripts dependencies.
     */
    public function get_script_depends() {
        return [ 'rr-core' ];
    }

    /**
     * Register the widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     *
     * @access protected
     */

    protected function register_controls(){
        $this->register_controls_section();
        $this->style_tab_content();
    }
    protected function register_controls_section() {

        // layout Panel
        $this->start_controls_section(
            'rr_layout',
            [
                'label' => esc_html__('Design Layout', 'rr-core'),
            ]
        );
        $this->add_control(
            'rr_design_style',
            [
                'label' => esc_html__('Select Layout', 'rr-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Layout 1', 'rr-core'),
                    'layout-2' => esc_html__('Layout 2', 'rr-core'),
                ],
                'default' => 'layout-1',
            ]
        );

        $this->end_controls_section();

        // Service group 
        $this->start_controls_section( 
            'rr_services',
            [
                'label' => esc_html__('Services List', 'rr-core'),
                'description' => esc_html__( 'Control all the style settings from Style tab', 'rr-core' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'repeater_condition',
            [
                'label' => __( 'Field condition', 'rr-core' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'style_1' => __( 'Style 1', 'rr-core' ),
                    'style_2' => __( 'Style 2', 'rr-core' ),
                    'style_3' => __( 'Style 3', 'rr-core' ),
                ],
                'default' => 'style_1',
                'frontend_available' => true,
                'style_transfer' => true,
            ]
        );

        $this->add_control(
            'rr_service_icon_type',
            [
                'label' => esc_html__('Select Icon Type', 'rr-core'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'icon',
                'options' => [

                    
                    'image' => esc_html__('Image', 'rr-core'),
                    'icon' => esc_html__('Icon', 'rr-core'),
                    'svg' => esc_html__('SVG', 'rr-core'),
                ],
            ]
        );

        $this->add_control(
            'rr_service_image',
            [
                'label' => esc_html__('Upload Icon Image', 'rr-core'),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
                'condition' => [
                    'rr_service_icon_type' => 'image'
                ]

            ]
        );

        if (rr_is_elementor_version('<', '2.6.0')) {
            $this->add_control(
                'rr_service_icon',
                [
                    'show_label' => false,
                    'type' => Controls_Manager::ICON,
                    'label_block' => true,
                    'default' => 'fa fa-star',
                    'condition' => [
                        'rr_service_icon_type' => 'icon'
                    ]
                ]
            );
        } else {
            $this->add_control(
                'rr_service_selected_icon',
                [
                    'show_label' => false,
                    'type' => Controls_Manager::ICONS,
                    'fa4compatibility' => 'icon',
                    'label_block' => true,
                    'default' => [
                        'value' => 'fas fa-star',
                        'library' => 'solid',
                    ],
                    'condition' => [
                        'rr_service_icon_type' => 'icon'
                    ]
                ]
            );
        }

        $this->add_control(
            'rr_service_icon_svg',
            [
                'show_label' => false,
                'type' => Controls_Manager::TEXTAREA,
                'label_block' => true,
                'placeholder' => esc_html__('SVG Code Here', 'rr-core'),
                'condition' => [
                    'rr_service_icon_type' => 'svg',
                ]
            ]
        );

        $this->add_control(
            'rr_service_title', [
                'label' => esc_html__('Title', 'rr-core'),
                'description' => rr_get_allowed_html_desc( 'basic' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('Service Title', 'rr-core'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'rr_service_description',
            [
                'label' => esc_html__('Description', 'rr-core'),
                'description' => rr_get_allowed_html_desc( 'intermediate' ),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'default' => esc_html__('There are many variations of passages of Lorem Ipsum available, but the majority have suffered.', 'rr-core'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'rr_services_link',
            [
                'label' => esc_html__( 'Service Link link', 'rr-core' ),
                'type' => \Elementor\Controls_Manager::URL,
                'dynamic' => [
                    'active' => true,
                ],
                'placeholder' => esc_html__( 'htrrs://your-link.com', 'rr-core' ),
                'show_external' => true,
                'default' => [
                    'url' => '#',
                    'is_external' => false,
                    'nofollow' => false,
                ],

            ]
        );


        $this->add_control(
            'rr_service_btn', [
                'label' => esc_html__('Button', 'rr-core'),
                'description' => rr_get_allowed_html_desc( 'basic' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('Read More', 'rr-core'),
                'label_block' => true,
            ]
        );
        $this->add_control(
            'rr_image_thumb',
            [
                'label' => esc_html__( 'Choose Thumbnail Image', 'rr-core' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Image_Size::get_type(),
            [
                'name' => 'rr_image_size',
                'default' => 'full',
                'exclude' => [
                    'custom'
                ] ,
            ]
        );
        $this->end_controls_section();
        

    }

    // style_tab_content
    protected function style_tab_content(){

        $this->rr_section_style_controls('services_section', 'Section Style', '.ele-section');
        $this->rr_basic_style_controls('section_sub_title', 'Section - Sub Title', '.rr-el-sub-title');
        $this->rr_basic_style_controls('section_title', 'Section - Title', '.rr-el-title');
        $this->rr_basic_style_controls('services_title', 'Services Title', '.rr-el-re-Title');
        $this->rr_basic_style_controls('services_desc', 'Services Description', '.rr-el-re-dec');
        $this->rr_link_controls_style('repiter_icon', 'Services - Icon', '.rr-el-icon');
        $this->rr_link_controls_style('repiter_btn', 'services - Button', '.rr-el-btn');
        $this->rr_section_style_controls('services_box', 'Services Box', '.services-box');
        
    }

    /**
     * Render the widget ourrut on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     *
     * @access protected
     */
    protected function render() {
        $settings = $this->get_settings_for_display();

        ?>

<?php if ( $settings['rr_design_style']  == 'layout-2' ):  

    $this->add_render_attribute('title_args', 'class', 'section-title2__wrapper-title  wow fadeInLeft animated rr-el-title');
?>

<?php else: 
    if ( !empty($settings['rr_image_thumb']['url']) ) {
        $rr_image_thumb = !empty($settings['rr_image_thumb']['id']) ? wp_get_attachment_image_url( $settings['rr_image_thumb']['id'], $settings['rr_image_size_size']) : $settings['rr_image_thumb']['url'];
        $rr_image_alt = get_post_meta($settings["rr_image_thumb"]["id"], "_wp_attachment_image_alt", true);
    }   

        $this->add_render_attribute('title_args', 'class', 'rr-section-title ele-section-title');
    ?>

<div class="service-5__item mb-30 ele-section">
    <div class="service-5__item-icon img-height-3">
        <?php if($settings['rr_service_icon_type'] == 'icon') : ?>
        <?php if (!empty($settings['rr_service_icon']) || !empty($settings['rr_service_selected_icon']['value'])) : ?>
        <span>
            <?php rr_render_icon($settings, 'rr_service_icon', 'rr_service_selected_icon'); ?>
        </span>
        <?php endif; ?>
        <?php elseif( $settings['rr_service_icon_type'] == 'image' ) : ?>
        <?php if (!empty($settings['rr_service_image']['url'])): ?>
        <span>
            <img src="<?php echo $settings['rr_service_image']['url']; ?>"
                alt="<?php echo get_post_meta(attachment_url_to_postid($settings['rr_service_image']['url']), '_wp_attachment_image_alt', true); ?>">
        </span>
        <?php endif; ?>
        <?php else : ?>
        <?php if (!empty($settings['rr_service_icon_svg'])): ?>
        <span>
            <?php echo $settings['rr_service_icon_svg']; ?>
        </span>
        <?php endif; ?>
        <?php endif; ?>
    </div>
    <div class="service-5__item-thumb">
        <div class="service-5__item-thumb-content">
            <h3 class="service-5__item-thumb-content-title"><a
                    href="<?php echo esc_url($settings['rr_services_link']['url']); ?>"><?php echo rr_kses($settings['rr_service_title']);?></a></h3>
            <p class="service-5__item-thumb-content-dec"><?php echo rr_kses($settings['rr_service_description']); ?></p>
            <a class="service-5__item-thumb-content-btn"
                href="<?php echo esc_url($settings['rr_services_link']['url']); ?>"><?php echo rr_kses($settings['rr_service_btn']); ?> <i
                    class="fa-solid fa-arrow-right"></i></a>
        </div>
        <?php if(!empty($rr_image_thumb)) : ?>
        <img src="<?php echo esc_url($rr_image_thumb); ?>" alt="<?php echo esc_attr($rr_image_alt); ?>">
        <?php endif; ?>
        <h3 class="service-5__item-title"><a href="<?php echo esc_url($settings['rr_services_link']['url']); ?>"><?php echo rr_kses($settings['rr_service_title']);?></a>
        </h3>
    </div>
</div>


<?php endif; 
    }
}

$widgets_manager->register( new RR_Service_Bow() ); 