<?php
namespace RRCore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Repeater;
use \Elementor\Utils;
use \Elementor\Control_Media;
use RRCore\Elementor\Controls\Group_Control_RRBGGradient;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * RR Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class rr_CTA extends Widget_Base {

    use \RRCore\Widgets\RRCoreElementFunctions;

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'rr-cta';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'CTA', 'rr-core' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'rr-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'rr-core' ];
	}

    /**
     * contact form 7 setup.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     *
     * @access protected
     */

    public function get_rr_contact_form(){
        if ( ! class_exists( 'WPCF7' ) ) {
            return;
        }
        $rr_cfa         = array();
        $rr_cf_args     = array( 'posts_per_page' => -1, 'post_type'=> 'wpcf7_contact_form' );
        $rr_forms       = get_posts( $rr_cf_args );
        $rr_cfa         = ['0' => esc_html__( 'Select Form', 'rr-core' ) ];
        if( $rr_forms ){
            foreach ( $rr_forms as $rr_form ){
                $rr_cfa[$rr_form->ID] = $rr_form->post_title;
            }
        }else{
            $rr_cfa[ esc_html__( 'No contact form found', 'rr-core' ) ] = 0;
        }
        return $rr_cfa;
    }

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */


	protected function register_controls(){
		$this->register_controls_section();
		$this->style_tab_content();
	}		


	// controls file 
	protected function register_controls_section(){
        // layout Panel
        $this->start_controls_section(
            'rr_layout',
            [
                'label' => esc_html__('Design Layout', 'rr-core'),
            ]
        );

        $this->add_control( 
            'rr_design_style',
            [
                'label' => esc_html__('Select Layout', 'rr-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Layout 1', 'rr-core'),
                    'layout-2' => esc_html__('Layout 2', 'rr-core'),
                    'layout-3' => esc_html__('Layout 3', 'rr-core'),
                    'layout-4' => esc_html__('Layout 4', 'rr-core'),
                ],
                'default' => 'layout-1',
            ]
        );

        $this->end_controls_section();
          // rr_section_title
          $this->rr_section_title_render_controls('section', 'Section Title', 'Sub Title', 'your title here', $default_description = 'Hic nesciunt galisum aut dolorem aperiam eum soluta quod ea cupiditate.',['layout-2','layout-3', 'layout-4']);

          $this->start_controls_section(
            'rr_core_contact',
            [
                'label' => esc_html__('Contact Form', 'rr-core'),
                'condition' => [
                    'rr_design_style' => 'layout-2'
                ]

            ]
        );

        $this->add_control(
            'rr_core_select_contact_form',
            [
                'label'   => esc_html__( 'Select Form', 'rr-core' ),
                'type'    => Controls_Manager::SELECT,
                'default' => '0',
                'options' => $this->get_rr_contact_form(),
            ]
        );

        $this->end_controls_section();
      // rr_btn_button_group
      $this->start_controls_section(
        'rr_btn_button_group',
        [
            'label' => esc_html__('Button', 'rr-core'),
            'condition' => [
                'rr_design_style' => ['layout-3', 'layout-4']
            ]
        ]
    );
    $this->add_control(
        'rr_btn_text',
        [
            'label' => esc_html__('Button Text', 'rr-core'),
            'type' => Controls_Manager::TEXT,
            'default' => esc_html__('Button Text', 'rr-core'),
            'title' => esc_html__('Enter button text', 'rr-core'),
            'label_block' => true,
            'condition' => [
                'rr_btn_button_show' => 'yes'
            ],
        ]
    );
    $this->add_control(
        'rr_btn_button_show',
        [
            'label' => esc_html__( 'Show Button', 'rr-core' ),
            'type' => Controls_Manager::SWITCHER,
            'label_on' => esc_html__( 'Show', 'rr-core' ),
            'label_off' => esc_html__( 'Hide', 'rr-core' ),
            'return_value' => 'yes',
            'default' => 'yes',
        ]
    );
    $this->add_control(
        'rr_btn_link_type',
        [
            'label' => esc_html__('Button Link Type', 'rr-core'),
            'type' => Controls_Manager::SELECT,
            'options' => [
                '1' => 'Custom Link',
                '2' => 'Internal Page',
            ],
            'default' => '1',
            'label_block' => true,
            'condition' => [
                'rr_btn_button_show' => 'yes'
            ],
        ]
    );

    $this->add_control(
        'rr_btn_link',
        [
            'label' => esc_html__('Button link', 'rr-core'),
            'type' => Controls_Manager::URL,
            'dynamic' => [
                'active' => true,
            ],
            'placeholder' => esc_html__('htRRs://your-link.com', 'rr-core'),
            'show_external' => false,
            'default' => [
                'url' => '#',
                'is_external' => true,
                'nofollow' => true,
                'custom_attributes' => '',
            ],
            'condition' => [
                'rr_btn_link_type' => '1',
                'rr_btn_button_show' => 'yes'
            ],
            'label_block' => true,
        ]
    );
    $this->add_control(
        'rr_btn_page_link',
        [
            'label' => esc_html__('Select Button Page', 'rr-core'),
            'type' => Controls_Manager::SELECT2,
            'label_block' => true,
            'options' => rr_get_all_pages(),
            'condition' => [
                'rr_btn_link_type' => '2',
                'rr_btn_button_show' => 'yes'
            ]
        ]
    );

    $this->add_responsive_control(
        'rr_align',
        [
            'label' => esc_html__('Alignment', 'rr-core'),
            'type' => Controls_Manager::CHOOSE,
            'options' => [
                'left' => [
                    'title' => esc_html__('Left', 'rr-core'),
                    'icon' => 'eicon-text-align-left',
                ],
                'center' => [
                    'title' => esc_html__('Center', 'rr-core'),
                    'icon' => 'eicon-text-align-center',
                ],
                'right' => [
                    'title' => esc_html__('Right', 'rr-core'),
                    'icon' => 'eicon-text-align-right',
                ],
            ],
            'default' => 'left',
            'toggle' => false,
            'selectors' => [
                '{{WRAPPER}}' => 'text-align: {{VALUE}};'
            ]
        ]
    );
    
    $this->end_controls_section();
    $this->start_controls_section(
        'rr-core_text_wrap',
        [
            'label' => esc_html__('Cta Contact', 'rr-core'),
            'condition' => [
                'rr_design_style' => 'layout-1'
            ]

        ]
    );
    $this->add_control(
        'rr_box_icon_type',
        [
            'label' => esc_html__('Select Icon Type', 'rr-core'),
            'type' => \Elementor\Controls_Manager::SELECT,
            'default' => 'icon',
            'options' => [
                'image' => esc_html__('Image', 'rr-core'),
                'icon' => esc_html__('Icon', 'rr-core'),
                'svg' => esc_html__('SVG', 'rr-core'),
            ],

        ]
    );
    $this->add_control(
        'rr_box_icon_svg',
        [
            'show_label' => false,
            'type' => Controls_Manager::TEXTAREA,
            'label_block' => true,
            'placeholder' => esc_html__('SVG Code Here', 'rr-core'),
            'condition' => [
                'rr_box_icon_type' => 'svg'
            ]
        ]
    );

    $this->add_control(
        'rr_box_icon_image',
        [
            'label' => esc_html__('Upload Icon Image', 'rr-core'),
            'type' => Controls_Manager::MEDIA,
            'default' => [
                'url' => Utils::get_placeholder_image_src(),
            ],
            'condition' => [
                'rr_box_icon_type' => 'image',
            ]
        ]
    );

    if (rr_is_elementor_version('<', '2.6.0')) {
        $this->add_control(
            'rr_box_icon',
            [
                'show_label' => false,
                'type' => Controls_Manager::ICON,
                'label_block' => true,
                'default' => 'fa fa-star',
                'condition' => [
                    'rr_box_icon_type' => 'icon'
                ]
            ]
        );
    } else {
        $this->add_control(
            'rr_box_selected_icon',
            [
                'show_label' => false,
                'type' => Controls_Manager::ICONS,
                'fa4compatibility' => 'icon',
                'label_block' => true,
                'default' => [
                    'value' => 'fas fa-star',
                    'library' => 'solid',
                ],
                'condition' => [
                    'rr_box_icon_type' => 'icon'
                ]
            ]
        );
    }
    $this->add_control(
        'rr_contact_text',
        [
            'label' => esc_html__('Cta Text Left', 'rr-core'),
            'type' => Controls_Manager::TEXT,
            'default' => esc_html__('Cta Text Left', 'rr-core'),
            'title' => esc_html__('Enter Cta Text Left', 'rr-core'),
            'label_block' => true,
        ]
    );
    $this->add_control(
        'rr_box_icon_type_2',
        [
            'label' => esc_html__('Select Icon Type', 'rr-core'),
            'type' => \Elementor\Controls_Manager::SELECT,
            'default' => 'icon',
            'options' => [
                'image' => esc_html__('Image', 'rr-core'),
                'icon' => esc_html__('Icon', 'rr-core'),
                'svg' => esc_html__('SVG', 'rr-core'),
            ],

        ]
    );
    $this->add_control(
        'rr_box_icon_svg_2',
        [
            'show_label' => false,
            'type' => Controls_Manager::TEXTAREA,
            'label_block' => true,
            'placeholder' => esc_html__('SVG Code Here', 'rr-core'),
            'condition' => [
                'rr_box_icon_type_2' => 'svg'
            ]
        ]
    );

    $this->add_control(
        'rr_box_icon_image_2',
        [
            'label' => esc_html__('Upload Icon Image', 'rr-core'),
            'type' => Controls_Manager::MEDIA,
            'default' => [
                'url' => Utils::get_placeholder_image_src(),
            ],
            'condition' => [
                'rr_box_icon_type_2' => 'image',
            ]
        ]
    );

    if (rr_is_elementor_version('<', '2.6.0')) {
        $this->add_control(
            'rr_box_icon_2',
            [
                'show_label' => false,
                'type' => Controls_Manager::ICON,
                'label_block' => true,
                'default' => 'fa fa-star',
                'condition' => [
                    'rr_box_icon_type_2' => 'icon'
                ]
            ]
        );
    } else {
        $this->add_control(
            'rr_box_selected_icon_2',
            [
                'show_label' => false,
                'type' => Controls_Manager::ICONS,
                'fa4compatibility' => 'icon',
                'label_block' => true,
                'default' => [
                    'value' => 'fas fa-star',
                    'library' => 'solid',
                ],
                'condition' => [
                    'rr_box_icon_type_2' => 'icon'
                ]
            ]
        );
    }
    $this->add_control(
        'rr_contact_text_right',
        [
            'label' => esc_html__('Cta Text Right', 'rr-core'),
            'type' => Controls_Manager::TEXT,
            'default' => esc_html__('Cta Text Right', 'rr-core'),
            'title' => esc_html__('Enter Cta Text Right', 'rr-core'),
            'label_block' => true,
        ]
    );

    $this->end_controls_section();
    
        // _rr_image
		$this->start_controls_section(
            '_rr_image',
            [
                'label' => esc_html__('Thumbnail', 'rr-core'),
                'condition' => [
                    'rr_design_style' => ['layout-1', 'layout-2', 'layout-3' ]
                ]
            ]
        );
        $this->add_control(
            'rr_image',
            [
                'label' => esc_html__( 'Choose Image', 'rr-core' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );
        $this->add_control(
            'rr_image_bg',
            [
                'label' => esc_html__( 'Choose Bg Image', 'rr-core' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Image_Size::get_type(),
            [
                'name' => 'rr_image_size',
                'default' => 'full',
                'exclude' => [
                    'custom'
                ]
            ]
        );

        $this->end_controls_section();

	}

	// style_tab_content
	protected function style_tab_content(){
        $this->rr_section_style_controls('cta_section', 'Section Style', '.ele-section'); 
        $this->rr_basic_style_controls('cta_title', 'Cta Title', '.rr-el-re-Title');
        $this->rr_link_controls_style('repiter_btn', 'Cta - Button', '.rr-el-btn');
	}

/**
 * Render the widget ouRRut on the frontend.
 *
 * Written in PHP and used to generate the final HTML.
 *
 * @since 1.0.0
 *
 * @access protected
 */
protected function render() {
    $settings = $this->get_settings_for_display();

    ?>

<?php if ( $settings['rr_design_style']  == 'layout-2' ):
    if ( !empty($settings['rr_image']['url']) ) {
        $rr_image = !empty($settings['rr_image']['id']) ? wp_get_attachment_image_url( $settings['rr_image']['id'], $settings['rr_image_size_size']) : $settings['rr_image']['url'];
        $rr_image_alt = get_post_meta($settings["rr_image"]["id"], "_wp_attachment_image_alt", true);
    }  

    if ( !empty($settings['rr_image_bg']['url']) ) {
        $rr_image_bg = !empty($settings['rr_image_bg']['id']) ? wp_get_attachment_image_url( $settings['rr_image_bg']['id'], $settings['rr_image_size_size']) : $settings['rr_image_bg']['url'];
        $rr_image_alt = get_post_meta($settings["rr_image_bg"]["id"], "_wp_attachment_image_alt", true);
    } 

    $this->add_render_attribute('title_args', 'class', 'contact3__title wow fadeInLeft animated rr-el-re-Title');
?>
<section class="contact3__area p-relative ele-section">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-12">
                <div class="contact3__allcontent p-relative mt-255">
                    <div class="contact3__bg-color">
                        <div class="contact3__bg-img" data-background="<?php echo esc_url($rr_image_bg); ?>"></div>
                        <div class="contact3__wrap d-flex justify-content-between align-items-center">
                            <div class="contact3__content">
                                <?php
                                    if ( !empty($settings['rr_section_title' ]) ) :
                                        printf( '<%1$s %2$s>%3$s</%1$s>',
                                        tag_escape( $settings['rr_section_title_tag'] ),
                                        $this->get_render_attribute_string( 'title_args' ),
                                        rr_kses( $settings['rr_section_title' ] )
                                        );
                                    endif;
                                ?>
                                <?php if ( !empty($settings['rr_section_description']) ) : ?>
                                <p class=" wow fadeInLeft animated" data-wow-delay=".3s">
                                    <?php echo rr_kses( $settings['rr_section_description'] ); ?></p>
                                <?php endif; ?>


                                <?php if( !empty($settings['rr_core_select_contact_form']) ) : ?>
                                <?php echo do_shortcode( '[contact-form-7  id="'.$settings['rr_core_select_contact_form'].'"]' ); ?>
                                <?php else : ?>
                                <?php echo '<div class="alert alert-info"><p class="m-0">' . __('Please Select contact form.', 'rr-core' ). '</p></div>'; ?>
                                <?php endif; ?>

                            </div>
                            <div class="contact3__thumb wow fadeInLeft animated mr-60" data-wow-delay=".6s">
                                <?php if(!empty($rr_image)) : ?>
                                <img src="<?php echo esc_url($rr_image); ?>"
                                    alt="<?php echo esc_attr($rr_image_alt); ?>">
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php elseif ( $settings['rr_design_style']  == 'layout-3' ):
    if ( !empty($settings['rr_image']['url']) ) {
        $rr_image = !empty($settings['rr_image']['id']) ? wp_get_attachment_image_url( $settings['rr_image']['id'], $settings['rr_image_size_size']) : $settings['rr_image']['url'];
        $rr_image_alt = get_post_meta($settings["rr_image"]["id"], "_wp_attachment_image_alt", true);
    }  

    if ( !empty($settings['rr_image_bg']['url']) ) {
        $rr_image_bg = !empty($settings['rr_image_bg']['id']) ? wp_get_attachment_image_url( $settings['rr_image_bg']['id'], $settings['rr_image_size_size']) : $settings['rr_image_bg']['url'];
        $rr_image_alt = get_post_meta($settings["rr_image_bg"]["id"], "_wp_attachment_image_alt", true);
    } 
    // Link
    if ('2' == $settings['rr_btn_link_type']) {
        $this->add_render_attribute('rr-button-arg', 'href', get_permalink($settings['rr_btn_page_link']));
        $this->add_render_attribute('rr-button-arg', 'target', '_self');
        $this->add_render_attribute('rr-button-arg', 'rel', 'nofollow');
        $this->add_render_attribute('rr-button-arg', 'class', "contact4__btn rr-el-btn");
    } else {
        $this->add_render_attribute('rr-button-arg', 'class', "contact4__btn rr-el-btn");
        if ( ! empty( $settings['rr_btn_link']['url'] ) ) {
            $this->add_link_attributes( 'rr-button-arg', $settings['rr_btn_link'] );
        }
    }

    $this->add_render_attribute('title_args', 'class', 'contact4__title wow fadeInLeft animated rr-el-re-Title');
?>
<section class="contact4__area p-relative">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-12">
                <div class="contact4__allcontent p-relative mt-255">
                    <div class="contact4__bg-color ele-section">
                        <div class="contact4__bg-img" data-background="<?php echo esc_url($rr_image_bg); ?>"></div>
                        <div class="contact4__wrap d-flex justify-content-between align-items-center">
                            <div class="contact4__content">
                                <?php
                                    if ( !empty($settings['rr_section_title' ]) ) :
                                        printf( '<%1$s %2$s>%3$s</%1$s>',
                                        tag_escape( $settings['rr_section_title_tag'] ),
                                        $this->get_render_attribute_string( 'title_args' ),
                                        rr_kses( $settings['rr_section_title' ] )
                                        );
                                    endif;
                                ?>
                                <?php if ( !empty($settings['rr_section_description']) ) : ?>
                                <p class=" wow fadeInLeft animated" data-wow-delay=".3s">
                                    <?php echo rr_kses( $settings['rr_section_description'] ); ?></p>
                                <?php endif; ?>
                                <div class="button mt-40 wow fadeInLeft animated" data-wow-delay=".3s">
                                    <a <?php echo $this->get_render_attribute_string( 'rr-button-arg' ); ?>><?php echo rr_kses($settings['rr_btn_text']); ?>
                                        <i class="fa-solid fa-arrow-right"></i></a>
                                </div>
                            </div>
                            <div class="contact4__thumb wow fadeInLeft animated" data-wow-delay=".4s">
                                <?php if(!empty($rr_image)) : ?>
                                <img src="<?php echo esc_url($rr_image); ?>"
                                    alt="<?php echo esc_attr($rr_image_alt); ?>">
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php elseif ( $settings['rr_design_style']  == 'layout-4' ):
    if ( !empty($settings['rr_image']['url']) ) {
        $rr_image = !empty($settings['rr_image']['id']) ? wp_get_attachment_image_url( $settings['rr_image']['id'], $settings['rr_image_size_size']) : $settings['rr_image']['url'];
        $rr_image_alt = get_post_meta($settings["rr_image"]["id"], "_wp_attachment_image_alt", true);
    }  

    if ( !empty($settings['rr_image_bg']['url']) ) {
        $rr_image_bg = !empty($settings['rr_image_bg']['id']) ? wp_get_attachment_image_url( $settings['rr_image_bg']['id'], $settings['rr_image_size_size']) : $settings['rr_image_bg']['url'];
        $rr_image_alt = get_post_meta($settings["rr_image_bg"]["id"], "_wp_attachment_image_alt", true);
    } 
    // Link
    if ('2' == $settings['rr_btn_link_type']) {
        $this->add_render_attribute('rr-button-arg', 'href', get_permalink($settings['rr_btn_page_link']));
        $this->add_render_attribute('rr-button-arg', 'target', '_self');
        $this->add_render_attribute('rr-button-arg', 'rel', 'nofollow');
        $this->add_render_attribute('rr-button-arg', 'class', "rr-btn btn-hover-white rr-el-btn");
    } else {
        $this->add_render_attribute('rr-button-arg', 'class', "rr-btn btn-hover-white rr-el-btn");
        if ( ! empty( $settings['rr_btn_link']['url'] ) ) {
            $this->add_link_attributes( 'rr-button-arg', $settings['rr_btn_link'] );
        }
    }

    $this->add_render_attribute('title_args', 'class', 'get-visa__wrapper-title rr-el-re-Title');
?>
<section class="get-visa__area ele-section">
    <div class="container-fluid-sticky-left">
        <div class="get-visa__wrapper">
            <?php
                if ( !empty($settings['rr_section_title' ]) ) :
                    printf( '<%1$s %2$s>%3$s</%1$s>',
                    tag_escape( $settings['rr_section_title_tag'] ),
                    $this->get_render_attribute_string( 'title_args' ),
                    rr_kses( $settings['rr_section_title' ] )
                    );
                endif;
            ?>
            <a <?php echo $this->get_render_attribute_string( 'rr-button-arg' ); ?>><?php echo rr_kses($settings['rr_btn_text']); ?>
            <i class="fa-solid fa-arrow-right"></i></a>
        </div>
    </div>
</section>

<?php else: 
 
    $this->add_render_attribute('title_args', 'class', 'title wow fadeInLeft animated rr-el-re-Title'); 
?>
<div class="footer__border-bottom dark-green ele-section">
    <div class="container">
        <div class="footer-top d-flex justify-content-between pt-50 pb-50">
            <div class="footer-top-left d-flex wow fadeInLeft animated" data-wow-delay=".2s">
                <div class="footer-left-svg">
                    <?php if($settings['rr_box_icon_type'] == 'icon') : ?>
                    <?php if (!empty($settings['rr_box_icon']) || !empty($settings['rr_box_selected_icon']['value'])) : ?>
                    <span>
                        <?php rr_render_icon($settings, 'rr_box_icon', 'rr_box_selected_icon'); ?>
                    </span>
                    <?php endif; ?>
                    <?php elseif( $settings['rr_box_icon_type'] == 'image' ) : ?>
                    <?php if (!empty($settings['rr_box_icon_image']['url'])): ?>
                    <span>
                        <img src="<?php echo $settings['rr_box_icon_image']['url']; ?>"
                            alt="<?php echo get_post_meta(attachment_url_to_postid($settings['rr_box_icon_image']['url']), '_wp_attachment_image_alt', true); ?>">
                    </span>
                    <?php endif; ?>
                    <?php else : ?>
                    <?php if (!empty($settings['rr_box_icon_svg'])): ?>
                    <div class="contact-inner-img contact-img">
                        <?php echo $settings['rr_box_icon_svg']; ?>
                    </div>
                    <?php endif; ?>
                    <?php endif; ?>
                </div>
                <h3><?php echo rr_kses($settings['rr_contact_text']);?></h3>
            </div>
            <div class="footr-top-right d-flex wow fadeInLeft animated" data-wow-delay=".3s">
                <div class="footer-top-right d-flex">
                    <div class="footer-right-svg">
                        <?php if($settings['rr_box_icon_type_2'] == 'icon') : ?>
                        <?php if (!empty($settings['rr_box_icon_2']) || !empty($settings['rr_box_selected_icon_2']['value'])) : ?>
                        <span>
                            <?php rr_render_icon($settings, 'rr_box_icon_2', 'rr_box_selected_icon_2'); ?>
                        </span>
                        <?php endif; ?>
                        <?php elseif( $settings['rr_box_icon_type_2'] == 'image' ) : ?>
                        <?php if (!empty($settings['rr_box_icon_image_2']['url'])): ?>
                        <span>
                            <img src="<?php echo $settings['rr_box_icon_image_2']['url']; ?>"
                                alt="<?php echo get_post_meta(attachment_url_to_postid($settings['rr_box_icon_image_2']['url']), '_wp_attachment_image_alt', true); ?>">
                        </span>
                        <?php endif; ?>
                        <?php else : ?>
                        <?php if (!empty($settings['rr_box_icon_svg_2'])): ?>
                        <div class="contact-inner-img contact-img">
                            <?php echo $settings['rr_box_icon_svg_2']; ?>
                        </div>
                        <?php endif; ?>
                        <?php endif; ?>
                    </div>
                    <h3><?php echo rr_kses($settings['rr_contact_text_right']);?></h3>
                </div>
            </div>
        </div>
    </div>
</div>
<?php endif; 
	}
}
$widgets_manager->register( new rr_CTA() );