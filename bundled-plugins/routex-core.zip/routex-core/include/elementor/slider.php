<?php
namespace RRCore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Group_Control_Background;
use \Elementor\Control_Media;
use \Elementor\Repeater;
use \Elementor\Group_Control_Typography;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Utils;
use RRCore\Elementor\Controls\Group_Control_RRBGGradient;
use RRCore\Elementor\Controls\Group_Control_RRGradient;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * RR Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class rr_Slider extends Widget_Base {

    use \RRCore\Widgets\RRCoreElementFunctions;

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'rr-slider';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Slider', 'rr-core' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'rr-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'rr-core' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'rr-core' ];
	}


    protected static function get_profile_names()
    {
        return [
            'apple' => esc_html__('Apple', 'rr-core'),
            'behance' => esc_html__('Behance', 'rr-core'),
            'bitbucket' => esc_html__('BitBucket', 'rr-core'),
            'codepen' => esc_html__('CodePen', 'rr-core'),
            'delicious' => esc_html__('Delicious', 'rr-core'),
            'deviantart' => esc_html__('DeviantArt', 'rr-core'),
            'digg' => esc_html__('Digg', 'rr-core'),
            'dribbble' => esc_html__('Dribbble', 'rr-core'),
            'email' => esc_html__('Email', 'rr-core'),
            'facebook' => esc_html__('Facebook', 'rr-core'),
            'flickr' => esc_html__('Flicker', 'rr-core'),
            'foursquare' => esc_html__('FourSquare', 'rr-core'),
            'github' => esc_html__('Github', 'rr-core'),
            'houzz' => esc_html__('Houzz', 'rr-core'),
            'instagram' => esc_html__('Instagram', 'rr-core'),
            'jsfiddle' => esc_html__('JS Fiddle', 'rr-core'),
            'linkedin' => esc_html__('LinkedIn', 'rr-core'),
            'medium' => esc_html__('Medium', 'rr-core'),
            'pinterest' => esc_html__('Pinterest', 'rr-core'),
            'product-hunt' => esc_html__('Product Hunt', 'rr-core'),
            'reddit' => esc_html__('Reddit', 'rr-core'),
            'slideshare' => esc_html__('Slide Share', 'rr-core'),
            'snapchat' => esc_html__('Snapchat', 'rr-core'),
            'soundcloud' => esc_html__('SoundCloud', 'rr-core'),
            'spotify' => esc_html__('Spotify', 'rr-core'),
            'stack-overflow' => esc_html__('StackOverflow', 'rr-core'),
            'tripadvisor' => esc_html__('TripAdvisor', 'rr-core'),
            'tumblr' => esc_html__('Tumblr', 'rr-core'),
            'twitch' => esc_html__('Twitch', 'rr-core'),
            'twitter' => esc_html__('Twitter', 'rr-core'),
            'vimeo' => esc_html__('Vimeo', 'rr-core'),
            'vk' => esc_html__('VK', 'rr-core'),
            'website' => esc_html__('Website', 'rr-core'),
            'whatsapp' => esc_html__('WhatsApp', 'rr-core'),
            'wordpress' => esc_html__('WordPress', 'rr-core'),
            'xing' => esc_html__('Xing', 'rr-core'),
            'yelp' => esc_html__('Yelp', 'rr-core'),
            'youtube' => esc_html__('YouTube', 'rr-core'),
        ];
    }


	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
    protected function register_controls(){
        $this->register_controls_section();
        $this->style_tab_content();
    }  

	protected function register_controls_section() {
		

        // layout Panel
        $this->start_controls_section(
            'rr_layout',
            [
                'label' => esc_html__('Design Layout', 'rr-core'),
            ]
        );
        $this->add_control(
            'rr_design_style',
            [
                'label' => esc_html__('Select Layout', 'rr-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Layout 1', 'rr-core'),
                    'layout-2' => esc_html__('Layout 2', 'rr-core'),
                ],
                'default' => 'layout-1',
            ]
        );
        $this->end_controls_section();

		
		$this->start_controls_section(
            'rr_main_slider',
            [
                'label' => esc_html__('Main Slider', 'rr-core'),
                'description' => esc_html__( 'Control all the style settings from Style tab', 'rr-core' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'repeater_condition',
            [
                'label' => __( 'Field condition', 'rr-core' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'style_1' => __( 'Style 1', 'rr-core' ),
                ],
                'default' => 'style_1',
                'frontend_available' => true,
                'style_transfer' => true,
            ]
        );

        $repeater->add_control(
            'rr_slider_image',
            [
                'label' => esc_html__('Upload Image', 'rr-core'),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ]
            ]
        );

        $repeater->add_control(
            'rr_slider_title',
            [
                'label' => esc_html__('Title', 'rr-core'),
                'description' => rr_get_allowed_html_desc( 'intermediate' ),
                'type' => Controls_Manager::TEXTAREA,
                'default' => esc_html__('Grow business.', 'rr-core'),
                'placeholder' => esc_html__('Type Heading Text', 'rr-core'),
                'label_block' => true,
            ]
        );
        $repeater->add_control(
            'rr_slider_description',
            [
                'label' => esc_html__('Description', 'rr-core'),
                'description' => rr_get_allowed_html_desc( 'basic' ),
                'type' => Controls_Manager::TEXTAREA,
                'default' => 'Description',
                'placeholder' => esc_html__('Type Before Heading Text', 'rr-core'),
                'label_block' => true,
            ]
        );
        $repeater->add_control(
            'rr_slider_title_tag',
            [
                'label' => esc_html__('Title HTML Tag', 'rr-core'),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'h1' => [
                        'title' => esc_html__('H1', 'rr-core'),
                        'icon' => 'eicon-editor-h1'
                    ],
                    'h2' => [
                        'title' => esc_html__('H2', 'rr-core'),
                        'icon' => 'eicon-editor-h2'
                    ],
                    'h3' => [
                        'title' => esc_html__('H3', 'rr-core'),
                        'icon' => 'eicon-editor-h3'
                    ],
                    'h4' => [
                        'title' => esc_html__('H4', 'rr-core'),
                        'icon' => 'eicon-editor-h4'
                    ],
                    'h5' => [
                        'title' => esc_html__('H5', 'rr-core'),
                        'icon' => 'eicon-editor-h5'
                    ],
                    'h6' => [
                        'title' => esc_html__('H6', 'rr-core'),
                        'icon' => 'eicon-editor-h6'
                    ]
                ],
                'default' => 'h2',
                'toggle' => false,
            ]
        );
        $repeater->add_control(
            'rr_btn_text',
            [
                'label' => esc_html__('Button Text', 'rr-core'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Button Text', 'rr-core'),
                'title' => esc_html__('Enter button text', 'rr-core'),
                'label_block' => true,
            ]
        );
 
        $repeater->add_control(
            'rr_btn_link',
            [
                'label' => esc_html__( 'Button Link link', 'rr-core' ),
                'type' => \Elementor\Controls_Manager::URL,
                'dynamic' => [
                    'active' => true,
                ],
                'placeholder' => esc_html__( 'htRRs://your-link.com', 'rr-core' ),
                'show_external' => true,
                'default' => [
                    'url' => '#',
                    'is_external' => false,
                    'nofollow' => false,
                ],
            ]
        );


        $repeater->add_control(
            'rr_video_url',
            [
                'label' => esc_html__( 'Video URL', 'rr-core' ),
                'type' => Controls_Manager::URL,
                'options' => [ 'url', 'is_external', 'nofollow' ],
                'default' => [
                    'url' => 'https://www.youtube.com/watch?v=inWWhr5tnEA',
                    'is_external' => true,
                    'nofollow' => true,
                ],
                'label_block' => true,
            ]
        );
        $repeater->add_control(
            'rr_video_text',
            [
                'label' => esc_html__('Video Text', 'rr-core'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Watch Now', 'rr-core'),
                'title' => esc_html__('Enter Video text', 'rr-core'),
                'label_block' => true,
            ]
        );
        $this->add_control(
            'slider_list',
            [
                'label' => esc_html__('Slider List', 'rr-core'),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'rr_slider_title' => esc_html__('Grow business.', 'rr-core')
                    ],
                    [
                        'rr_slider_title' => esc_html__('Development.', 'rr-core')
                    ],
                    [
                        'rr_slider_title' => esc_html__('Marketing.', 'rr-core')
                    ],
                ],
                'title_field' => '{{{ rr_slider_title }}}',
            ]
        );

        $this->add_group_control(
            Group_Control_Image_Size::get_type(),
            [
                'name' => 'thumbnail', // // Usage: `{name}_size` and `{name}_custom_dimension`, in this case `thumbnail_size` and `thumbnail_custom_dimension`.
                'exclude' => ['custom'],
                // 'default' => 'rr-portfolio-thumb',
            ]
        );
        $this->end_controls_section();
        $this->start_controls_section(
            'rr_shap_section',
                [
                    'label' => esc_html__( 'Shape', 'rr-core' ),
                    'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
                ]
            );
    
            $this->add_control(
                'rr_slider_shape_switcher',
                [
                    'label' => esc_html__( 'Slider Shape', 'rr-core' ),
                    'type' => \Elementor\Controls_Manager::SWITCHER,
                    'label_on' => esc_html__( 'Yes', 'rr-core' ),
                    'label_off' => esc_html__( 'No', 'rr-core' ),
                    'return_value' => 'yes',
                    'default' => 'yes',
                    'separator' => 'before',
                ]
            );
     
            $this->end_controls_section();
            
            $this->start_controls_section(
                'hero_section',
                [
                    'label' => esc_html__('Background Overlay', 'rr-core'),
                    'tab' => \Elementor\Controls_Manager::TAB_STYLE,
                ]
            );
            
            $this->add_group_control(
                \Elementor\Group_Control_Background::get_type(),
                [
                    'name' => 'background',
                    'label' => esc_html__('Background', 'generic-elements'),
                    'types' => ['classic', 'gradient', 'video'],
                    'selector' => '{{WRAPPER}} .banner-4__thumb-bg::before',
                ]
            );
            $this->end_controls_section();
            
            



	}

    protected function style_tab_content(){
        $this->rr_section_style_controls('banner_section', 'Section Style', '.ele-section');
        $this->rr_basic_style_controls('banner_title', 'Heading Style', '.ele-heading');
        $this->rr_basic_style_controls('banner_desc', 'Description Style', '.ele-desc');
        $this->rr_link_controls_style('main_button', 'Button Style', '.rr-el-btn');
    }

	/**
	 * Render the widget ouRRut on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *Video Youtube link
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		?>

<?php if ( $settings['rr_design_style']  == 'layout-2' ): ?>

<section class="banner__area banner-4 p-relative ele-section">
    <div class="swiper banner-4__active p-relative">
        <div class="swiper-wrapper">
            <?php foreach ($settings['slider_list'] as $key => $item) : 
                $this->add_render_attribute('title_args', 'class', 'banner__title banner-4__title ele-heading');

                if ( !empty($item['rr_slider_image']['url']) ) {
                    $rr_slider_image = !empty($item['rr_slider_image']['id']) ? wp_get_attachment_image_url( $item['rr_slider_image']['id'], $settings['thumbnail_size']) : $item['rr_slider_image']['url'];
                    $rr_slider_image_alt = get_post_meta($item["rr_slider_image"]["id"], "_wp_attachment_image_alt", true);
                }

                ?>
            <div class="swiper-slide">
                <div class="banner-4__shapes">
                    <div class="banner-4__shapes-shape-1 upDown" data-animation="pixfix-fadeInLeft" data-delay="1000ms"
                        data-duration="1200ms">
                        <?php if ( !empty($settings['rr_slider_shape_switcher']) ) : ?>
                        <img src="<?php echo get_template_directory_uri(  ); ?>/assets/imgs/banner-4/banner-bg-4-shape.png"
                            alt="img not found">
                        <?php endif; ?>
                    </div>
                </div>
                <div class="banner banner__space banner-4__space">
                    <?php if(!empty($rr_slider_image)) : ?>
                    <div class="banner__thumb-bg banner-4__thumb-bg"
                        data-background="<?php echo esc_url($rr_slider_image);?>"></div>
                    <?php endif; ?>
                    <div class="container">
                        <div class="row">
                            <div class="col-12">
                                <div class="banner__content banner-4__content p-relative z-index-1">
                                    <?php
                                        if ($item['rr_slider_title_tag']) :
                                            printf('<%1$s %2$s>%3$s</%1$s>',
                                                tag_escape($item['rr_slider_title_tag']),
                                                $this->get_render_attribute_string('title_args'),
                                                rr_kses($item['rr_slider_title'])
                                            );
                                        endif; 
                                    ?>
                                    
                                    <?php if ( !empty($item['rr_slider_description']) ) : ?>
                                    <p data-animation="pixfix-fadeInUp" data-delay="1200ms" data-duration="1400ms">
                                        <?php echo rr_kses( $item['rr_slider_description'] ); ?></p>
                                    <?php endif; ?>
                                    <div class="banner-home-2__btn__wrapper-2 banner-4__btn-wrapper"
                                        data-animation="pixfix-fadeInUp" data-delay="1400ms" data-duration="1600ms">
                                        <?php if ( !empty($item['rr_btn_text']) ) : ?>
                                        <a href="<?php echo esc_url($item['rr_btn_link']['url']); ?>"
                                            class="rr-btn btn-hover-white banner-4__btn-wrapper-btn rr-el-btn"><?php echo rr_kses($item['rr_btn_text']);?><i
                                                class="fa-solid fa-arrow-right"></i></a>
                                        <?php endif; ?>
                                        <?php if ( !empty($item['rr_video_text']) ) : ?>
                                        <div class="banner-4__icon-box">
                                            <a href="<?php echo esc_url($item['rr_video_url']['url']); ?>"
                                                class="icon popup-video zooming banner-video-button"
                                                data-effect="mfp-move-from-top vertical-middle">
                                                <svg width="13" height="16" viewBox="0 0 13 16" fill="none"
                                                    xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M12 6.26795C13.3333 7.03775 13.3333 8.96225 12 9.73205L3 14.9282C1.66667 15.698 0 14.7358 0 13.1962L0 2.80385C0 1.26425 1.66667 0.301996 3 1.0718L12 6.26795Z"
                                                        fill="#83CD20" />
                                                </svg>
                                            </a>
                                            <a href="<?php echo esc_url($item['rr_video_url']['url']); ?>"
                                                class="popup-video text"
                                                data-effect="mfp-move-from-top vertical-middle"><?php echo rr_kses($item['rr_video_text']);?></a>
                                        </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        <div class="slider-arrow banner-4__slider-arrow-4">
            <div class="slider-nav slider-next"><i class="fa-sharp fa-regular fa-arrow-right"></i></div>
            <div class="slider-nav slider-prev"><i class="fa-sharp fa-regular fa-arrow-left"></i></div>
        </div>
    </div>
</section>
<?php else:  
?>
<section class="banner__area p-relative z-1 ele-section">
    <div class="swiper banner_parallax-slider p-relative">
        <div class="swiper-wrapper">
            <?php foreach ($settings['slider_list'] as $key => $item) : 
            $this->add_render_attribute('title_args', 'class', 'banner__title wow fade-in-bottom ele-heading');

            if ( !empty($item['rr_slider_image']['url']) ) {
                $rr_slider_image = !empty($item['rr_slider_image']['id']) ? wp_get_attachment_image_url( $item['rr_slider_image']['id'], $settings['thumbnail_size']) : $item['rr_slider_image']['url'];
                $rr_slider_image_alt = get_post_meta($item["rr_slider_image"]["id"], "_wp_attachment_image_alt", true);
            }
      
            ?>
            <div class="swiper-slide">
                <div class="banner banner__space">
                    <div class="banner__thumb-bg" data-background="<?php echo esc_url($rr_slider_image);?>">
                    </div>
                    <div class="container">
                        <div class="row">
                            <div class="col-12">
                                <div class="banner__content p-relative z-index-1 text-center">
                                    <?php
                                    if ($item['rr_slider_title_tag']) :
                                        printf('<%1$s %2$s>%3$s</%1$s>',
                                            tag_escape($item['rr_slider_title_tag']),
                                            $this->get_render_attribute_string('title_args'),
                                            rr_kses($item['rr_slider_title'])
                                        );
                                    endif; ?>
                                    <?php if ( !empty($item['rr_slider_description']) ) : ?>
                                    <p class="h5 wow fadeInLeft animated ele-desc" data-wow-delay=".6s">
                                        <?php echo rr_kses( $item['rr_slider_description'] ); ?></p>
                                    <?php endif; ?>
                                    <?php if ( !empty($item['rr_btn_text']) ) : ?>
                                    <div class="banner-home-2__btn__wrapper-2">
                                        <a href="<?php echo esc_url($item['rr_btn_link']['url']); ?>"
                                            class="rr-btn btn-hover-white wow fadeInLeft animated mt-30 rr-el-btn"
                                            data-wow-delay=".8s"><?php echo rr_kses($item['rr_btn_text']);?> <i
                                                class="fa-solid fa-arrow-right"></i></a>
                                    </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<?php endif; 
		
	}

}

$widgets_manager->register( new rr_Slider() );