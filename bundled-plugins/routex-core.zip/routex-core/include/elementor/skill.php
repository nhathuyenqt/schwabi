<?php
namespace RRCore\Widgets;

use Elementor\Widget_Base;
use \Elementor\Control_Media;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Css_Filter;
use \Elementor\Repeater;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Border;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Group_Control_Typography;
Use \Elementor\Core\Schemes\Typography;
use \Elementor\Utils;
use \Elementor\Group_Control_Box_Shadow;
use RRCore\Elementor\Controls\Group_Control_RRBGGradient;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * RR Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class rr_Skill extends Widget_Base {

    use \RRCore\Widgets\RRCoreElementFunctions;
	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'skill-bar';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Skill', 'rr-core' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'rr-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'rr-core' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'rr-core' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */

    protected function register_controls(){
        $this->register_controls_section();
        $this->style_tab_content();
    }  

	protected function register_controls_section() {

		// layout Panel
		$this->start_controls_section(
            'rr_layout',
            [
                'label' => esc_html__('Design Layout', 'rr-core'),
            ]
		);
		$this->add_control(
            'rr_design_style',
            [
                'label' => esc_html__('Select Layout', 'rr-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                        'layout-1' => esc_html__('Layout 1', 'rr-core'),
                        'layout-2' => esc_html__('Layout 2', 'rr-core'),
                ],
                'default' => 'layout-1',
            ]
		);

		$this->end_controls_section();

        $this->rr_section_title_render_controls('skill', 'Section Title', 'Sub Title', 'your title here', $default_description = 'Hic nesciunt galisum aut dolorem aperiam eum soluta quod ea cupiditate.');


        // Skill
        $this->start_controls_section(
            'rr_progress_bar',
            [
                'label' => esc_html__('Skill Bar', 'rr-core', ['layout-1', 'layout-2']),
            ]
        );

        $repeater = new Repeater();

        
        $repeater->add_control(
            'rr_skill_box_title',
            [
                'type' => Controls_Manager::TEXT,
                'label' => esc_html__( 'Skill Title', 'rr-core' ),
                'default' => esc_html__( 'Design', 'rr-core' ),
                'placeholder' => esc_html__( 'Type a skill name', 'rr-core' ),
                'label_block' => true
            ]
        );

        $repeater->add_control(
            'rr_skill_num',
            [
                'label'       => esc_html__( 'Skill Number', 'rr-core' ),
                'type'        => \Elementor\Controls_Manager::TEXT,
                'default'     => esc_html__( '85', 'rr-core' ),
                'placeholder' => esc_html__( 'Your Number', 'rr-core' ),
            ]
        );

        $this->add_control(
            'rr_skill_list',
            [
                'label' => esc_html__('Services - List', 'rr-core'),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'rr_skill_box_title' => esc_html__('Design', 'rr-core'),
                        'rr_skill_num' => '70',
                    ],
                    [
                        'rr_skill_box_title' => esc_html__('Development', 'rr-core'),
                        'rr_skill_num' => '80',
                    ],
                    [
                        'rr_skill_box_title' => esc_html__('Customization', 'rr-core'),
                        'rr_skill_num' => '95',
                    ],
                ],
                'title_field' => '{{{ rr_skill_box_title }}}',
            ]
        );

        $this->end_controls_section();

	}

    protected function style_tab_content(){
        $this->rr_section_style_controls('skill_section', 'Section - Style', '.rr-el-section');
        $this->rr_basic_style_controls('section_title', 'Section - Title', '.rr-el-title');
        $this->rr_basic_style_controls('heading_title', 'Skill - Title', '.rr-el-title-skill');
        $this->rr_basic_style_controls('skill_number', 'Skill - Number', '.rr-el-skill-number');
    }
	/**
	 * Render the widget ouRRut on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		?>

<?php if ( $settings['rr_design_style']  == 'layout-2' ) : 
        $this->add_render_attribute('title_args', 'class', 'rr-team-details-title');    
    ?>
<div class="rr-team-details-skills fix ele-section overflow-hidden">
    <?php
        if ( !empty($settings['rr_skill_title' ]) ) :
            printf( '<%1$s %2$s>%3$s</%1$s>',
            tag_escape( $settings['rr_skill_title_tag'] ),
            $this->get_render_attribute_string( 'title_args' ),
            rr_kses( $settings['rr_skill_title' ] )
            );
        endif;
        ?>
    <?php if ( !empty($settings['rr_skill_description']) ) : ?>
    <p><?php echo rr_kses( $settings['rr_skill_description'] ); ?></p>
    <?php endif; ?>
    <div class="rr-team-details-skills-progress">
        <?php foreach ( $settings['rr_skill_list'] as $key => $item ) : ?>
        <div class="rr-team-details-progress-item">
            <div class="rr-team-details-progress-title p-relative">
                <h5><?php echo rr_kses($item['rr_skill_box_title']); ?><span class="pursent-1 wow slideInLeft"
                        data-wow-duration=".8s"
                        data-wow-delay=".3s"><?php echo rr_kses($item['rr_skill_num']); ?>%</span></h5>

            </div>
        </div>
        <?php endforeach; ?> 
    </div>
</div>


<?php else:
        // shape image
        if ( !empty($settings['rr_shape_image_1']['url']) ) {
            $rr_shape_image = !empty($settings['rr_shape_image_1']['id']) ? wp_get_attachment_image_url( $settings['rr_shape_image_1']['id'], $settings['shape_image_size_size']) : $settings['rr_shape_image_1']['url'];
            $rr_shape_image_alt = get_post_meta($settings["rr_shape_image_1"]["id"], "_wp_attachment_image_alt", true);
        }
        if ( !empty($settings['rr_shape_image_2']['url']) ) {
            $rr_shape_image_2 = !empty($settings['rr_shape_image_2']['id']) ? wp_get_attachment_image_url( $settings['rr_shape_image_2']['id'], $settings['shape_image_size_size']) : $settings['rr_shape_image_2']['url'];
            $rr_shape_image_alt_2 = get_post_meta($settings["rr_shape_image_2"]["id"], "_wp_attachment_image_alt", true);
        }
        // small thumbnail
        if ( !empty($settings['rr_thumb_img']['url']) ) {
            $rr_thumb_img = !empty($settings['rr_thumb_img']['id']) ? wp_get_attachment_image_url( $settings['rr_thumb_img']['id'], $settings['thumb_image_size_size']) : $settings['rr_thumb_img']['url'];
            $rr_thumb_img_alt = get_post_meta($settings["rr_thumb_img"]["id"], "_wp_attachment_image_alt", true);
        }
        $this->add_render_attribute('title_args', 'class', 'teamdetail__progress-wrapper-title pb-30 wow fadeInLeft animated rr-el-title-skill');
    ?>
<div class="teamdetail__progress pt-30 rr-el-section overflow-hidden">
    <div class="teamdetail__progress-wrapper d-grid">
        <?php
            if ( !empty($settings['rr_skill_title' ]) ) :
                printf( '<%1$s %2$s>%3$s</%1$s>',
                tag_escape( $settings['rr_skill_title_tag'] ),
                $this->get_render_attribute_string( 'title_args' ),
                rr_kses( $settings['rr_skill_title' ] )
                );
            endif;
        ?>
     <?php foreach ( $settings['rr_skill_list'] as $key => $item ) : ?>
        <div class="teamdetail__progress-wrapper-item fix wow fadeIn animated">
            <div class="teamdetail__progress-wrapper-item-content d-flex justify-content-between">
            <?php if(!empty($item['rr_skill_box_title'])) : ?>
                <span class="span-title rr-el-title"><?php echo rr_kses($item['rr_skill_box_title']); ?></span>
            <?php endif; ?>
                <span class="left-side rr-el-skill-number"><?php echo esc_attr($item['rr_skill_num']); ?>%</span>
            </div>

            <div class="progress d-flex">
                <div class="progress-bar wow slideInLeft" data-wow-delay="0s" data-wow-duration=".8s" role="progressbar"
                    data-width="<?php echo esc_attr($item['rr_skill_num']); ?>%" aria-valuenow="<?php echo esc_attr($item['rr_skill_num']); ?>" aria-valuemin="0" aria-valuemax="100">
                </div>
            </div>
            
        </div>
    <?php endforeach; ?>
    </div>
</div>

<?php endif; 
	}

}

$widgets_manager->register( new rr_Skill() );