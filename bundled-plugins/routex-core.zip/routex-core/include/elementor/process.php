<?php
namespace RRCore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Repeater;
use \Elementor\Utils;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * RR Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class rr_Process extends Widget_Base {

    use \RRCore\Widgets\RRCoreElementFunctions;

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'rr-process';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Process', 'rr-core' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'rr-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'rr-core' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'rr-core' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
     
    protected function register_controls(){
        $this->register_controls_section();
        $this->style_tab_content();
    }  

	protected function register_controls_section() {

        // layout Panel
        $this->start_controls_section(
            'rr_layout',
            [
                'label' => esc_html__('Design Layout', 'rr-core'),
            ]
        );
        $this->add_control(
            'rr_design_style',
            [
                'label' => esc_html__('Select Layout', 'rr-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Layout 1', 'rr-core'),
                    'layout-2' => esc_html__('Layout 2', 'rr-core'),
                    'layout-3' => esc_html__('Layout 3', 'rr-core'),
                    'layout-4' => esc_html__('Layout 4', 'rr-core'),
                ],
                'default' => 'layout-1',
            ]
        );

        $this->end_controls_section();
        // _rr_image
        $this->start_controls_section(
        '_rr_image',
        [
            'label' => esc_html__('Thumbnail', 'rr-core'),
            'condition' => [
                'rr_design_style' => ['layout-1', 'layout-2', 'layout-3', 'layout-4']
            ]
        ]
    );
    $this->add_control(
        'rr_image',
        [
            'label' => esc_html__( 'Choose Image', 'rr-core' ),
            'type' => \Elementor\Controls_Manager::MEDIA,
            'default' => [
                'url' => \Elementor\Utils::get_placeholder_image_src(),
            ],
        ]
    );

    $this->add_group_control(
        Group_Control_Image_Size::get_type(),
        [
            'name' => 'rr_image_size',
            'default' => 'full',
        ]
    );

    $this->end_controls_section();
            // title/content
    $this->rr_section_title_render_controls('section', 'Section Title', 'Sub Title', 'your title here', $default_description = 'Hic nesciunt galisum aut dolorem aperiam eum soluta quod ea cupiditate.', ['layout-1', 'layout-2', 'layout-3', 'layout-4'] );
        // Process group
        $this->start_controls_section(
            'rr_process',
            [
                'label' => esc_html__('Process List', 'rr-core'),
                'description' => esc_html__( 'Control all the style settings from Style tab', 'rr-core' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'repeater_condition',
            [
                'label' => __( 'Field condition', 'rr-core' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'style_1' => __( 'Style 1', 'rr-core' ),
                    'style_2' => __( 'Style 2', 'rr-core' ),
                ],
                'default' => 'style_1',
                'frontend_available' => true,
                'style_transfer' => true,
            ] 
        );
        

        $repeater->add_control(
            'rr_process_icon_type_list',
            [
                'label' => esc_html__('Select Icon Type', 'rr-core'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'icon',
                'options' => [
                    'image' => esc_html__('Image', 'rr-core'),
                    'icon' => esc_html__('Icon', 'rr-core'),
                    'svg' => esc_html__('SVG', 'rr-core'),
                ],
            ]
        );

        $repeater->add_control(
            'rr_process_image_list',
            [
                'label' => esc_html__('Upload Icon Image', 'rr-core'),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
                'condition' => [
                    'rr_process_icon_type_list' => 'image'
                ]

            ]
        );

        if (rr_is_elementor_version('<', '2.6.0')) {
            $repeater->add_control(
                'rr_process_icon_list',
                [
                    'show_label' => false,
                    'type' => Controls_Manager::ICON,
                    'label_block' => true,
                    'default' => 'fa fa-star',
                    'condition' => [
                        'rr_process_icon_type_list' => 'icon'
                    ]
                ]
            );
        } else {
            $repeater->add_control(
                'rr_process_selected_icon_list',
                [
                    'show_label' => false,
                    'type' => Controls_Manager::ICONS,
                    'fa4compatibility' => 'icon',
                    'label_block' => true,
                    'default' => [
                        'value' => 'fas fa-star',
                        'library' => 'solid',
                    ],
                    'condition' => [
                        'rr_process_icon_type_list' => 'icon'
                    ]
                ]
            );
        }

        $repeater->add_control(
            'rr_process_icon_svg_list',
            [
                'show_label' => false,
                'type' => Controls_Manager::TEXTAREA,
                'label_block' => true,
                'placeholder' => esc_html__('SVG Code Here', 'rr-core'),
                'condition' => [
                    'rr_process_icon_type_list' => 'svg',
                ]
            ]
        );


        $repeater->add_control(
            'rr_process_title', [
                'label' => esc_html__('Title', 'rr-core'),
                'description' => rr_get_allowed_html_desc( 'basic' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('Process Title', 'rr-core'),
                'label_block' => true,
            ]
        );
        $repeater->add_control(
            'rr_process_url',
            [
                'label' => esc_html__( 'Process Url', 'text-domain' ),
                'type' => Controls_Manager::URL,
                'options' => [ 'url', 'is_external', 'nofollow' ],
                'default' => [
                    'url' => '',
                    'is_external' => true,
                    'nofollow' => true,
                ],
                'label_block' => true,
            ]
        );

        $repeater->add_control(
            'rr_process_des', [
                'label' => esc_html__('Description', 'rr-core'),
                'description' => rr_get_allowed_html_desc( 'basic' ),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'default' => esc_html__('onec suscipit ante ipsum. Donec quam at tortor hendrerit', 'rr-core'),
                'label_block' => true,
                'condition' => [
                    'repeater_condition' => 'style_1',
                ]
            ]
        );

        $this->add_control(
            'rr_process_list',
            [
                'label' => esc_html__('Processs - List', 'rr-core'),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'rr_process_title' => esc_html__('Discover', 'rr-core'),
                    ],
                    [
                        'rr_process_title' => esc_html__('Define', 'rr-core')
                    ],
                    [
                        'rr_process_title' => esc_html__('Develop', 'rr-core')
                    ]
                ],
                'title_field' => '{{{ rr_process_title }}}',
            ]
        );

        $this->end_controls_section();

	}

    // style_tab_content
    protected function style_tab_content(){
        $this->rr_section_style_controls('process_section', 'Section - Style', '.rr-el-section'); 
        $this->rr_basic_style_controls('section_sub_title', 'Section - Sub Title', '.rr-el-sub-title');
        $this->rr_basic_style_controls('section_title', 'Section - Title', '.rr-el-title');
        $this->rr_basic_style_controls('section_desc', 'Section - Description', '.rr-el-desc');
        $this->rr_basic_style_controls('process_title', 'Process - Title', '.rr-rp-title');
        $this->rr_basic_style_controls('process_desc', 'Process - Description', '.rr-rp-desc');
        $this->rr_basic_style_controls('process_number', 'Process - Number', '.rr-rp-number');
    }

	/**
	 * Render the widget ouRRut on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		?>

<?php if ( $settings['rr_design_style']  == 'layout-2' ) :
if ( !empty($settings['rr_image']['url']) ) {
    $rr_image = !empty($settings['rr_image']['id']) ? wp_get_attachment_image_url( $settings['rr_image']['id'], $settings['rr_image_size_size']) : $settings['rr_image']['url'];
    $rr_bg_image_alt = get_post_meta($settings["rr_image"]["id"], "_wp_attachment_image_alt", true);
}
    $this->add_render_attribute('title_args', 'class', 'section__title-wrapper-title wow fadeInLeft animated rr-el-title'); 
?>
<section class="gray-bg overflow-hidden position-relative rr-el-section">
    <div
        class="process-overview__area position-relative overflow-hidden section-top bottom-356 custom-width border white-bg">
        <div class="process-overview__bg-img" data-background="<?php echo esc_url($rr_image); ?>"></div>
        <div class="container">
            <div class="row">
                <?php if ( !empty($settings['rr_section_section_title_show']) ) : ?>
                <div class="section__title-wrapper text-center mb-40">
                    <?php if ( !empty($settings['rr_section_sub_title']) ) : ?>
                    <h6 class="section__title-wrapper-center-subtitle mb-10 wow fadeInLeft animated rr-el-sub-title"
                        data-wow-delay=".6s">
                        <svg width="53" height="10" viewBox="0 0 53 10" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <g clip-path="url(#clip0_3800_434)">
                                <path
                                    d="M5.28951 2.14437C6.08938 2.36766 6.91161 2.50135 7.74102 2.54299L14.4245 3.26714C15.9366 3.43986 17.4277 3.76256 18.8758 4.23048C19.665 4.49614 20.4243 4.84349 21.1413 5.2669C21.9175 5.78994 22.7251 6.26475 23.5596 6.68864C24.0625 6.92402 24.6122 7.04215 25.1674 7.03411C25.7786 6.99856 26.3565 6.7438 26.7951 6.3166C27.6388 5.44628 27.8713 4.38993 28.4228 3.71228C28.6509 3.37951 28.994 3.14288 29.3861 3.04791C29.8064 2.95474 30.2447 2.98472 30.6484 3.13427C31.5548 3.46398 32.3151 4.10423 32.7943 4.94135C33.3723 5.79839 33.8241 6.775 34.4818 7.69183C35.1219 8.67698 36.0705 9.42226 37.1791 9.81116C37.761 9.97733 38.3777 9.97733 38.9596 9.81116C39.5109 9.64765 40.0192 9.36403 40.4478 8.9807C41.2142 8.27735 41.8115 7.40973 42.1951 6.44282C42.5804 5.55257 42.8595 4.68889 43.2448 3.93151C43.6867 2.89622 44.489 2.05634 45.503 1.56765C46.5171 1.07897 47.6739 0.974642 48.759 1.27404C49.3354 1.41933 49.8741 1.6859 50.3393 2.05594C50.8044 2.42599 51.1852 2.89102 51.4564 3.41996C51.89 4.23627 52.0965 5.15404 52.0543 6.07742C52.0377 6.66905 51.9115 7.25247 51.6822 7.79813C51.5294 8.18346 51.4231 8.37613 51.4564 8.40271C51.4896 8.42928 51.649 8.26318 51.8749 7.89778C52.201 7.3528 52.4029 6.74258 52.4662 6.11063C52.5934 5.09968 52.4274 4.07346 51.9879 3.1542C51.7001 2.52884 51.2812 1.97266 50.7596 1.52332C50.2381 1.07399 49.626 0.742013 48.965 0.549886C48.1576 0.314234 47.3078 0.262331 46.4777 0.397987C45.6477 0.533642 44.8586 0.85342 44.1682 1.33384C43.4171 1.89515 42.8149 2.63192 42.4143 3.47975C41.9825 4.31021 41.6769 5.18716 41.2982 6.01762C40.964 6.84506 40.446 7.58567 39.7834 8.18347C39.4811 8.47409 39.1083 8.68086 38.7017 8.78339C38.2951 8.88592 37.8687 8.88064 37.4648 8.7681C36.5933 8.44143 35.8501 7.84273 35.3455 7.06068C34.7675 6.2568 34.3157 5.28018 33.6845 4.33678C33.3635 3.84764 32.9818 3.40117 32.5485 3.00804C32.0919 2.61118 31.5613 2.30862 30.9872 2.11779C30.3948 1.91517 29.7578 1.88068 29.1469 2.01814C28.5271 2.17131 27.9813 2.53834 27.6056 3.05455C26.9014 3.99795 26.6622 5.04765 26.0908 5.5725C25.8315 5.83263 25.4872 5.99065 25.1209 6.01762C24.7173 6.02071 24.3179 5.9345 23.9516 5.76517C23.1493 5.36762 22.3707 4.92396 21.6196 4.43644C20.842 3.99071 20.0177 3.632 19.1615 3.36681C17.6463 2.91365 16.0874 2.62192 14.5109 2.49649C11.6541 2.25731 9.36208 2.18423 7.7676 2.1045C6.94264 2.02614 6.11152 2.03952 5.28951 2.14437Z"
                                    fill="#034833" />
                                <path
                                    d="M7.0238 6.2697C7.07695 6.13018 6.35945 5.7382 5.27653 5.08712C4.73175 4.76158 4.0873 4.36296 3.39636 3.89126C3.05089 3.65873 2.73199 3.39963 2.33337 3.13388C2.16268 3.0178 2.00459 2.88421 1.86167 2.73527C1.74212 2.61795 1.64726 2.47789 1.58265 2.32336C1.54943 2.19713 1.58265 2.20377 1.58265 2.15726C1.67899 2.06916 1.79914 2.01139 1.92811 1.99117L3.21699 1.64571C4.0408 1.41982 4.77825 1.20058 5.39611 0.981341C6.63183 0.582721 7.38921 0.263819 7.3427 0.124302C7.2962 -0.0152149 6.49897 0.0379361 5.21674 0.250534C4.55237 0.356832 3.82156 0.502993 2.98446 0.675728L1.65572 0.968051C1.31604 1.02987 1.00451 1.19726 0.765472 1.4464C0.617425 1.61431 0.522614 1.82242 0.493079 2.04432C0.465887 2.24825 0.488692 2.45574 0.55952 2.6489C0.670868 2.94985 0.847895 3.2222 1.07773 3.44614C1.26497 3.63879 1.47464 3.80831 1.70223 3.95105C2.08756 4.23009 2.47953 4.47591 2.85157 4.70179C3.5155 5.09883 4.20842 5.44528 4.92442 5.7382C6.16014 6.25641 6.97065 6.40257 7.0238 6.2697Z"
                                    fill="#034833" />
                            </g>
                            <defs>
                                <clipPath id="clip0_3800_434">
                                    <rect width="52" height="9.86585" fill="white"
                                        transform="matrix(-1 0 0 1 52.5 0.0664062)" />
                                </clipPath>
                            </defs>
                        </svg>
                        <?php echo rr_kses( $settings['rr_section_sub_title'] ); ?>
                        <svg width="53" height="10" viewBox="0 0 53 10" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <g clip-path="url(#clip0_3795_128)">
                                <path
                                    d="M47.7095 2.14437C46.9096 2.36766 46.0874 2.50135 45.258 2.54299L38.5745 3.26714C37.0625 3.43986 35.5713 3.76256 34.1232 4.23048C33.334 4.49614 32.5748 4.84349 31.8577 5.2669C31.0815 5.78994 30.2739 6.26475 29.4394 6.68864C28.9366 6.92402 28.3868 7.04215 27.8317 7.03411C27.2204 6.99856 26.6425 6.7438 26.204 6.3166C25.3602 5.44628 25.1277 4.38993 24.5763 3.71228C24.3482 3.37951 24.005 3.14288 23.6129 3.04791C23.1926 2.95474 22.7543 2.98472 22.3506 3.13427C21.4442 3.46398 20.6839 4.10423 20.2047 4.94135C19.6267 5.79839 19.175 6.775 18.5172 7.69183C17.8771 8.67698 16.9285 9.42226 15.8199 9.81116C15.238 9.97733 14.6213 9.97733 14.0394 9.81116C13.4881 9.64765 12.9799 9.36403 12.5512 8.9807C11.7848 8.27735 11.1875 7.40973 10.8039 6.44282C10.4186 5.55257 10.1396 4.68889 9.75423 3.93151C9.31236 2.89622 8.51001 2.05634 7.49598 1.56765C6.48195 1.07897 5.32509 0.974642 4.24 1.27404C3.66364 1.41933 3.12491 1.6859 2.65977 2.05594C2.19463 2.42599 1.8138 2.89102 1.54267 3.41996C1.10903 4.23627 0.90251 5.15404 0.944721 6.07742C0.961366 6.66905 1.08753 7.25247 1.31679 7.79813C1.46959 8.18346 1.57589 8.37613 1.54267 8.40271C1.50945 8.42928 1.35 8.26318 1.12411 7.89778C0.797997 7.3528 0.596096 6.74258 0.532817 6.11063C0.405578 5.09968 0.57162 4.07346 1.01116 3.1542C1.29897 2.52884 1.71785 1.97266 2.23939 1.52332C2.76094 1.07399 3.37299 0.742013 4.03404 0.549886C4.8414 0.314234 5.69125 0.262331 6.52128 0.397987C7.35131 0.533642 8.14045 0.85342 8.83077 1.33384C9.58192 1.89515 10.1841 2.63192 10.5847 3.47975C11.0165 4.31021 11.3221 5.18716 11.7008 6.01762C12.035 6.84506 12.553 7.58567 13.2156 8.18347C13.5179 8.47409 13.8907 8.68086 14.2973 8.78339C14.704 8.88592 15.1303 8.88064 15.5342 8.7681C16.4058 8.44143 17.1489 7.84273 17.6536 7.06068C18.2316 6.2568 18.6833 5.28018 19.3145 4.33678C19.6355 3.84764 20.0172 3.40117 20.4505 3.00804C20.9071 2.61118 21.4377 2.30862 22.0118 2.11779C22.6043 1.91517 23.2412 1.88068 23.8521 2.01814C24.4719 2.17131 25.0177 2.53834 25.3934 3.05455C26.0977 3.99795 26.3368 5.04765 26.9082 5.5725C27.1675 5.83263 27.5118 5.99065 27.8782 6.01762C28.2818 6.02071 28.6811 5.9345 29.0475 5.76517C29.8497 5.36762 30.6284 4.92396 31.3794 4.43644C32.157 3.99071 32.9814 3.632 33.8375 3.36681C35.3527 2.91365 36.9116 2.62192 38.4881 2.49649C41.3449 2.25731 43.6369 2.18423 45.2314 2.1045C46.0564 2.02614 46.8875 2.03952 47.7095 2.14437Z"
                                    fill="#034833" />
                                <path
                                    d="M45.9762 6.2697C45.9231 6.13018 46.6406 5.7382 47.7235 5.08712C48.2683 4.76158 48.9127 4.36296 49.6036 3.89126C49.9491 3.65873 50.268 3.39963 50.6666 3.13388C50.8373 3.0178 50.9954 2.88421 51.1383 2.73527C51.2579 2.61795 51.3527 2.47789 51.4173 2.32336C51.4506 2.19713 51.4173 2.20377 51.4173 2.15726C51.321 2.06916 51.2009 2.01139 51.0719 1.99117L49.783 1.64571C48.9592 1.41982 48.2218 1.20058 47.6039 0.981341C46.3682 0.582721 45.6108 0.263819 45.6573 0.124302C45.7038 -0.0152149 46.501 0.0379361 47.7833 0.250534C48.4476 0.356832 49.1784 0.502993 50.0155 0.675728L51.3443 0.968051C51.684 1.02987 51.9955 1.19726 52.2345 1.4464C52.3826 1.61431 52.4774 1.82242 52.5069 2.04432C52.5341 2.24825 52.5113 2.45574 52.4405 2.6489C52.3291 2.94985 52.1521 3.2222 51.9223 3.44614C51.735 3.63879 51.5254 3.80831 51.2978 3.95105C50.9124 4.23009 50.5205 4.47591 50.1484 4.70179C49.4845 5.09883 48.7916 5.44528 48.0756 5.7382C46.8399 6.25641 46.0294 6.40257 45.9762 6.2697Z"
                                    fill="#034833" />
                            </g>
                            <defs>
                                <clipPath id="clip0_3795_128">
                                    <rect width="52" height="9.86585" fill="white"
                                        transform="translate(0.5 0.0664062)" />
                                </clipPath>
                            </defs>
                        </svg>
                    </h6>
                    <?php endif; ?>
                    <?php
                        if ( !empty($settings['rr_section_title' ]) ) :
                            printf( '<%1$s %2$s>%3$s</%1$s>',
                            tag_escape( $settings['rr_section_title_tag'] ),
                            $this->get_render_attribute_string( 'title_args' ),
                            rr_kses( $settings['rr_section_title' ] )
                            );
                        endif;
                    ?>

                </div>
                <?php endif; ?>
            </div>
            <div class="row justify-content-center mb-minus-30">
                <?php foreach ($settings['rr_process_list'] as $key => $item) : ?>
                <div class="col-lg-4 col-md-6">
                    <div class="process-overview__wrap mb-30">
                        <div class="process-overview__item wow fadeInLeft animated" data-wow-delay=".2s">
                            <span class="rr-rp-number">0<?php echo $key+1; ?></span>
                            <?php if (!empty($item['rr_process_title'])): ?>
                            <h3 class="process-overview__title mb-20 rr-rp-title"><a
                                    href="<?php echo rr_kses($item['rr_process_url']['url']); ?>"><?php echo rr_kses($item['rr_process_title' ]); ?></a>
                            </h3>
                            <?php endif; ?>
                            <?php if (!empty($item['rr_process_des'])): ?>
                            <p class="rr-rp-desc"><?php echo rr_kses($item['rr_process_des' ]); ?></p>
                            <?php endif; ?>
                        </div>
                        <div class="process-overview__icon">
                            <?php if($item['rr_process_icon_type_list'] == 'icon') : ?>
                            <?php if (!empty($item['rr_process_icon_list']) || !empty($item['rr_process_selected_icon_list']['value'])) : ?>
                            <?php rr_render_icon($item, 'rr_process_icon_list', 'rr_process_selected_icon_list'); ?>
                            <?php endif; ?>
                            <?php elseif( $item['rr_process_icon_type_list'] == 'image' ) : ?>
                            <?php if (!empty($item['rr_process_image_list']['url'])): ?>
                            <img src="<?php echo $item['rr_process_image_list']['url']; ?>"
                                alt="<?php echo get_post_meta(attachment_url_to_postid($item['rr_process_image_list']['url']), '_wp_attachment_image_alt', true); ?>">
                            <?php endif; ?>
                            <?php else : ?>
                            <?php if (!empty($item['rr_process_icon_svg_list'])): ?>
                            <?php echo $item['rr_process_icon_svg_list']; ?>
                            <?php endif; ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</section>
<?php elseif ( $settings['rr_design_style']  == 'layout-3' ) :

if ( !empty($settings['rr_image']['url']) ) {
    $rr_image = !empty($settings['rr_image']['id']) ? wp_get_attachment_image_url( $settings['rr_image']['id'], $settings['rr_image_size_size']) : $settings['rr_image']['url'];
    $rr_bg_image_alt = get_post_meta($settings["rr_image"]["id"], "_wp_attachment_image_alt", true);
}

    $this->add_render_attribute('title_args', 'class', 'section-title2__wrapper-title  wow fadeInLeft animated rr-el-title'); 
?>

<section
    class="overview__area custom-width section-space bottom p-relative border overflow-hidden gray-bg  rr-el-section">
    <div class="overview__bg-img" data-background="<?php echo esc_url($rr_image); ?>"></div>
    <div class="container">
        <div class="row">
            <div class="col-12">
                <?php if ( !empty($settings['rr_section_section_title_show']) ) : ?>
                <div class="section-title2 mb-60">
                    <div class="section-title2__wrapper">
                        <?php if ( !empty($settings['rr_section_sub_title']) ) : ?>
                        <span class="section-title2__wrapper-subtitle wow fadeInLeft animated rr-el-sub-title"
                            data-wow-delay=".2s"><?php echo rr_kses( $settings['rr_section_sub_title'] ); ?>
                            <svg width="14" height="13" viewBox="0 0 14 13" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <g clip-path="url(#clip0_3800_1041)">
                                    <path d="M4.9248 11.3553L6.49525 10.661L5.62485 10.0508L4.9248 11.3553Z"
                                        fill="#83CD20" />
                                    <path
                                        d="M4.9248 11.3548L4.99976 8.98047L13.9078 0.980469L5.66407 10.0918L4.9248 11.3548Z"
                                        fill="#83CD20" />
                                    <path d="M5 8.98047L13.908 0.980469L0 7.2075L5 8.98047Z" fill="#83CD20" />
                                    <path d="M5.66406 10.0918L9.95686 12.9805L13.9078 0.980469L5.66406 10.0918Z"
                                        fill="#034833" />
                                </g>
                                <defs>
                                    <clipPath id="clip0_3800_1041">
                                        <rect width="13.908" height="12" fill="white"
                                            transform="translate(0 0.980469)" />
                                    </clipPath>
                                </defs>
                            </svg>
                        </span>
                        <?php endif; ?>
                        <?php
                        if ( !empty($settings['rr_section_title' ]) ) :
                            printf( '<%1$s %2$s>%3$s</%1$s>',
                            tag_escape( $settings['rr_section_title_tag'] ),
                            $this->get_render_attribute_string( 'title_args' ),
                            rr_kses( $settings['rr_section_title' ] )
                            );
                        endif;
                    ?>
                    </div>
                    <?php if ( !empty($settings['rr_section_description']) ) : ?>
                    <p class="section-title2__paragraph wow fadeInLeft animated rr-el-desc" data-wow-delay=".4s">
                        <?php echo rr_kses( $settings['rr_section_description']);?></p>
                    <?php endif; ?>
                </div>
                <?php endif; ?>
            </div>
        </div>
        <div class="row mb-minus-30">
            <?php foreach ($settings['rr_process_list'] as $key => $item) : ?>
            <div class="col-lg-4 col-md-6 col-sm-6">
                <div class="overview__item mb-30 wow fadeInLeft animated" data-wow-delay=".4s">
                    <div class="overview__icon p-relative">
                        <div class="overview__icon-number">
                            <span class="rr-rp-number">0<?php echo $key+1; ?></span>
                        </div>
                        <?php if($item['rr_process_icon_type_list'] == 'icon') : ?>
                        <?php if (!empty($item['rr_process_icon_list']) || !empty($item['rr_process_selected_icon_list']['value'])) : ?>
                        <?php rr_render_icon($item, 'rr_process_icon_list', 'rr_process_selected_icon_list'); ?>
                        <?php endif; ?>
                        <?php elseif( $item['rr_process_icon_type_list'] == 'image' ) : ?>
                        <?php if (!empty($item['rr_process_image_list']['url'])): ?>
                        <img src="<?php echo $item['rr_process_image_list']['url']; ?>"
                            alt="<?php echo get_post_meta(attachment_url_to_postid($item['rr_process_image_list']['url']), '_wp_attachment_image_alt', true); ?>">
                        <?php endif; ?>
                        <?php else : ?>
                        <?php if (!empty($item['rr_process_icon_svg_list'])): ?>
                        <?php echo $item['rr_process_icon_svg_list']; ?>
                        <?php endif; ?>
                        <?php endif; ?>
                    </div>
                    <div class="overview__text">
                        <?php if (!empty($item['rr_process_title'])): ?>
                        <h5 class="overview__text-title mb-20 rr-rp-title">
                            <?php echo rr_kses($item['rr_process_title' ]); ?></h5>
                        <?php endif; ?>
                        <?php if (!empty($item['rr_process_des'])): ?>
                        <p class="rr-rp-desc"><?php echo rr_kses($item['rr_process_des' ]); ?></p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>
<?php elseif ( $settings['rr_design_style']  == 'layout-4' ) :

if ( !empty($settings['rr_image']['url']) ) {
    $rr_image = !empty($settings['rr_image']['id']) ? wp_get_attachment_image_url( $settings['rr_image']['id'], $settings['rr_image_size_size']) : $settings['rr_image']['url'];
    $rr_bg_image_alt = get_post_meta($settings["rr_image"]["id"], "_wp_attachment_image_alt", true);
}

    $this->add_render_attribute('title_args', 'class', 'section__title-wrapper-title wow fadeInLeft  animated rr-el-title'); 
?>

<section class="process__area border-1px section-space custom-width p-relative overflow-hidden z-1 rr-el-section">
    <div class="process__bg-img" data-background="<?php echo esc_url($rr_image); ?>"></div>
    <div class="container">
        <div class="row">
        <?php if ( !empty($settings['rr_section_section_title_show']) ) : ?>
            <div class="section__title-wrapper text-center mb-60">
                <?php if ( !empty($settings['rr_section_sub_title']) ) : ?>
                <h6 class="section__title-wrapper-center-subtitle mb-10 wow fadeInLeft  animated rr-el-sub-title" data-wow-delay=".2s">
                    <svg width="20" height="21" viewBox="0 0 20 21" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <g clip-path="url(#clip0_5704_198)">
                            <path
                                d="M19.3 2.67377C19.2618 2.59399 19.1936 2.53259 19.1103 2.50302L12.1959 0.0621048C12.0224 0.000729911 11.832 0.0918964 11.7706 0.265396L10.2 4.70972H9.51302V3.57639C9.513 3.42331 9.47783 3.27229 9.41023 3.13495C9.34263 2.99761 9.2444 2.87762 9.12311 2.78424C9.00182 2.69086 8.86071 2.62656 8.71066 2.59632C8.5606 2.56608 8.4056 2.57069 8.25761 2.60981L0.248416 4.7208V4.7268C0.177823 4.74455 0.115123 4.78523 0.0701599 4.84247C0.0251971 4.89971 0.000518721 4.97027 0 5.04305L0 19.043C0 19.5953 0.447749 20.043 0.999998 20.043H10.3333C10.8856 20.043 11.3333 19.5953 11.3333 19.043V16.0184L14.0066 16.9622C14.1803 17.0233 14.3707 16.9324 14.4319 16.7587L19.3143 2.92847C19.3287 2.88716 19.3349 2.8434 19.3325 2.79969C19.33 2.75598 19.319 2.71319 19.2999 2.67377H19.3ZM8.42769 3.25264C8.47703 3.23964 8.52869 3.23812 8.57871 3.24819C8.62873 3.25827 8.67577 3.27968 8.71623 3.31076C8.7567 3.34193 8.78947 3.38197 8.81202 3.4278C8.83456 3.47363 8.84628 3.52402 8.84627 3.5751V4.70972H2.90366L8.42769 3.25264ZM10.6666 19.043C10.6666 19.1314 10.6315 19.2162 10.569 19.2787C10.5065 19.3412 10.4217 19.3764 10.3333 19.3764H0.999998C0.911593 19.3764 0.826808 19.3412 0.764296 19.2787C0.701784 19.2162 0.666665 19.1314 0.666665 19.043V5.37638H10.3333C10.4217 5.37638 10.5065 5.4115 10.569 5.47402C10.6315 5.53653 10.6666 5.62131 10.6666 5.70972V19.043ZM13.4067 6.64542L13.8333 6.44313L14.0366 6.86842L12.417 11.452C12.3877 11.5354 12.3926 11.627 12.4306 11.7068L12.7776 12.4327L12.6704 12.737L12.0093 12.0525C11.9734 12.0151 11.9294 11.9866 11.8806 11.9692C11.8318 11.9518 11.7797 11.9461 11.7283 11.9524L11.3333 12.0024V11.5557L11.6176 11.4197C11.6974 11.3816 11.7588 11.3134 11.7884 11.2301L12.4551 9.34479L13.4067 6.64542ZM14.0353 8.87034L14.7121 9.95775L14.5963 10.2854L13.7866 9.57642L14.0353 8.87034ZM11.3333 10.516V9.6L11.6613 9.58633L11.3333 10.516ZM11.9001 8.90942L11.3333 8.93271V8.489L12.1494 8.20434L11.9001 8.90942ZM13.9141 16.2224L11.3333 15.3114V12.6743L11.6456 12.6353L12.5667 13.5881C12.598 13.6199 12.6353 13.6452 12.6765 13.6624C12.7177 13.6795 12.762 13.6882 12.8066 13.688C12.8304 13.6882 12.8541 13.6856 12.8773 13.6804C12.9328 13.6683 12.9843 13.6423 13.0268 13.6047C13.0694 13.5671 13.1017 13.5193 13.1206 13.4657L13.4539 12.5227C13.4834 12.4393 13.4785 12.3477 13.4402 12.2681L13.0916 11.543L13.5477 10.2514L14.527 11.1098C14.5878 11.1631 14.6659 11.1925 14.7468 11.1925C14.7752 11.1925 14.8036 11.1887 14.8311 11.1814C14.8837 11.1676 14.9322 11.1411 14.9723 11.1043C15.0124 11.0675 15.0429 11.0214 15.0611 10.9701L15.3944 10.0271C15.411 9.97996 15.4168 9.9297 15.4114 9.88002C15.406 9.83035 15.3894 9.78253 15.363 9.74013L14.3196 8.06405L14.7103 6.9578C14.7249 6.91647 14.7312 6.87267 14.7289 6.8289C14.7265 6.78513 14.7156 6.74225 14.6966 6.70272L14.2901 5.85247C14.2712 5.81295 14.2447 5.77754 14.2121 5.74826C14.1796 5.71898 14.1416 5.6964 14.1003 5.68181C14.059 5.66722 14.0152 5.66091 13.9715 5.66324C13.9277 5.66557 13.8849 5.67649 13.8454 5.69538L12.9946 6.10213C12.9552 6.121 12.9199 6.14745 12.8906 6.17998C12.8614 6.21251 12.8389 6.25048 12.8244 6.29172L12.4333 7.39934L11.3333 7.78305V5.70972C11.3329 5.53913 11.2888 5.3715 11.2051 5.22286C11.1214 5.07422 11.0009 4.94954 10.8553 4.86076L11.4001 3.31601L11.5223 2.96947L12.2891 0.802812L18.5753 3.02172L13.9141 16.2224Z"
                                fill="#034833"></path>
                            <path
                                d="M16.5439 5.13329L16.7657 4.50454L17.3374 4.7062L17.1155 5.33495L16.5439 5.13329ZM11.972 3.51917L12.194 2.89062L12.7654 3.09242L12.5434 3.721L11.972 3.51917ZM15.4008 4.72979L15.6228 4.10104L16.1943 4.30287L15.9723 4.93145L15.4008 4.72979ZM13.115 3.92283L13.337 3.29425L13.9083 3.49608L13.6863 4.12466L13.115 3.92283ZM14.2579 4.326L14.48 3.69741L15.0514 3.89925L14.8294 4.52779L14.2579 4.326ZM5.51301 6.71091C3.67202 6.71091 2.17969 8.20324 2.17969 10.0442C2.17969 11.8852 3.67202 13.3776 5.51301 13.3776C7.35401 13.3776 8.84634 11.8852 8.84634 10.0442C8.84438 8.20424 7.35318 6.71299 5.51301 6.71091ZM7.92005 8.90457L7.4653 8.80465C7.2653 8.76053 7.06522 8.72557 6.86322 8.69528C6.83297 8.4935 6.79646 8.29271 6.75372 8.0932L6.65359 7.63861C7.20852 7.90276 7.65568 8.34975 7.92005 8.90457ZM2.84631 10.0442C2.84698 9.90799 2.85806 9.77194 2.87969 9.63732L3.70393 9.4539C3.83039 9.4259 3.95768 9.40265 4.08527 9.38065C4.05304 9.82251 4.05304 10.2661 4.08527 10.708C3.95764 10.686 3.83039 10.6626 3.70393 10.6346L2.87969 10.4513C2.85809 10.3167 2.84695 10.1806 2.84635 10.0442H2.84631ZM4.76172 9.29328C5.26137 9.24868 5.76399 9.24868 6.26364 9.29328C6.30839 9.79292 6.30839 10.2956 6.26364 10.7952C5.76399 10.84 5.26133 10.84 4.76168 10.7952C4.71693 10.2956 4.71697 9.79292 4.76172 9.29328ZM6.93926 9.38065C7.06701 9.40265 7.1943 9.4259 7.32059 9.4539L8.14497 9.63732C8.19119 9.90668 8.19119 10.182 8.14497 10.4513L7.32059 10.6346C7.19434 10.6626 7.06701 10.686 6.93926 10.7083C6.97165 10.2664 6.97165 9.82262 6.93926 9.38065ZM5.91972 7.41095L6.10301 8.23565C6.13101 8.36195 6.1546 8.48924 6.17676 8.61699C5.73474 8.5846 5.29095 8.5846 4.84893 8.61699C4.87106 8.48924 4.89435 8.36195 4.92268 8.23565L5.10593 7.41095C5.37527 7.36521 5.65039 7.36521 5.91972 7.41095ZM4.37306 7.6362L4.27293 8.09095C4.22898 8.29095 4.19397 8.49103 4.16373 8.69303C3.96195 8.72316 3.76116 8.75957 3.56164 8.8022L3.10689 8.90232C3.37146 8.34799 3.81845 7.90139 4.37302 7.63732L4.37306 7.6362ZM3.10623 11.1829L3.56098 11.283C3.76098 11.3269 3.96085 11.3619 4.16306 11.3922C4.19319 11.594 4.2296 11.7948 4.27222 11.9943L4.37235 12.4489C3.8175 12.185 3.37024 11.7383 3.10556 11.1839L3.10623 11.1829ZM5.10622 12.6756L4.92293 11.8509C4.8946 11.7249 4.87135 11.5973 4.84918 11.4699C5.06993 11.486 5.2916 11.4969 5.51326 11.4969C5.73493 11.4969 5.95597 11.486 6.17701 11.4699C6.15489 11.5973 6.13126 11.7249 6.10326 11.8509L5.92001 12.6756C5.65068 12.7213 5.37556 12.7213 5.10622 12.6756ZM6.65289 12.4503L6.75301 11.9956C6.7973 11.7956 6.83197 11.5956 6.86259 11.3935C7.06434 11.3633 7.2651 11.3269 7.46459 11.2843L7.91918 11.1842C7.65505 11.7395 7.20779 12.1869 6.65259 12.4513L6.65289 12.4503ZM2.84635 16.0442H8.17967V16.7109H2.84635V16.0442ZM3.51302 17.3776H7.51301V18.0442H3.51302V17.3776ZM5.17968 14.7109H5.84635V15.3776H5.17968V14.7109ZM3.84635 14.7109H4.51302V15.3776H3.84635V14.7109ZM6.51301 14.7109H7.17968V15.3776H6.51301V14.7109Z"
                                fill="#034833"></path>
                        </g>
                        <defs>
                            <clipPath id="clip0_5704_198">
                                <rect width="20" height="20" fill="white" transform="translate(0 0.0429688)"></rect>
                            </clipPath>
                        </defs>
                    </svg>
                    <?php echo rr_kses( $settings['rr_section_sub_title'] ); ?>
                </h6>
                <?php endif; ?>
                <?php
                        if ( !empty($settings['rr_section_title' ]) ) :
                            printf( '<%1$s %2$s>%3$s</%1$s>',
                            tag_escape( $settings['rr_section_title_tag'] ),
                            $this->get_render_attribute_string( 'title_args' ),
                            rr_kses( $settings['rr_section_title' ] )
                            );
                        endif;
                    ?>
            </div>
        <?php endif; ?>
        </div>
        <div class="row mb-minus-30">
        <?php foreach ($settings['rr_process_list'] as $key => $item) : ?>
            <div class="col-xl-4 col-lg-4 col-md-6">
                <div class="process__item process__item-<?php echo $key+1; ?> mb-30 wow fadeInLeft  animated" data-wow-delay=".4s">
                    <span class="process__item-number rr-rp-number">0<?php echo $key+1; ?></span>
                    <?php if (!empty($item['rr_process_title'])): ?>
                    <h5 class="mb-20 mt-10 rr-rp-title"><?php echo rr_kses($item['rr_process_title' ]); ?></h5>
                    <?php endif; ?>
                    <?php if (!empty($item['rr_process_des'])): ?>
                    <p class="rr-rp-desc"><?php echo rr_kses($item['rr_process_des' ]); ?></p>
                    <?php endif; ?>
                </div>
            </div>
        <?php endforeach; ?>
        </div>
    </div>
</section>

<?php else: 

if ( !empty($settings['rr_image']['url']) ) {
    $rr_image = !empty($settings['rr_image']['id']) ? wp_get_attachment_image_url( $settings['rr_image']['id'], $settings['rr_image_size_size']) : $settings['rr_image']['url'];
    $rr_bg_image_alt = get_post_meta($settings["rr_image"]["id"], "_wp_attachment_image_alt", true);
}
$this->add_render_attribute('title_args', 'class', 'section__title-wrapper-title wow fadeInLeft animated rr-el-title'); 
?>
<section class="section-space gray-bg">
    <div
        class="process__area border section-space-top bottom custom-width p-relative overflow-hidden z-1 rr-el-section">
        <div class="process__bg-img" data-background="<?php echo esc_url($rr_image); ?>"></div>
        <div class="container">
            <div class="row">
                <?php if ( !empty($settings['rr_section_section_title_show']) ) : ?>
                <div class="section__title-wrapper text-center mb-60">
                    <?php if ( !empty($settings['rr_section_sub_title']) ) : ?>
                    <h6 class="section__title-wrapper-center-subtitle mb-10 wow fadeInLeft animated rr-el-sub-title"
                        data-wow-delay=".2s">
                        <svg width="20" height="21" viewBox="0 0 20 21" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <g clip-path="url(#clip0_5704_198)">
                                <path
                                    d="M19.3 2.67377C19.2618 2.59399 19.1936 2.53259 19.1103 2.50302L12.1959 0.0621048C12.0224 0.000729911 11.832 0.0918964 11.7706 0.265396L10.2 4.70972H9.51302V3.57639C9.513 3.42331 9.47783 3.27229 9.41023 3.13495C9.34263 2.99761 9.2444 2.87762 9.12311 2.78424C9.00182 2.69086 8.86071 2.62656 8.71066 2.59632C8.5606 2.56608 8.4056 2.57069 8.25761 2.60981L0.248416 4.7208V4.7268C0.177823 4.74455 0.115123 4.78523 0.0701599 4.84247C0.0251971 4.89971 0.000518721 4.97027 0 5.04305L0 19.043C0 19.5953 0.447749 20.043 0.999998 20.043H10.3333C10.8856 20.043 11.3333 19.5953 11.3333 19.043V16.0184L14.0066 16.9622C14.1803 17.0233 14.3707 16.9324 14.4319 16.7587L19.3143 2.92847C19.3287 2.88716 19.3349 2.8434 19.3325 2.79969C19.33 2.75598 19.319 2.71319 19.2999 2.67377H19.3ZM8.42769 3.25264C8.47703 3.23964 8.52869 3.23812 8.57871 3.24819C8.62873 3.25827 8.67577 3.27968 8.71623 3.31076C8.7567 3.34193 8.78947 3.38197 8.81202 3.4278C8.83456 3.47363 8.84628 3.52402 8.84627 3.5751V4.70972H2.90366L8.42769 3.25264ZM10.6666 19.043C10.6666 19.1314 10.6315 19.2162 10.569 19.2787C10.5065 19.3412 10.4217 19.3764 10.3333 19.3764H0.999998C0.911593 19.3764 0.826808 19.3412 0.764296 19.2787C0.701784 19.2162 0.666665 19.1314 0.666665 19.043V5.37638H10.3333C10.4217 5.37638 10.5065 5.4115 10.569 5.47402C10.6315 5.53653 10.6666 5.62131 10.6666 5.70972V19.043ZM13.4067 6.64542L13.8333 6.44313L14.0366 6.86842L12.417 11.452C12.3877 11.5354 12.3926 11.627 12.4306 11.7068L12.7776 12.4327L12.6704 12.737L12.0093 12.0525C11.9734 12.0151 11.9294 11.9866 11.8806 11.9692C11.8318 11.9518 11.7797 11.9461 11.7283 11.9524L11.3333 12.0024V11.5557L11.6176 11.4197C11.6974 11.3816 11.7588 11.3134 11.7884 11.2301L12.4551 9.34479L13.4067 6.64542ZM14.0353 8.87034L14.7121 9.95775L14.5963 10.2854L13.7866 9.57642L14.0353 8.87034ZM11.3333 10.516V9.6L11.6613 9.58633L11.3333 10.516ZM11.9001 8.90942L11.3333 8.93271V8.489L12.1494 8.20434L11.9001 8.90942ZM13.9141 16.2224L11.3333 15.3114V12.6743L11.6456 12.6353L12.5667 13.5881C12.598 13.6199 12.6353 13.6452 12.6765 13.6624C12.7177 13.6795 12.762 13.6882 12.8066 13.688C12.8304 13.6882 12.8541 13.6856 12.8773 13.6804C12.9328 13.6683 12.9843 13.6423 13.0268 13.6047C13.0694 13.5671 13.1017 13.5193 13.1206 13.4657L13.4539 12.5227C13.4834 12.4393 13.4785 12.3477 13.4402 12.2681L13.0916 11.543L13.5477 10.2514L14.527 11.1098C14.5878 11.1631 14.6659 11.1925 14.7468 11.1925C14.7752 11.1925 14.8036 11.1887 14.8311 11.1814C14.8837 11.1676 14.9322 11.1411 14.9723 11.1043C15.0124 11.0675 15.0429 11.0214 15.0611 10.9701L15.3944 10.0271C15.411 9.97996 15.4168 9.9297 15.4114 9.88002C15.406 9.83035 15.3894 9.78253 15.363 9.74013L14.3196 8.06405L14.7103 6.9578C14.7249 6.91647 14.7312 6.87267 14.7289 6.8289C14.7265 6.78513 14.7156 6.74225 14.6966 6.70272L14.2901 5.85247C14.2712 5.81295 14.2447 5.77754 14.2121 5.74826C14.1796 5.71898 14.1416 5.6964 14.1003 5.68181C14.059 5.66722 14.0152 5.66091 13.9715 5.66324C13.9277 5.66557 13.8849 5.67649 13.8454 5.69538L12.9946 6.10213C12.9552 6.121 12.9199 6.14745 12.8906 6.17998C12.8614 6.21251 12.8389 6.25048 12.8244 6.29172L12.4333 7.39934L11.3333 7.78305V5.70972C11.3329 5.53913 11.2888 5.3715 11.2051 5.22286C11.1214 5.07422 11.0009 4.94954 10.8553 4.86076L11.4001 3.31601L11.5223 2.96947L12.2891 0.802812L18.5753 3.02172L13.9141 16.2224Z"
                                    fill="#034833" />
                                <path
                                    d="M16.5439 5.13329L16.7657 4.50454L17.3374 4.7062L17.1155 5.33495L16.5439 5.13329ZM11.972 3.51917L12.194 2.89062L12.7654 3.09242L12.5434 3.721L11.972 3.51917ZM15.4008 4.72979L15.6228 4.10104L16.1943 4.30287L15.9723 4.93145L15.4008 4.72979ZM13.115 3.92283L13.337 3.29425L13.9083 3.49608L13.6863 4.12466L13.115 3.92283ZM14.2579 4.326L14.48 3.69741L15.0514 3.89925L14.8294 4.52779L14.2579 4.326ZM5.51301 6.71091C3.67202 6.71091 2.17969 8.20324 2.17969 10.0442C2.17969 11.8852 3.67202 13.3776 5.51301 13.3776C7.35401 13.3776 8.84634 11.8852 8.84634 10.0442C8.84438 8.20424 7.35318 6.71299 5.51301 6.71091ZM7.92005 8.90457L7.4653 8.80465C7.2653 8.76053 7.06522 8.72557 6.86322 8.69528C6.83297 8.4935 6.79646 8.29271 6.75372 8.0932L6.65359 7.63861C7.20852 7.90276 7.65568 8.34975 7.92005 8.90457ZM2.84631 10.0442C2.84698 9.90799 2.85806 9.77194 2.87969 9.63732L3.70393 9.4539C3.83039 9.4259 3.95768 9.40265 4.08527 9.38065C4.05304 9.82251 4.05304 10.2661 4.08527 10.708C3.95764 10.686 3.83039 10.6626 3.70393 10.6346L2.87969 10.4513C2.85809 10.3167 2.84695 10.1806 2.84635 10.0442H2.84631ZM4.76172 9.29328C5.26137 9.24868 5.76399 9.24868 6.26364 9.29328C6.30839 9.79292 6.30839 10.2956 6.26364 10.7952C5.76399 10.84 5.26133 10.84 4.76168 10.7952C4.71693 10.2956 4.71697 9.79292 4.76172 9.29328ZM6.93926 9.38065C7.06701 9.40265 7.1943 9.4259 7.32059 9.4539L8.14497 9.63732C8.19119 9.90668 8.19119 10.182 8.14497 10.4513L7.32059 10.6346C7.19434 10.6626 7.06701 10.686 6.93926 10.7083C6.97165 10.2664 6.97165 9.82262 6.93926 9.38065ZM5.91972 7.41095L6.10301 8.23565C6.13101 8.36195 6.1546 8.48924 6.17676 8.61699C5.73474 8.5846 5.29095 8.5846 4.84893 8.61699C4.87106 8.48924 4.89435 8.36195 4.92268 8.23565L5.10593 7.41095C5.37527 7.36521 5.65039 7.36521 5.91972 7.41095ZM4.37306 7.6362L4.27293 8.09095C4.22898 8.29095 4.19397 8.49103 4.16373 8.69303C3.96195 8.72316 3.76116 8.75957 3.56164 8.8022L3.10689 8.90232C3.37146 8.34799 3.81845 7.90139 4.37302 7.63732L4.37306 7.6362ZM3.10623 11.1829L3.56098 11.283C3.76098 11.3269 3.96085 11.3619 4.16306 11.3922C4.19319 11.594 4.2296 11.7948 4.27222 11.9943L4.37235 12.4489C3.8175 12.185 3.37024 11.7383 3.10556 11.1839L3.10623 11.1829ZM5.10622 12.6756L4.92293 11.8509C4.8946 11.7249 4.87135 11.5973 4.84918 11.4699C5.06993 11.486 5.2916 11.4969 5.51326 11.4969C5.73493 11.4969 5.95597 11.486 6.17701 11.4699C6.15489 11.5973 6.13126 11.7249 6.10326 11.8509L5.92001 12.6756C5.65068 12.7213 5.37556 12.7213 5.10622 12.6756ZM6.65289 12.4503L6.75301 11.9956C6.7973 11.7956 6.83197 11.5956 6.86259 11.3935C7.06434 11.3633 7.2651 11.3269 7.46459 11.2843L7.91918 11.1842C7.65505 11.7395 7.20779 12.1869 6.65259 12.4513L6.65289 12.4503ZM2.84635 16.0442H8.17967V16.7109H2.84635V16.0442ZM3.51302 17.3776H7.51301V18.0442H3.51302V17.3776ZM5.17968 14.7109H5.84635V15.3776H5.17968V14.7109ZM3.84635 14.7109H4.51302V15.3776H3.84635V14.7109ZM6.51301 14.7109H7.17968V15.3776H6.51301V14.7109Z"
                                    fill="#034833" />
                            </g>
                            <defs>
                                <clipPath id="clip0_5704_198">
                                    <rect width="20" height="20" fill="white" transform="translate(0 0.0429688)" />
                                </clipPath>
                            </defs>
                        </svg>
                        <?php echo rr_kses( $settings['rr_section_sub_title'] ); ?>
                    </h6>
                    <?php endif; ?>
                    <?php
                        if ( !empty($settings['rr_section_title' ]) ) :
                            printf( '<%1$s %2$s>%3$s</%1$s>',
                            tag_escape( $settings['rr_section_title_tag'] ),
                            $this->get_render_attribute_string( 'title_args' ),
                            rr_kses( $settings['rr_section_title' ] )
                            );
                        endif;
                    ?>
                </div>
                <?php endif; ?>
            </div>
            <div class="row mb-minus-30">
                <?php foreach ($settings['rr_process_list'] as $key => $item) : ?>
                <div class="col-xl-4 col-lg-4 col-md-6">
                    <div class="process__item process__item_<?php echo $key+1; ?>  mb-30 wow fadeInLeft animated"
                        data-wow-delay=".4s">
                        <span class="process__item-number rr-rp-number">0<?php echo $key+1; ?></span>
                        <?php if (!empty($item['rr_process_title'])): ?>
                        <h5 class="mb-20 mt-10 rr-rp-title"><?php echo rr_kses($item['rr_process_title' ]); ?></h5>
                        <?php endif; ?>
                        <?php if (!empty($item['rr_process_des'])): ?>
                        <p class="rr-rp-desc"><?php echo rr_kses($item['rr_process_des' ]); ?></p>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</section>
<?php endif;
	}
}  

$widgets_manager->register( new rr_Process() );