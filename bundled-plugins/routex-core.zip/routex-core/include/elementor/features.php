<?php
namespace RRCore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Repeater;
use \Elementor\Utils;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * RR Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class rr_Features extends Widget_Base {

    use \RRCore\Widgets\RRCoreElementFunctions;

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'features';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Features', 'rr-core' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'rr-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'rr-core' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'rr-core' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
     
    protected function register_controls(){
        $this->register_controls_section();
        $this->style_tab_content();
    }  

	protected function register_controls_section() {

        // layout Panel
        $this->start_controls_section(
            'rr_layout',
            [
                'label' => esc_html__('Design Layout', 'rr-core'),
            ]
        );
        $this->add_control(
            'rr_design_style',
            [
                'label' => esc_html__('Select Layout', 'rr-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Layout 1', 'rr-core'),
                    'layout-2' => esc_html__('Layout 2', 'rr-core'),
                    'layout-3' => esc_html__('Layout 3', 'rr-core'),
                ],
                'default' => 'layout-1',
            ]
        );

        $this->end_controls_section();

        $this->rr_section_title_render_controls('section', 'Section Title', 'Sub Title', 'your title here', $default_description = 'Hic nesciunt galisum aut dolorem aperiam eum soluta quod ea cupiditate.', ['layout-1', 'layout-2']);
 
        // Features group
        $this->start_controls_section(
            'rr_features',
            [
                'label' => esc_html__('Features List', 'rr-core'),
                'description' => esc_html__( 'Control all the style settings from Style tab', 'rr-core' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $repeater = new \Elementor\Repeater();
 
        $repeater->add_control(
            'rr_features_main_image',
            [
                'label' => esc_html__('Upload Image', 'rr-core'),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ]

            ]
        );

        $repeater->add_control(
            'rr_features_title', [
                'label' => esc_html__('Title', 'rr-core'),
                'description' => rr_get_allowed_html_desc( 'basic' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('Service Title', 'rr-core'),
                'label_block' => true,
            ]
        );
        $repeater->add_control(
            'rr_features_desc', [
                'label' => esc_html__('Description', 'rr-core'),
                'description' => rr_get_allowed_html_desc( 'basic' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('Service Description', 'rr-core'),
                'label_block' => true,
            ]
        );
        $repeater->add_control(
            'template',
            [
                'label' => __('Section Template', 'rr-core'),
                'placeholder' => __('Select a section template for as tab content', 'rr-core'),
                'type' => Controls_Manager::SELECT2,
                'options' => get_elementor_templates()
            ]
        );
        $repeater->add_control(
            'rr_features_btn', [
                'label' => esc_html__('Button', 'rr-core'),
                'description' => rr_get_allowed_html_desc( 'basic' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('Apply Now', 'rr-core'),
                'label_block' => true,
            ]
        );
        $repeater->add_control(
            'rr_features_link',
            [
                'label' => esc_html__( 'Service Link link', 'rr-core' ),
                'type' => \Elementor\Controls_Manager::URL,
                'dynamic' => [
                    'active' => true,
                ],
                'placeholder' => esc_html__( 'htRRs://your-link.com', 'rr-core' ),
                'show_external' => true,
                'default' => [
                    'url' => '#',
                    'is_external' => false,
                    'nofollow' => false,
                ], 
            ]
        );

        $this->add_control(
            'rr_features_list',
            [
                'label' => esc_html__('Services - List', 'rr-core'),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'rr_features_title' => esc_html__('Discover', 'rr-core'),
                    ],
                    [
                        'rr_features_title' => esc_html__('Define', 'rr-core')
                    ],
                    [
                        'rr_features_title' => esc_html__('Develop', 'rr-core')
                    ]
                ],
                'title_field' => '{{{ rr_features_title }}}',
            ]
        );
        $this->end_controls_section();
    
        // section column
        $this->rr_columns('col');
        // button
        $this->rr_button_render('feature', 'Button', ['layout-1']);
                
	}

    // style_tab_content
    protected function style_tab_content(){
        $this->rr_section_style_controls('features_section', 'Section - Style', '.rr-el-section'); 
        $this->rr_basic_style_controls('repiter_sub_title', 'Features - Sub Title', '.rr-el-sub-title');
        $this->rr_basic_style_controls('features_title', 'Features Title', '.rr-el-re-Title');
        $this->rr_link_controls_style('features_btn', 'Features - Button', '.rr-el-btn');
        $this->rr_basic_style_controls('repiter_rp_title', 'Features - Rp Title', '.rr-el-rp-title');
        $this->rr_basic_style_controls('repiter_rp_dec', 'Features - Rp desc', '.rr-el-rp-desc');
        $this->rr_section_style_controls('features_box', 'Features - Box', '.rr-el-box'); 
    }

	/**
	 * Render the widget ouRRut on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		?>

<?php if ( $settings['rr_design_style']  == 'layout-2' ) : 
 $this->add_render_attribute('title_args', 'class', 'section__title-wrapper-title wow fadeInLeft animated rr-el-re-Title'); 
?>
<!--choice-->
<section class="choice__area section-space">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <?php if ( !empty($settings['rr_section_section_title_show']) ) : ?>
                <div class="section__title-wrapper text-center mb-70">
                    <h6 class="section__title-wrapper-center-subtitle mb-10 wow fadeInLeft animated"
                        data-wow-delay=".2s"><?php echo rr_kses( $settings['rr_section_sub_title'] ); ?></h6>
                    <?php
                            if ( !empty($settings['rr_section_title' ]) ) :
                                printf( '<%1$s %2$s>%3$s</%1$s>',
                                tag_escape( $settings['rr_section_title_tag'] ),
                                $this->get_render_attribute_string( 'title_args' ),
                                rr_kses( $settings['rr_section_title' ] )
                                );
                            endif;
                        ?>
                </div>
                <?php endif; ?>
            </div>
        </div>
        <div class="row mb-minus-30">
            <?php foreach ($settings['rr_features_list'] as $key => $item) :

                // thumbnail image
                if ( !empty($item['rr_features_main_image']['url']) ) {
                    $rr_features_main_image = !empty($item['rr_features_main_image']['id']) ? wp_get_attachment_image_url( $item['rr_features_main_image']['id'], 'full' ) : $item['rr_features_main_image']['url'];
                    $rr_features_main_image_alt = get_post_meta($item["rr_features_main_image"]["id"], "_wp_attachment_image_alt", true);
                }
            ?>
            <div class="col-xl-2 col-lg-3 col-md-4 col-sm-6">
                <div class="choice__item mb-30">
                    <div class="choice__item-icon">
                        <?php if(!empty($rr_features_main_image)) : ?>
                        <img src="<?php echo esc_url($rr_features_main_image); ?>"
                            alt="<?php echo esc_attr($rr_features_main_image_alt); ?>">
                        <?php endif; ?>
                    </div>
                    <h3 class="choice__item-title"><a
                            href="<?php echo rr_kses($item['rr_features_link']['url']); ?>"><?php echo rr_kses($item['rr_features_title']); ?></a>
                    </h3>
                    <p class="choice__item-dec"><?php echo rr_kses($item['rr_features_desc']); ?></p>
                    <a class="choice__item-btn" href="<?php echo rr_kses($item['rr_features_link']['url']); ?>"><?php echo rr_kses($item['rr_features_btn']); ?> <i class="fa-solid fa-arrow-right"></i></a>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>
<?php elseif ( $settings['rr_design_style']  == 'layout-3' ) : 
 $this->add_render_attribute('title_args', 'class', 'section__title-wrapper-title wow fadeInLeft animated rr-el-re-Title'); 
?>
<section class="feature-5__area pt-60 rr-el-section">
    <div class="container">
        <div class="row mb-minus-30">
            <?php foreach ($settings['rr_features_list'] as $key => $item) :

                // thumbnail image
                if ( !empty($item['rr_features_main_image']['url']) ) {
                    $rr_features_main_image = !empty($item['rr_features_main_image']['id']) ? wp_get_attachment_image_url( $item['rr_features_main_image']['id'], 'full' ) : $item['rr_features_main_image']['url'];
                    $rr_features_main_image_alt = get_post_meta($item["rr_features_main_image"]["id"], "_wp_attachment_image_alt", true);
                }
            ?>
            <div class="col-xl-4 col-lg-4 col-md-6 col-sm-6">
                <div class="feature-5__item mb-30 rr-el-box">
                    <div class="feature-5__item-icon">
                        <?php if(!empty($rr_features_main_image)) : ?>
                        <img src="<?php echo esc_url($rr_features_main_image); ?>"
                            alt="<?php echo esc_attr($rr_features_main_image_alt); ?>">
                        <?php endif; ?>
                    </div>
                    <div class="feature-5__item-content">
                        <h3 class="feature-5__item-content-title rr-el-rp-title"><a
                                href="<?php echo rr_kses($item['rr_features_link']['url']); ?>"><?php echo rr_kses($item['rr_features_title']); ?></a>
                        </h3>
                        <p class="feature-5__item-content-dec"><?php echo rr_kses($item['rr_features_desc']); ?></p>
                        <a class="feature-5__item-content-btn"
                            href="<?php echo rr_kses($item['rr_features_link']['url']); ?>">
                            <svg width="27" height="14" viewBox="0 0 27 14" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <path d="M1 7L25 7" stroke="#727272" stroke-width="1.5" stroke-linecap="round"
                                    stroke-linejoin="round"></path>
                                <path d="M20 1L26 7L20 13" stroke="#727272" stroke-width="1.5" stroke-linecap="round"
                                    stroke-linejoin="round"></path>
                            </svg>
                        </a>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>
<?php else: 

    // shape image
    if ( !empty($settings['rr_shape_image_1']['url']) ) {
        $rr_shape_image = !empty($settings['rr_shape_image_1']['id']) ? wp_get_attachment_image_url( $settings['rr_shape_image_1']['id'], $settings['shape_image_size_size']) : $settings['rr_shape_image_1']['url'];
        $rr_shape_image_alt = get_post_meta($settings["rr_shape_image_1"]["id"], "_wp_attachment_image_alt", true);
    }
    // Link
    if ('2' == $settings['rr_feature_btn_link_type']) {
        $this->add_render_attribute('rr-button-arg', 'href', get_permalink($settings['rr_feature_btn_page_link']));
        $this->add_render_attribute('rr-button-arg', 'target', '_self');
        $this->add_render_attribute('rr-button-arg', 'rel', 'nofollow');
        $this->add_render_attribute('rr-button-arg', 'class', 'choose-us__button-btn-2 rr-el-btn');
    } else {
        if ( ! empty( $settings['rr_feature_btn_link']['url'] ) ) {
            $this->add_link_attributes( 'rr-button-arg', $settings['rr_feature_btn_link'] );
            $this->add_render_attribute('rr-button-arg', 'class', 'choose-us__button-btn-2 rr-el-btn');
        }
    }
    $this->add_render_attribute('title_args', 'class', 'section-title2__wrapper-title  wow fadeInLeft animated rr-el-re-Title'); 
?>
<section class="adventure__area rr-el-section">
    <div class="container">
        <div class="row">
            <div class="section-title2 mb-60">
                <?php if ( !empty($settings['rr_section_section_title_show']) ) : ?>
                <div class="section-title2__wrapper">
                    <span class="section-title2__wrapper-subtitle wow fadeInLeft animated rr-el-sub-title"
                        data-wow-delay=".2s"><?php echo rr_kses( $settings['rr_section_sub_title'] ); ?>
                        <svg width="52" height="10" viewBox="0 0 52 10" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <g clip-path="url(#clip0_3931_71)">
                                <path
                                    d="M47.2095 2.18344C46.4096 2.40672 45.5874 2.54041 44.758 2.58205L38.0745 3.30621C36.5625 3.47892 35.0713 3.80163 33.6232 4.26955C32.834 4.5352 32.0748 4.88255 31.3577 5.30596C30.5815 5.829 29.7739 6.30381 28.9394 6.7277C28.4366 6.96308 27.8868 7.08121 27.3317 7.07318C26.7204 7.03762 26.1425 6.78287 25.704 6.35566C24.8602 5.48534 24.6277 4.429 24.0763 3.75134C23.8482 3.41858 23.505 3.18194 23.1129 3.08697C22.6926 2.9938 22.2543 3.02378 21.8506 3.17334C20.9442 3.50304 20.1839 4.14329 19.7047 4.98041C19.1267 5.83745 18.675 6.81407 18.0172 7.73089C17.3771 8.71604 16.4285 9.46132 15.3199 9.85023C14.738 10.0164 14.1213 10.0164 13.5394 9.85023C12.9881 9.68671 12.4799 9.4031 12.0512 9.01977C11.2848 8.31641 10.6875 7.44879 10.3039 6.48188C9.91861 5.59163 9.63957 4.72795 9.25423 3.97057C8.81236 2.93529 8.01001 2.0954 6.99598 1.60672C5.98195 1.11803 4.82509 1.0137 3.74 1.31311C3.16364 1.45839 2.62491 1.72496 2.15977 2.09501C1.69463 2.46505 1.3138 2.93008 1.04267 3.45902C0.609026 4.27533 0.40251 5.19311 0.444721 6.11649C0.461366 6.70812 0.587529 7.29153 0.816785 7.83719C0.969589 8.22253 1.07589 8.4152 1.04267 8.44177C1.00945 8.46835 0.849998 8.30225 0.624113 7.93685C0.297997 7.39186 0.0960956 6.78164 0.0328167 6.1497C-0.094422 5.13874 0.0716196 4.11252 0.511162 3.19327C0.798973 2.56791 1.21785 2.01172 1.73939 1.56239C2.26094 1.11305 2.87299 0.781076 3.53404 0.588948C4.3414 0.353297 5.19125 0.301393 6.02128 0.437049C6.85131 0.572705 7.64045 0.892483 8.33077 1.37291C9.08192 1.93421 9.6841 2.67099 10.0847 3.51881C10.5165 4.34927 10.8221 5.22623 11.2008 6.05669C11.535 6.88412 12.053 7.62474 12.7156 8.22253C13.0179 8.51315 13.3907 8.71992 13.7973 8.82245C14.204 8.92498 14.6303 8.91971 15.0342 8.80716C15.9058 8.48049 16.6489 7.8818 17.1536 7.09975C17.7316 6.29586 18.1833 5.31924 18.8145 4.37584C19.1355 3.8867 19.5172 3.44023 19.9505 3.0471C20.4071 2.65024 20.9377 2.34768 21.5118 2.15685C22.1043 1.95424 22.7412 1.91975 23.3521 2.0572C23.9719 2.21037 24.5177 2.57741 24.8934 3.09361C25.5977 4.03702 25.8368 5.08671 26.4082 5.61156C26.6675 5.87169 27.0118 6.02971 27.3782 6.05669C27.7818 6.05977 28.1811 5.97357 28.5475 5.80423C29.3497 5.40668 30.1284 4.96303 30.8794 4.4755C31.657 4.02977 32.4814 3.67106 33.3375 3.40587C34.8527 2.95271 36.4116 2.66098 37.9881 2.53555C40.8449 2.29638 43.1369 2.22329 44.7314 2.14356C45.5564 2.0652 46.3875 2.07858 47.2095 2.18344Z"
                                    fill="#034833" />
                                <path
                                    d="M45.4762 6.30876C45.4231 6.16924 46.1406 5.77727 47.2235 5.12619C47.7683 4.80065 48.4127 4.40202 49.1036 3.93032C49.4491 3.6978 49.768 3.43869 50.1666 3.17295C50.3373 3.05687 50.4954 2.92327 50.6383 2.77433C50.7579 2.65702 50.8527 2.51696 50.9173 2.36242C50.9506 2.23619 50.9173 2.24283 50.9173 2.19633C50.821 2.10822 50.7009 2.05045 50.5719 2.03023L49.283 1.68477C48.4592 1.45889 47.7218 1.23964 47.1039 1.0204C45.8682 0.621784 45.1108 0.302882 45.1573 0.163365C45.2038 0.0238476 46.001 0.0769986 47.2833 0.289596C47.9476 0.395895 48.6784 0.542055 49.5155 0.71479L50.8443 1.00711C51.184 1.06894 51.4955 1.23633 51.7345 1.48546C51.8826 1.65337 51.9774 1.86148 52.0069 2.08338C52.0341 2.28732 52.0113 2.4948 51.9405 2.68796C51.8291 2.98891 51.6521 3.26126 51.4223 3.4852C51.235 3.67786 51.0254 3.84737 50.7978 3.99011C50.4124 4.26915 50.0205 4.51497 49.6484 4.74085C48.9845 5.1379 48.2916 5.48435 47.5756 5.77726C46.3399 6.29547 45.5294 6.44163 45.4762 6.30876Z"
                                    fill="#034833" />
                            </g>
                            <defs>
                                <clipPath id="clip0_3931_71">
                                    <rect width="52" height="9.86585" fill="white" transform="translate(0 0.105469)" />
                                </clipPath>
                            </defs>
                        </svg>
                    </span>
                    <?php
                        if ( !empty($settings['rr_section_title' ]) ) :
                            printf( '<%1$s %2$s>%3$s</%1$s>',
                            tag_escape( $settings['rr_section_title_tag'] ),
                            $this->get_render_attribute_string( 'title_args' ),
                            rr_kses( $settings['rr_section_title' ] )
                            );
                        endif;
                    ?>
                </div>
                <?php endif; ?>
                <?php if ( !empty($settings['rr_feature_btn_text']) ) : ?>
                <div class="section-title2__button wow fadeInLeft animated" data-wow-delay=".4s">
                    <a <?php echo $this->get_render_attribute_string( 'rr-button-arg' ); ?>><?php echo rr_kses($settings['rr_feature_btn_text']); ?>
                        <i class="fa-solid fa-arrow-right"></i></a>
                </div>
                <?php endif; ?>
            </div>
        </div>
        <div class="row mb-minus-30">
            <?php foreach ($settings['rr_features_list'] as $key => $item) :

                // thumbnail image
                if ( !empty($item['rr_features_main_image']['url']) ) {
                    $rr_features_main_image = !empty($item['rr_features_main_image']['id']) ? wp_get_attachment_image_url( $item['rr_features_main_image']['id'], 'full' ) : $item['rr_features_main_image']['url'];
                    $rr_features_main_image_alt = get_post_meta($item["rr_features_main_image"]["id"], "_wp_attachment_image_alt", true);
                }
            ?>
            <div
                class="col-xl-<?php echo esc_attr($settings['rr_col_for_desktop']); ?> col-lg-<?php echo esc_attr($settings['rr_col_for_laptop']); ?> col-md-<?php echo esc_attr($settings['rr_col_for_tablet']); ?> col-<?php echo esc_attr($settings['rr_col_for_mobile']); ?>">
                <div class="adventure__item mb-30 wow fadeInLeft animated rr-el-box" data-wow-delay=".2s">
                    <?php if(!empty($rr_features_main_image)) : ?>
                    <div class="adventure__item-icon mb-20">
                        <img src="<?php echo esc_url($rr_features_main_image); ?>"
                            alt="<?php echo esc_attr($rr_features_main_image_alt); ?>">
                    </div>
                    <?php endif; ?>
                    <div class="adventure__item-content">
                        <?php if ( !empty($item['rr_features_title']) ) : ?>
                        <h3 class="rr-el-rp-title"><?php echo rr_kses($item['rr_features_title']); ?></h3>
                        <?php endif; ?>
                        <div class="adventure__item-content-list mt-20">
                            <?php echo \Elementor\Plugin::instance()->frontend->get_builder_content($item['template'], true); ?>
                        </div>
                    </div> 
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>
<?php endif;
	}
}

$widgets_manager->register( new rr_Features() );