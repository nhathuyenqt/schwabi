<?php
namespace RRCore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Repeater;
use \Elementor\Utils;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * RR Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class rr_Projects_slider extends Widget_Base {

    use \RRCore\Widgets\RRCoreElementFunctions;

    /**
     * Retrieve the widget name.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name() {
        return 'project';
    }

    /**
     * Retrieve the widget title.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title() {
        return __( 'Projects', 'rr-core' );
    }

    /**
     * Retrieve the widget icon.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'rr-icon';
    }
    /**
     * Retrieve the list of categories the widget belongs to.
     *
     * Used to determine where to display the widget in the editor.
     *
     * Note that currently Elementor supports only one category.
     * When multiple categories passed, Elementor uses the first one.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return array Widget categories.
     */ 
    public function get_categories() {
        return [ 'rr-core' ];
    }

    /**
     * Retrieve the list of scripts the widget depended on.
     *
     * Used to set scripts dependencies required to run the widget.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return array Widget scripts dependencies.
     */
    public function get_script_depends() {
        return [ 'rr-core' ];
    }

    /**
     * Register the widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     *
     * @access protected
     */

    protected function register_controls(){
        $this->register_controls_section();
        $this->style_tab_content();
    }   

	protected function register_controls_section() {

        // layout Panel
        $this->start_controls_section(
            'rr_layout',
            [
                'label' => esc_html__('Design Layout', 'tpcore'),
            ]
        );
        $this->add_control(
            'rr_design_style',
            [
                'label' => esc_html__('Select Layout', 'tpcore'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Layout 1', 'tpcore'),
                    'layout-2' => esc_html__('Layout 2', 'tpcore'),
                ],
                'default' => 'layout-1',
            ]
        );

        $this->end_controls_section();
        // title/content
        $this->rr_section_title_render_controls('section', 'Section Title', 'Sub Title', 'your title here', $default_description = 'Hic nesciunt galisum aut dolorem aperiam eum soluta quod ea cupiditate.',['layout-2']);

        $this->start_controls_section(
            'rr_platform_single_area',
            [
                'label' => esc_html__('Platform List', 'tpcore'),
                'description' => esc_html__( 'Control all the style settings from Style tab', 'tpcore' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
                'condition' => [
                    'rr_design_style' => ['layout-1']
                ]
            ]
        );


        $this->add_control(
            'repeater_single_condition',
            [
                'label' => __( 'Field condition', 'tpcore' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'style_1' => __( 'Style 1', 'tpcore' ),
                    'style_2' => __( 'Style 2', 'tpcore' ),
                ],
                'default' => 'style_1',
                'frontend_available' => true,
                'style_transfer' => true,
            ]
        );
        $this->add_control(
            'rr_thumbnail_image_single',
            [
                'label' => esc_html__( 'Choose Thumbnail Image', 'rr-core' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Image_Size::get_type(),
            [
                'name' => 'rr_image_size',
                'default' => 'full',
                'exclude' => [
                    'custom'
                ]
            ]
        );    

        $this->add_control(
            'rr_features_single_title', [
                'label' => esc_html__('Features link', 'tpcore'),
                'description' => rr_get_allowed_html_desc( 'basic' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('Service Title', 'tpcore'),
                'label_block' => true,
            ]
        );
        $this->add_control(
            'rr_platform_single_sub_title',
            [
                'label' => esc_html__('Designation', 'tpcore'),
                'description' => rr_get_allowed_html_desc( 'intermediate' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'Web Developer',
                'label_block' => true,
            ]
        );    

        $this->add_control(
            'rr_features_single_link',
            [
                'label' => esc_html__( 'Service Link link', 'tpcore' ),
                'type' => \Elementor\Controls_Manager::URL,
                'dynamic' => [
                    'active' => true,
                ],
                'show_external' => true,
                'default' => [
                    'url' => '#',
                    'is_external' => false,
                    'nofollow' => false,
                ],
            ]
        );
        $this->end_controls_section();
    
        // Security group
        $this->start_controls_section(
            'rr_security',
            [
                'label' => esc_html__('Project List', 'rr-core'),
                'description' => esc_html__( 'Control all the style settings from Style tab', 'rr-core' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
                'condition' => [
                    'rr_design_style' => ['layout-2']
                ]
            ]
        );

        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'rr_security_title', [
                'label' => esc_html__('Title', 'rr-core'),
                'description' => rr_get_allowed_html_desc( 'basic' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('Service Title', 'rr-core'),
                'label_block' => true,
            ]
        );
        $repeater->add_control(
            'rr_security_subtitle',
            [
                'label' => esc_html__('Subtitle', 'rr-core'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'label_block' => true,
            ]
        );
        

        $repeater->add_control(
            'rr_security_link_switcher',
            [
                'label' => esc_html__( 'Add Services link', 'rr-core' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Yes', 'rr-core' ),
                'label_off' => esc_html__( 'No', 'rr-core' ),
                'return_value' => 'yes',
                'default' => 'yes',
                'separator' => 'before',
            ]
        );
        
        $repeater->add_control(
            'rr_security_link_type',
            [
                'label' => esc_html__( 'Service Link Type', 'rr-core' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    '1' => 'Custom Link',
                    '2' => 'Internal Page',
                ],
                'default' => '1',
                'condition' => [
                    'rr_security_link_switcher' => 'yes'
                ]
            ]
        );

        $repeater->add_control(
            'rr_security_link',
            [
                'label' => esc_html__( 'Service Link link', 'rr-core' ),
                'type' => \Elementor\Controls_Manager::URL,
                'dynamic' => [
                    'active' => true,
                ],
                'placeholder' => esc_html__( 'https://your-link.com', 'rr-core' ),
                'show_external' => true,
                'default' => [
                    'url' => '#',
                    'is_external' => false,
                    'nofollow' => false,
                ],
                'condition' => [
                    'rr_security_link_type' => '1',
                    'rr_security_link_switcher' => 'yes',
                ]
            ]
        );

        $repeater->add_control(
            'rr_security_page_link',
            [
                'label' => esc_html__( 'Select Service Link Page', 'rr-core' ),
                'type' => \Elementor\Controls_Manager::SELECT2,
                'label_block' => true,
                'options' => rr_get_all_pages(),
                'condition' => [
                    'rr_security_link_type' => '2',
                    'rr_security_link_switcher' => 'yes',
                ]
            ]
        );

        $repeater->add_control(
            'rr_security_image',
            [
                'label' => esc_html__( 'Choose Image', 'rr-core' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $repeater->add_group_control(
            Group_Control_Image_Size::get_type(),
            [
                'name' => 'rr_image_size',
                'default' => 'full',
                'exclude' => [
                    'custom'
                ]
            ]
        );
        

        $this->add_control(
            'rr_security_list',
            [
                'label' => esc_html__('Services - List', 'rr-core'),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'rr_security_title' => esc_html__('Discover', 'rr-core'),
                    ],
                    [
                        'rr_security_title' => esc_html__('Define', 'rr-core')
                    ],
                    [
                        'rr_security_title' => esc_html__('Develop', 'rr-core')
                    ]
                ],
                'title_field' => '{{{ rr_security_title }}}',

            ]
        );
        $this->end_controls_section();

	}

    // style_tab_content
    protected function style_tab_content(){
        $this->rr_section_style_controls('platform_area_section', 'Section - Style', '.rr-el-section');
        $this->rr_basic_style_controls('platform_area_subtitle', 'Section - Subtitle', '.rr-el-subtitle', ['layout-1', 'layout-2']);
        $this->rr_basic_style_controls('platform_area_title', 'Section - Title', '.rr-el-title', ['layout-1', 'layout-2']);
        $this->rr_basic_style_controls('platform_rep_title', 'Rep - Title', '.rr-rp-title', ['layout-2']);
        $this->rr_basic_style_controls('platform_rep_designation', 'Rep - Designation', '.rr-rp-desc', ['layout-2']);
    }

	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		?>

<?php if ( $settings['rr_design_style']  == 'layout-2' ): 
	$this->add_render_attribute('title_args', 'class', 'section__title text-capitalize mb-0 title-animation rr-el-title');
?>

<section class="latest-work rr-el-section">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="section__title-wrapper latest-work__content text-center mb-60 mb-xs-40">
                    <?php if ( !empty($settings['rr_section_sub_title']) ) : ?>
                    <h5 class="section__subtitle color-theme-primary mb-15 mb-xs-10 title-animation rr-el-subtitle"><img
                            src="<?php echo get_template_directory_uri(  ); ?>/assets/imgs/ask-quesiton/heart.png"
                            alt="icon not found"
                            class="img-fluid"><?php echo rr_kses( $settings['rr_section_sub_title'] ); ?>
                    </h5>
                    <?php endif; ?>
                    <?php
                        if ( !empty($settings['rr_section_title' ]) ) :
                            printf( '<%1$s %2$s>%3$s</%1$s>',
                            tag_escape( $settings['rr_section_title_tag'] ),
                            $this->get_render_attribute_string( 'title_args' ),
                            rr_kses( $settings['rr_section_title' ] )
                            );
                        endif;
                    ?>
                </div>
            </div>
        </div>
    </div>

    <div class="swiper latest-work__slider">
        <div class="swiper-wrapper">
            <?php foreach ($settings['rr_security_list'] as $key => $item) :
                        
            if ('2' == $item['rr_security_link_type']) {
                $link = get_permalink($item['rr_security_page_link']);
                $target = '_self';
                $rel = 'nofollow';
            } else {
                $link = !empty($item['rr_security_link']['url']) ? $item['rr_security_link']['url'] : '';
                $target = !empty($item['rr_security_link']['is_external']) ? '_blank' : '';
                $rel = !empty($item['rr_security_link']['nofollow']) ? 'nofollow' : '';
            }
            if ( !empty($item['rr_security_image']['url']) ) {
                $rr_image = !empty($item['rr_security_image']['id']) ? wp_get_attachment_image_url( $item['rr_security_image']['id'], $item['rr_image_size_size']) : $item['rr_security_image']['url'];
                $rr_image_alt = get_post_meta($item["rr_security_image"]["id"], "_wp_attachment_image_alt", true);
            }
        ?>
            <div class="swiper-slide">
                <div class="latest-work__item">
                    <div class="latest-work__item-media">
                        <?php if(!empty($rr_image)) : ?>
                        <img src="<?php echo esc_url($rr_image); ?>" alt="<?php echo esc_attr($rr_image_alt); ?>">
                        <?php endif; ?>
                    </div>
                    <div class="latest-work__item-hover">
                    <?php if (!empty($item['rr_security_title' ])): ?>
                        <h4 class="mb-10 rr-rp-title">
                        <?php if(!empty($link)) : ?>
                        <a href="<?php echo esc_url($link); ?>"><?php echo rr_kses($item['rr_security_title' ]); ?></a>
                        <?php else : ?>
                        <?php echo rr_kses($item['rr_security_title' ]); ?>
                        <?php endif; ?>
                        </h4>
                        <?php endif; ?>
                        <?php if (!empty($item['rr_security_subtitle' ])): ?>
                        <p class="mb-0 rr-rp-desc"><?php echo rr_kses($item['rr_security_subtitle' ]); ?></p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        <div class="latest-work__slider-dot mt-80"></div>
    </div>
</section>

<?php else: 
	$this->add_render_attribute('title_args', 'class', 'title wow fadeInLeft animated rr-el-title');
    // thumbnail image
    if ( !empty($settings['rr_thumbnail_image_single']['url']) ) {
        $rr_thumbnail_image_single = !empty($settings['rr_thumbnail_image_single']['id']) ? wp_get_attachment_image_url( $settings['rr_thumbnail_image_single']['id'], $settings['rr_image_size_size']) : $settings['rr_thumbnail_image_single']['url'];
        $rr_thumbnail_image_alt = get_post_meta($settings["rr_thumbnail_image_single"]["id"], "_wp_attachment_image_alt", true);
    }

?>

<div class="our-projects__item position-relative overflow-hidden rr-el-section">
    <div class="panel wow"></div>
    <div class="our-projects__item__content">
        <div class="our-projects__item__content-media">
            <?php if( !empty($settings['rr_thumbnail_image_single'] ) ) : ?>
            <img src="<?php echo esc_url($rr_thumbnail_image_single); ?>"
                alt="<?php echo esc_attr($rr_thumbnail_image_alt); ?>">
            <?php endif; ?>
        </div>
        <div class="our-projects__item__content-icon">
            <a href="<?php echo rr_kses($settings['rr_features_single_link']['url']); ?>">
                <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path
                        d="M18.0006 1V14C18.0006 14.2652 17.8952 14.5196 17.7077 14.7071C17.5201 14.8946 17.2658 15 17.0006 15C16.7353 15 16.481 14.8946 16.2934 14.7071C16.1059 14.5196 16.0006 14.2652 16.0006 14V3.41375L1.70806 17.7075C1.52042 17.8951 1.26592 18.0006 1.00056 18.0006C0.735192 18.0006 0.480697 17.8951 0.293056 17.7075C0.105415 17.5199 0 17.2654 0 17C0 16.7346 0.105415 16.4801 0.293056 16.2925L14.5868 2H4.00056C3.73534 2 3.48099 1.89464 3.29345 1.70711C3.10591 1.51957 3.00056 1.26522 3.00056 1C3.00056 0.734784 3.10591 0.48043 3.29345 0.292893C3.48099 0.105357 3.73534 0 4.00056 0H17.0006C17.2658 0 17.5201 0.105357 17.7077 0.292893C17.8952 0.48043 18.0006 0.734784 18.0006 1Z"
                        fill="white" />
                </svg>
            </a>
        </div>
        <div class="our-projects__item__content-text">
            <?php if ( !empty($settings['rr_features_single_title']) ) : ?>
            <h4 class="title-animation rr-el-title"><a
                    href="<?php echo rr_kses($settings['rr_features_single_link']['url']); ?>"><?php echo rr_kses($settings['rr_features_single_title' ]); ?></a>
            </h4>
            <?php endif; ?>
            <?php if ( !empty($settings['rr_platform_single_sub_title']) ) : ?>
            <p class="rr-el-subtitle"><?php echo rr_kses($settings['rr_platform_single_sub_title']);?></p>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php endif; 
	}
}

$widgets_manager->register( new rr_Projects_slider() );