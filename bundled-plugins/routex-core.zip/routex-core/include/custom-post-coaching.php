<?php 
class RRProjecRRost 
{
	function __construct() {
		add_action( 'init', array( $this, 'register_custom_post_type' ) );
		add_action( 'init', array( $this, 'create_cat' ) );
		add_filter( 'template_include', array( $this, 'coachings_template_include' ) );
	}
	
	public function coachings_template_include( $template ) {
		if ( is_singular( 'rr-coachings' ) ) {
			return $this->get_template( 'single-rr-coachings.php');
		}
		return $template;
	}
	
	public function get_template( $template ) {
		if ( $theme_file = locate_template( array( $template ) ) ) {
			$file = $theme_file;
		} 
		else {
			$file = RRCORE_ADDONS_DIR . '/include/template/'. $template;
		}
		return apply_filters( __FUNCTION__, $file, $template );
	}
	
	
	public function register_custom_post_type() {
		$medilix_services_slug = get_theme_mod( 'medilix_services_slug', __( 'Coachings', 'rr-core' ) );
		$labels = array(
			'name'                  => esc_html_x( 'Coachings', 'Post Type General Name', 'rr-core' ),
			'singular_name'         => esc_html_x( 'Coaching', 'Post Type Singular Name', 'rr-core' ),
			'menu_name'             => esc_html__( 'Coachings', 'rr-core' ),
			'name_admin_bar'        => esc_html__( 'Coachings', 'rr-core' ),
			'archives'              => esc_html__( 'Item Archives', 'rr-core' ),
			'parent_item_colon'     => esc_html__( 'Parent Item:', 'rr-core' ),
			'all_items'             => esc_html__( 'All Items', 'rr-core' ),
			'add_new_item'          => esc_html__( 'Add New coaching', 'rr-core' ),
			'add_new'               => esc_html__( 'Add New', 'rr-core' ),
			'new_item'              => esc_html__( 'New Item', 'rr-core' ),
			'edit_item'             => esc_html__( 'Edit Item', 'rr-core' ),
			'update_item'           => esc_html__( 'Update Item', 'rr-core' ),
			'view_item'             => esc_html__( 'View Item', 'rr-core' ),
			'search_items'          => esc_html__( 'Search Item', 'rr-core' ),
			'not_found'             => esc_html__( 'Not found', 'rr-core' ),
			'not_found_in_trash'    => esc_html__( 'Not found in Trash', 'rr-core' ),
			'featured_image'        => esc_html__( 'Featured Image', 'rr-core' ),
			'set_featured_image'    => esc_html__( 'Set featured image', 'rr-core' ),
			'remove_featured_image' => esc_html__( 'Remove featured image', 'rr-core' ),
			'use_featured_image'    => esc_html__( 'Use as featured image', 'rr-core' ),
			'inserbt_into_item'     => esc_html__( 'Insert into item', 'rr-core' ),
			'uploaded_to_this_item' => esc_html__( 'Uploaded to this item', 'rr-core' ),
			'items_list'            => esc_html__( 'Items list', 'rr-core' ),
			'items_list_navigation' => esc_html__( 'Items list navigation', 'rr-core' ),
			'filter_items_list'     => esc_html__( 'Filter items list', 'rr-core' ),
		);

		$args   = array(
			'label'                 => esc_html__( 'coaching', 'rr-core' ),
			'labels'                => $labels,
			'supports'              => ['title', 'editor', 'thumbnail', 'elementor'],
			'hierarchical'          => false,
			'public'                => true,
			'show_ui'               => true,
			'show_in_menu'          => true,
			'menu_position'         => 5,
			'menu_icon'   			=> 'dashicons-shield',
			'show_in_admin_bar'     => true,
			'show_in_nav_menus'     => true,
			'can_export'            => true,
			'has_archive'           => true,		
			'exclude_from_search'   => false,
			'publicly_queryable'    => true,
			'capability_type'       => 'page',
			'rewrite' => array(
				'slug' => $medilix_services_slug,
				'with_front' => false
			),
		);

		register_post_type( 'rr-coachings', $args );
	}
	
	public function create_cat() {
		$labels = array(
			'name'                       => esc_html_x( 'Coaching Categories', 'Taxonomy General Name', 'rr-core' ),
			'singular_name'              => esc_html_x( 'coaching Categories', 'Taxonomy Singular Name', 'rr-core' ),
			'menu_name'                  => esc_html__( 'Coaching Categories', 'rr-core' ),
			'all_items'                  => esc_html__( 'All coaching Category', 'rr-core' ),
			'parent_item'                => esc_html__( 'Parent Item', 'rr-core' ),
			'parent_item_colon'          => esc_html__( 'Parent Item:', 'rr-core' ),
			'new_item_name'              => esc_html__( 'New coaching Category Name', 'rr-core' ),
			'add_new_item'               => esc_html__( 'Add New coaching Category', 'rr-core' ),
			'edit_item'                  => esc_html__( 'Edit coaching Category', 'rr-core' ),
			'update_item'                => esc_html__( 'Update coaching Category', 'rr-core' ),
			'view_item'                  => esc_html__( 'View coaching Category', 'rr-core' ),
			'separate_items_with_commas' => esc_html__( 'Separate items with commas', 'rr-core' ),
			'add_or_remove_items'        => esc_html__( 'Add or remove items', 'rr-core' ),
			'choose_from_most_used'      => esc_html__( 'Choose from the most used', 'rr-core' ),
			'popular_items'              => esc_html__( 'Popular coaching Category', 'rr-core' ),
			'search_items'               => esc_html__( 'Search coaching Category', 'rr-core' ),
			'not_found'                  => esc_html__( 'Not Found', 'rr-core' ),
			'no_terms'                   => esc_html__( 'No coaching Category', 'rr-core' ),
			'items_list'                 => esc_html__( 'coaching Category list', 'rr-core' ),
			'items_list_navigation'      => esc_html__( 'coaching Category list navigation', 'rr-core' ),
		);

		$args = array(
			'labels'                     => $labels,
			'hierarchical'               => true,
			'public'                     => true,
			'show_ui'                    => true, 
			'show_admin_column'          => true,
			'show_in_nav_menus'          => true,
			'show_tagcloud'              => true,
		);

		register_taxonomy('coachings-cat','rr-coachings', $args );
	}

}

new RRProjecRRost();