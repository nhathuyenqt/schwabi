<?php
/**
 * The main template file
 *
 * @package  WordPress 
 * @subpackage  rr-core
 */
get_header();

$service_column = is_active_sidebar( 'rr-visa-sidebar' ) ? 'col-lg-8' : 'col-lg-12';

?>
<section class="visa-details__area coaching-details padding-t100 section-space-bottom">
    <div class="container">
        <div class="row">
            <div class="col-lg-8">
                <?php 
                    if( have_posts() ) : 
                    while( have_posts() ) : 
                    the_post();
                ?>
                <div class="visa-details__content">
                    <?php the_content(); ?>
                </div>
                <?php
                    endwhile;   
                    wp_reset_query();
                    endif;
                ?>
            </div>
            <?php if ( is_active_sidebar( 'rr-visa-sidebar' ) ): ?>
            <div class="col-lg-4">
                <?php dynamic_sidebar( 'rr-visa-sidebar' ); ?>
            </div>
            <?php endif; ?>
        </div>
    </div>
</section>


<?php get_footer();  ?>