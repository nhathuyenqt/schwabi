<?php
/**
 * The main template file
 *
 * @package  WordPress
 * @subpackage  rr-core
 */
get_header();
$service_column = is_active_sidebar( 'rr-countries-sidebar' ) ? 'col-lg-8' : 'col-lg-12';
?>
<section class="countrie-details__area visa-details countrie countrie-main pt-100 section-space-bottom">
    <div class="container">
        <div class="row">
               <?php 
                  if( have_posts() ) : 
                  while( have_posts() ) : 
                  the_post();
                ?>
            <div class="col-lg-8">
                <div class="countrie-details__content">
                     <?php the_content(); ?>
                </div>
            </div>
            <?php
                  endwhile;   
                  wp_reset_query();
                  endif;
                ?>
            <?php if ( is_active_sidebar( 'rr-countries-sidebar' ) ): ?>
            <div class="col-lg-4">
               <?php dynamic_sidebar( 'rr-countries-sidebar' ); ?>
            </div>
            <?php endif; ?>
        </div>
    </div>
</section>


<?php get_footer();  ?>