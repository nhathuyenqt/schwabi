<?php
/**
 * The main template file
 *
 * @package  WordPress
 * @subpackage  rr-core
 */
get_header();

$project_column = is_active_sidebar( 'rr-coaching-sidebar' ) ? 'col-lg-8' : 'col-lg-12';

?>
<section class="coaching-details__area pt-100 section-space-bottom">
    <div class="container">
        <div class="row gx-30">
            <?php if ( is_active_sidebar( 'rr-coaching-sidebar' ) ): ?>
            <div class="col-xl-4 col-lg-4 col-12">
                <?php dynamic_sidebar( 'rr-coaching-sidebar' ); ?>
            </div>
            <?php endif; ?>
            <?php 
               if( have_posts() ) :  
               while( have_posts() ) :  
               the_post();
            ?>
            <div class="<?php echo esc_attr($project_column); ?>">
                <div class="rr-service-details">
                    <?php the_content(); ?>
                </div>
            </div>
            <?php
               endwhile;  
               wp_reset_query();
               endif;
            ?>

        </div>
    </div>
</section>
<?php get_footer();  ?>